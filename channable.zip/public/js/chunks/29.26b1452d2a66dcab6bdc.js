(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[29],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _SwiperDefault_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperDefault.vue */ "./resources/js/src/views/extensions/swiper/SwiperDefault.vue");
/* harmony import */ var _SwiperNavigation_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SwiperNavigation.vue */ "./resources/js/src/views/extensions/swiper/SwiperNavigation.vue");
/* harmony import */ var _SwiperPagination_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./SwiperPagination.vue */ "./resources/js/src/views/extensions/swiper/SwiperPagination.vue");
/* harmony import */ var _SwiperProgress_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./SwiperProgress.vue */ "./resources/js/src/views/extensions/swiper/SwiperProgress.vue");
/* harmony import */ var _SwiperMultipleSlides_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./SwiperMultipleSlides.vue */ "./resources/js/src/views/extensions/swiper/SwiperMultipleSlides.vue");
/* harmony import */ var _SwiperMultiRowSlides_vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./SwiperMultiRowSlides.vue */ "./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue");
/* harmony import */ var _SwiperCenteredSlides_vue__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./SwiperCenteredSlides.vue */ "./resources/js/src/views/extensions/swiper/SwiperCenteredSlides.vue");
/* harmony import */ var _SwiperCenteredSlides2_vue__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./SwiperCenteredSlides2.vue */ "./resources/js/src/views/extensions/swiper/SwiperCenteredSlides2.vue");
/* harmony import */ var _SwiperFadeEffect_vue__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./SwiperFadeEffect.vue */ "./resources/js/src/views/extensions/swiper/SwiperFadeEffect.vue");
/* harmony import */ var _SwiperCube_vue__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./SwiperCube.vue */ "./resources/js/src/views/extensions/swiper/SwiperCube.vue");
/* harmony import */ var _SwiperCoverflowEffect_vue__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./SwiperCoverflowEffect.vue */ "./resources/js/src/views/extensions/swiper/SwiperCoverflowEffect.vue");
/* harmony import */ var _SwiperAutoplay_vue__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./SwiperAutoplay.vue */ "./resources/js/src/views/extensions/swiper/SwiperAutoplay.vue");
/* harmony import */ var _SwiperGallery_vue__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./SwiperGallery.vue */ "./resources/js/src/views/extensions/swiper/SwiperGallery.vue");
/* harmony import */ var _SwiperParallax_vue__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./SwiperParallax.vue */ "./resources/js/src/views/extensions/swiper/SwiperParallax.vue");
/* harmony import */ var _SwiperLazy_vue__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./SwiperLazy.vue */ "./resources/js/src/views/extensions/swiper/SwiperLazy.vue");
/* harmony import */ var _SwiperResponsive_vue__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./SwiperResponsive.vue */ "./resources/js/src/views/extensions/swiper/SwiperResponsive.vue");
/* harmony import */ var _SwiperVirtual_vue__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./SwiperVirtual.vue */ "./resources/js/src/views/extensions/swiper/SwiperVirtual.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


















/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BRow: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BRow"],
    BCol: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCol"],
    SwiperDefault: _SwiperDefault_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    SwiperNavigation: _SwiperNavigation_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    SwiperPagination: _SwiperPagination_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    SwiperProgress: _SwiperProgress_vue__WEBPACK_IMPORTED_MODULE_4__["default"],
    SwiperMultipleSlides: _SwiperMultipleSlides_vue__WEBPACK_IMPORTED_MODULE_5__["default"],
    SwiperMultiRowSlides: _SwiperMultiRowSlides_vue__WEBPACK_IMPORTED_MODULE_6__["default"],
    SwiperCenteredSlides: _SwiperCenteredSlides_vue__WEBPACK_IMPORTED_MODULE_7__["default"],
    SwiperCenteredSlides2: _SwiperCenteredSlides2_vue__WEBPACK_IMPORTED_MODULE_8__["default"],
    SwiperFadeEffect: _SwiperFadeEffect_vue__WEBPACK_IMPORTED_MODULE_9__["default"],
    SwiperCube: _SwiperCube_vue__WEBPACK_IMPORTED_MODULE_10__["default"],
    SwiperCoverflowEffect: _SwiperCoverflowEffect_vue__WEBPACK_IMPORTED_MODULE_11__["default"],
    SwiperAutoplay: _SwiperAutoplay_vue__WEBPACK_IMPORTED_MODULE_12__["default"],
    SwiperGallery: _SwiperGallery_vue__WEBPACK_IMPORTED_MODULE_13__["default"],
    SwiperParallax: _SwiperParallax_vue__WEBPACK_IMPORTED_MODULE_14__["default"],
    SwiperLazy: _SwiperLazy_vue__WEBPACK_IMPORTED_MODULE_15__["default"],
    SwiperResponsive: _SwiperResponsive_vue__WEBPACK_IMPORTED_MODULE_16__["default"],
    SwiperVirtual: _SwiperVirtual_vue__WEBPACK_IMPORTED_MODULE_17__["default"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperAutoplay.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperAutoplay.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/swiper.css */ "./node_modules/swiper/css/swiper.css");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/swiper/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["Swiper"],
    SwiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["SwiperSlide"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    BImg: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BImg"]
  },
  data: function data() {
    return {
      codeAutoplay: _code__WEBPACK_IMPORTED_MODULE_4__["codeAutoplay"],
      swiperOptions: {
        spaceBetween: 30,
        centeredSlides: true,
        autoplay: {
          delay: 2500,
          disableOnInteraction: false
        },
        pagination: {
          el: '.swiper-pagination',
          clickable: true
        },
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }
      },

      /* eslint-disable global-require */
      swiperData: [{
        img: __webpack_require__(/*! @/assets/images/banner/banner-20.jpg */ "./resources/js/src/assets/images/banner/banner-20.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-7.jpg */ "./resources/js/src/assets/images/banner/banner-7.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-8.jpg */ "./resources/js/src/assets/images/banner/banner-8.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-9.jpg */ "./resources/js/src/assets/images/banner/banner-9.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-10.jpg */ "./resources/js/src/assets/images/banner/banner-10.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-11.jpg */ "./resources/js/src/assets/images/banner/banner-11.jpg")
      }]
      /* eslint-disable global-require */

    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperCenteredSlides.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperCenteredSlides.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! swiper/css/swiper.css */ "./node_modules/swiper/css/swiper.css");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/swiper/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["Swiper"],
    SwiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["SwiperSlide"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      codeCenterSlides: _code__WEBPACK_IMPORTED_MODULE_3__["codeCenterSlides"],
      swiperData: [{
        icon: 'GithubIcon',
        text: 'Getting Started'
      }, {
        icon: 'FacebookIcon',
        text: 'Pricing & Plans'
      }, {
        icon: 'TwitterIcon',
        text: 'Sales Question'
      }, {
        icon: 'InstagramIcon',
        text: 'Usage Guides'
      }, {
        icon: 'GitlabIcon',
        text: 'General Guide'
      }],
      swiperOptions: {
        slidesPerView: 'auto',
        centeredSlides: true,
        spaceBetween: 30,
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }
      }
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperCenteredSlides2.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperCenteredSlides2.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! swiper/css/swiper.css */ "./node_modules/swiper/css/swiper.css");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/swiper/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["Swiper"],
    SwiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["SwiperSlide"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      codeCenterSlides2: _code__WEBPACK_IMPORTED_MODULE_3__["codeCenterSlides2"],
      swiperData: [{
        icon: 'GithubIcon',
        text: 'Getting Started'
      }, {
        icon: 'FacebookIcon',
        text: 'Pricing & Plans'
      }, {
        icon: 'TwitterIcon',
        text: 'Sales Question'
      }, {
        icon: 'InstagramIcon',
        text: 'Usage Guides'
      }, {
        icon: 'FacebookIcon',
        text: 'Pricing & Plans'
      }],
      swiperOptions: {
        slidesPerView: 'auto',
        centeredSlides: true,
        spaceBetween: 30
      }
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperCoverflowEffect.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperCoverflowEffect.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/swiper.css */ "./node_modules/swiper/css/swiper.css");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/swiper/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["Swiper"],
    SwiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["SwiperSlide"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    BImg: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BImg"]
  },
  data: function data() {
    return {
      codeCoverflowEffect: _code__WEBPACK_IMPORTED_MODULE_4__["codeCoverflowEffect"],

      /* eslint-disable global-require */
      swiperData: [{
        img: __webpack_require__(/*! @/assets/images/banner/banner-35.jpg */ "./resources/js/src/assets/images/banner/banner-35.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-39.jpg */ "./resources/js/src/assets/images/banner/banner-39.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-38.jpg */ "./resources/js/src/assets/images/banner/banner-38.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-37.jpg */ "./resources/js/src/assets/images/banner/banner-37.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-36.jpg */ "./resources/js/src/assets/images/banner/banner-36.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-34.jpg */ "./resources/js/src/assets/images/banner/banner-34.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-33.jpg */ "./resources/js/src/assets/images/banner/banner-33.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-32.jpg */ "./resources/js/src/assets/images/banner/banner-32.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-31.jpg */ "./resources/js/src/assets/images/banner/banner-31.jpg")
      }],

      /* eslint-disable global-require */
      swiperOptions: {
        effect: 'coverflow',
        grabCursor: true,
        centeredSlides: true,
        slidesPerView: 'auto',
        coverflowEffect: {
          rotate: 50,
          stretch: 0,
          depth: 100,
          modifier: 1,
          slideShadows: true
        },
        pagination: {
          el: '.swiper-pagination'
        }
      }
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperCube.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperCube.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/swiper.css */ "./node_modules/swiper/css/swiper.css");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/swiper/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["Swiper"],
    SwiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["SwiperSlide"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    BImg: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BImg"]
  },
  data: function data() {
    return {
      codeCube: _code__WEBPACK_IMPORTED_MODULE_4__["codeCube"],

      /* eslint-disable global-require */
      swiperData: [{
        img: __webpack_require__(/*! @/assets/images/banner/banner-21.jpg */ "./resources/js/src/assets/images/banner/banner-21.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-22.jpg */ "./resources/js/src/assets/images/banner/banner-22.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-23.jpg */ "./resources/js/src/assets/images/banner/banner-23.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-24.jpg */ "./resources/js/src/assets/images/banner/banner-24.jpg")
      }],

      /* eslint-disable global-require */
      swiperOptions: {
        effect: 'cube',
        grabCursor: true,
        cubeEffect: {
          shadow: true,
          slideShadows: true,
          shadowOffset: 20,
          shadowScale: 0.94
        },
        pagination: {
          el: '.swiper-pagination'
        }
      }
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperDefault.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperDefault.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/swiper.css */ "./node_modules/swiper/css/swiper.css");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/swiper/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["Swiper"],
    SwiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["SwiperSlide"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    BImg: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BImg"]
  },
  data: function data() {
    return {
      codeDefault: _code__WEBPACK_IMPORTED_MODULE_4__["codeDefault"],

      /* eslint-disable global-require */
      swiperData: [{
        img: __webpack_require__(/*! @/assets/images/banner/banner-13.jpg */ "./resources/js/src/assets/images/banner/banner-13.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-7.jpg */ "./resources/js/src/assets/images/banner/banner-7.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-4.jpg */ "./resources/js/src/assets/images/banner/banner-4.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-2.jpg */ "./resources/js/src/assets/images/banner/banner-2.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-1.jpg */ "./resources/js/src/assets/images/banner/banner-1.jpg")
      }]
      /* eslint-disable global-require */

    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperFadeEffect.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperFadeEffect.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/swiper.css */ "./node_modules/swiper/css/swiper.css");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/swiper/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["Swiper"],
    SwiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["SwiperSlide"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    BImg: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BImg"]
  },
  data: function data() {
    return {
      codeFadeEffect: _code__WEBPACK_IMPORTED_MODULE_4__["codeFadeEffect"],

      /* eslint-disable global-require */
      swiperData: [{
        img: __webpack_require__(/*! @/assets/images/banner/banner-20.jpg */ "./resources/js/src/assets/images/banner/banner-20.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-19.jpg */ "./resources/js/src/assets/images/banner/banner-19.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-18.jpg */ "./resources/js/src/assets/images/banner/banner-18.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-17.jpg */ "./resources/js/src/assets/images/banner/banner-17.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-16.jpg */ "./resources/js/src/assets/images/banner/banner-16.jpg")
      }],

      /* eslint-disable global-require */
      swiperOptions: {
        spaceBetween: 30,
        effect: 'fade',
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        },
        pagination: {
          el: '.swiper-pagination'
        }
      }
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperGallery.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperGallery.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/swiper.css */ "./node_modules/swiper/css/swiper.css");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/swiper/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["Swiper"],
    SwiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["SwiperSlide"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    BImg: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BImg"]
  },
  data: function data() {
    return {
      codeGallery: _code__WEBPACK_IMPORTED_MODULE_4__["codeGallery"],

      /* eslint-disable global-require */
      swiperData: [{
        img: __webpack_require__(/*! @/assets/images/banner/banner-11.jpg */ "./resources/js/src/assets/images/banner/banner-11.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-12.jpg */ "./resources/js/src/assets/images/banner/banner-12.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-13.jpg */ "./resources/js/src/assets/images/banner/banner-13.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-15.jpg */ "./resources/js/src/assets/images/banner/banner-15.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-16.jpg */ "./resources/js/src/assets/images/banner/banner-16.jpg")
      }],

      /* eslint-disable global-require */
      swiperOptions: {
        loop: true,
        loopedSlides: 5,
        spaceBetween: 10,
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }
      },
      swiperOptionThumbs: {
        loop: true,
        loopedSlides: 5,
        // looped slides should be the same
        spaceBetween: 10,
        centeredSlides: true,
        slidesPerView: 4,
        touchRatio: 0.2,
        slideToClickedSlide: true
      }
    };
  },
  mounted: function mounted() {
    var _this = this;

    this.$nextTick(function () {
      var swiperTop = _this.$refs.swiperTop.$swiper;
      var swiperThumbs = _this.$refs.swiperThumbs.$swiper;
      swiperTop.controller.control = swiperThumbs;
      swiperThumbs.controller.control = swiperTop;
    });
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperLazy.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperLazy.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/swiper.css */ "./node_modules/swiper/css/swiper.css");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/swiper/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["Swiper"],
    SwiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["SwiperSlide"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    BImg: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BImg"]
  },
  data: function data() {
    return {
      codeLazy: _code__WEBPACK_IMPORTED_MODULE_4__["codeLazy"],

      /* eslint-disable global-require */
      swiperData: [{
        img: __webpack_require__(/*! @/assets/images/banner/banner-9.jpg */ "./resources/js/src/assets/images/banner/banner-9.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-8.jpg */ "./resources/js/src/assets/images/banner/banner-8.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-7.jpg */ "./resources/js/src/assets/images/banner/banner-7.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-20.jpg */ "./resources/js/src/assets/images/banner/banner-20.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-5.jpg */ "./resources/js/src/assets/images/banner/banner-5.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-4.jpg */ "./resources/js/src/assets/images/banner/banner-4.jpg")
      }],

      /* eslint-disable global-require */
      swiperOptions: {
        lazy: true,
        pagination: {
          el: '.swiper-pagination',
          clickable: true
        },
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }
      }
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/swiper.css */ "./node_modules/swiper/css/swiper.css");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/swiper/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["Swiper"],
    SwiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["SwiperSlide"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    BImg: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BImg"]
  },
  data: function data() {
    return {
      codeMultiRowSlides: _code__WEBPACK_IMPORTED_MODULE_4__["codeMultiRowSlides"],
      swiperData: [
      /* eslint-disable global-require */
      {
        img: __webpack_require__(/*! @/assets/images/banner/banner-26.jpg */ "./resources/js/src/assets/images/banner/banner-26.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-39.jpg */ "./resources/js/src/assets/images/banner/banner-39.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-28.jpg */ "./resources/js/src/assets/images/banner/banner-28.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-29.jpg */ "./resources/js/src/assets/images/banner/banner-29.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-30.jpg */ "./resources/js/src/assets/images/banner/banner-30.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-31.jpg */ "./resources/js/src/assets/images/banner/banner-31.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-32.jpg */ "./resources/js/src/assets/images/banner/banner-32.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-33.jpg */ "./resources/js/src/assets/images/banner/banner-33.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-34.jpg */ "./resources/js/src/assets/images/banner/banner-34.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-35.jpg */ "./resources/js/src/assets/images/banner/banner-35.jpg")
      }
      /* eslint-disable global-require */
      ],
      swiperOption: {
        slidesPerView: 3,
        slidesPerColumn: 2,
        spaceBetween: 30,
        pagination: {
          el: '.swiper-pagination',
          clickable: true
        },
        breakpoints: {
          1024: {
            slidesPerView: 3,
            spaceBetween: 30
          },
          768: {
            slidesPerView: 2,
            spaceBetween: 30
          },
          640: {
            slidesPerView: 1,
            spaceBetween: 20
          }
        }
      }
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperMultipleSlides.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperMultipleSlides.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/swiper.css */ "./node_modules/swiper/css/swiper.css");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/swiper/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["Swiper"],
    SwiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["SwiperSlide"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    BImg: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BImg"]
  },
  data: function data() {
    return {
      codeMultipleSlides: _code__WEBPACK_IMPORTED_MODULE_4__["codeMultipleSlides"],

      /* eslint-disable global-require */
      swiperData: [{
        img: __webpack_require__(/*! @/assets/images/banner/banner-31.jpg */ "./resources/js/src/assets/images/banner/banner-31.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-32.jpg */ "./resources/js/src/assets/images/banner/banner-32.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-33.jpg */ "./resources/js/src/assets/images/banner/banner-33.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-34.jpg */ "./resources/js/src/assets/images/banner/banner-34.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-35.jpg */ "./resources/js/src/assets/images/banner/banner-35.jpg")
      }],

      /* eslint-disable global-require */
      swiperOptions: {
        slidesPerView: 3,
        spaceBetween: 30,
        pagination: {
          el: '.swiper-pagination',
          clickable: true
        }
      }
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperNavigation.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperNavigation.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/swiper.css */ "./node_modules/swiper/css/swiper.css");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/swiper/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["Swiper"],
    SwiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["SwiperSlide"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    BImg: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BImg"]
  },
  data: function data() {
    return {
      codeNavigation: _code__WEBPACK_IMPORTED_MODULE_4__["codeNavigation"],

      /* eslint-disable global-require */
      swiperData: [{
        img: __webpack_require__(/*! @/assets/images/banner/banner-7.jpg */ "./resources/js/src/assets/images/banner/banner-7.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-4.jpg */ "./resources/js/src/assets/images/banner/banner-4.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-14.jpg */ "./resources/js/src/assets/images/banner/banner-14.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-3.jpg */ "./resources/js/src/assets/images/banner/banner-3.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-2.jpg */ "./resources/js/src/assets/images/banner/banner-2.jpg")
      }],

      /* eslint-disable global-require */
      swiperOptions: {
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }
      }
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperPagination.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperPagination.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/swiper.css */ "./node_modules/swiper/css/swiper.css");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/swiper/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["Swiper"],
    SwiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["SwiperSlide"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    BImg: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BImg"]
  },
  data: function data() {
    return {
      codePagination: _code__WEBPACK_IMPORTED_MODULE_4__["codePagination"],

      /* eslint-disable global-require */
      swiperData: [{
        img: __webpack_require__(/*! @/assets/images/banner/banner-12.jpg */ "./resources/js/src/assets/images/banner/banner-12.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-9.jpg */ "./resources/js/src/assets/images/banner/banner-9.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-8.jpg */ "./resources/js/src/assets/images/banner/banner-8.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-7.jpg */ "./resources/js/src/assets/images/banner/banner-7.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-20.jpg */ "./resources/js/src/assets/images/banner/banner-20.jpg")
      }],

      /* eslint-disable global-require */
      swiperOptions: {
        pagination: {
          el: '.swiper-pagination'
        }
      }
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperParallax.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperParallax.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/swiper.css */ "./node_modules/swiper/css/swiper.css");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/swiper/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BImg: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BImg"],
    Swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_2__["Swiper"],
    SwiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_2__["SwiperSlide"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardText"]
  },
  data: function data() {
    return {
      codeParallax: _code__WEBPACK_IMPORTED_MODULE_4__["codeParallax"],
      swiperData: [{
        title: 'Slide 1',
        subtitle: 'Subtitle',
        text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam dictum mattis velit, sit amet faucibus felis iaculis nec. Nulla laoreet Lorem, ipsum dolor sit amet consectetur..'
      }, {
        title: 'Slide 2',
        subtitle: 'Subtitle',
        text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam dictum mattis velit, sit amet faucibus felis iaculis nec. Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam reiciendis provident atque quod obcaecati voluptatibus ex qui repudiandae sunt dolores. Nulla laoreet justo vitae porttitor porttitor. Suspendisse in sem justo. Integeo. Aenean feugiat non eros quis feugiat.'
      }, {
        title: 'Slide 3',
        subtitle: 'Subtitle',
        text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam dictum mattis velit, sit amet faucibus felis iaculis nec. Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam reiciendis provident atque quod obcaecati voluptatibus ex qui repudiandae sunt dolores. Nulla laoreet justo vitae porttitor porttitor. Suspendisse in sem justo. Integer laoreet magna nec elit suscipit, ac laoreet nibh euismod. Aliquam hendrerit lnt ut libero. Aenean feugiat non eros quis feugiat.'
      }],
      swiperOptions: {
        speed: 600,
        parallax: true,
        pagination: {
          el: '.swiper-pagination',
          clickable: true
        },
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }
      }
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperProgress.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperProgress.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/swiper.css */ "./node_modules/swiper/css/swiper.css");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/swiper/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["Swiper"],
    SwiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["SwiperSlide"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    BImg: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BImg"]
  },
  data: function data() {
    return {
      codeProgress: _code__WEBPACK_IMPORTED_MODULE_4__["codeProgress"],

      /* eslint-disable global-require */
      swiperData: [{
        img: __webpack_require__(/*! @/assets/images/banner/banner-8.jpg */ "./resources/js/src/assets/images/banner/banner-8.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-7.jpg */ "./resources/js/src/assets/images/banner/banner-7.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-20.jpg */ "./resources/js/src/assets/images/banner/banner-20.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-4.jpg */ "./resources/js/src/assets/images/banner/banner-4.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-5.jpg */ "./resources/js/src/assets/images/banner/banner-5.jpg")
      }],

      /* eslint-disable global-require */
      swiperOptions: {
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        },
        pagination: {
          el: '.swiper-pagination',
          type: 'progressbar'
        }
      }
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperResponsive.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperResponsive.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/swiper.css */ "./node_modules/swiper/css/swiper.css");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/swiper/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["Swiper"],
    SwiperSlide: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_1__["SwiperSlide"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    BImg: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BImg"]
  },
  data: function data() {
    return {
      codeResponsive: _code__WEBPACK_IMPORTED_MODULE_4__["codeResponsive"],

      /* eslint-disable global-require */
      swiperData: [{
        img: __webpack_require__(/*! @/assets/images/banner/banner-30.jpg */ "./resources/js/src/assets/images/banner/banner-30.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-31.jpg */ "./resources/js/src/assets/images/banner/banner-31.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-32.jpg */ "./resources/js/src/assets/images/banner/banner-32.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-33.jpg */ "./resources/js/src/assets/images/banner/banner-33.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-34.jpg */ "./resources/js/src/assets/images/banner/banner-34.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-35.jpg */ "./resources/js/src/assets/images/banner/banner-35.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-36.jpg */ "./resources/js/src/assets/images/banner/banner-36.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-37.jpg */ "./resources/js/src/assets/images/banner/banner-37.jpg")
      }, {
        img: __webpack_require__(/*! @/assets/images/banner/banner-38.jpg */ "./resources/js/src/assets/images/banner/banner-38.jpg")
      }],

      /* eslint-disable global-require */
      swiperOptions: {
        slidesPerView: 5,
        spaceBetween: 50,
        pagination: {
          el: '.swiper-pagination',
          clickable: true
        },
        breakpoints: {
          1024: {
            slidesPerView: 4,
            spaceBetween: 40
          },
          768: {
            slidesPerView: 3,
            spaceBetween: 30
          },
          640: {
            slidesPerView: 2,
            spaceBetween: 20
          },
          320: {
            slidesPerView: 1,
            spaceBetween: 10
          }
        }
      }
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperVirtual.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperVirtual.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_fill_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.fill.js */ "./node_modules/core-js/modules/es.array.fill.js");
/* harmony import */ var core_js_modules_es_array_fill_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_fill_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue-awesome-swiper */ "./node_modules/vue-awesome-swiper/dist/vue-awesome-swiper.js");
/* harmony import */ var vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! swiper/css/swiper.css */ "./node_modules/swiper/css/swiper.css");
/* harmony import */ var swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(swiper_css_swiper_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var vue_ripple_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! vue-ripple-directive */ "./node_modules/vue-ripple-directive/src/ripple.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/swiper/code.js");



//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//






/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Swiper: vue_awesome_swiper__WEBPACK_IMPORTED_MODULE_4__["Swiper"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_5__["BButton"]
  },
  directives: {
    Ripple: vue_ripple_directive__WEBPACK_IMPORTED_MODULE_7__["default"]
  },
  data: function data() {
    return {
      codeVirtual: _code__WEBPACK_IMPORTED_MODULE_8__["codeVirtual"],
      slides: [],
      prependNumber: 1,
      appendNumber: 600,
      swiperOptions: {
        slidesPerView: 3,
        centeredSlides: true,
        spaceBetween: 30,
        pagination: {
          el: '.swiper-pagination',
          type: 'fraction'
        },
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        },
        virtual: {
          slides: Array(600).fill('Slide').map(function (item, index) {
            return "".concat(item, " ").concat(index + 1);
          })
        }
      }
    };
  },
  methods: {
    toSlide: function toSlide(index) {
      this.$refs.mySwiper15.$swiper.slideTo(index, 1);
    },
    prependSlides: function prependSlides() {
      this.$refs.mySwiper15.$swiper.virtual.prependSlide(["Slide ".concat(this.prependNumber -= 1), "Slide ".concat(this.prependNumber -= 1)]);
    },
    appendSlide: function appendSlide() {
      this.$refs.mySwiper15.$swiper.virtual.appendSlide("Slide ".concat(this.appendNumber += 1));
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "/*=========================================================================================\n    File Name: ext-component-swiper.scss\n    Description: swiper plugin scss.\n    ----------------------------------------------------------------------------------------\n    Item Name: Vuexy - Vuejs, React, Angular, HTML & Laravel Admin Dashboard Template\n    Author: PIXINVENT\n    Author URL: http://www.themeforest.net/user/pixinvent\n==========================================================================================*/\n/* Swiper css */\n/* ---------- */\n/* swiper slide shadow */\n[dir=ltr] .swiper-container .swiper-shadow {\n  box-shadow: 2px 8px 10px 0 rgba(25, 42, 70, 0.13) !important;\n}\n[dir=rtl] .swiper-container .swiper-shadow {\n  box-shadow: -2px 8px 10px 0 rgba(25, 42, 70, 0.13) !important;\n}\n.swiper-pagination .swiper-pagination-bullet:focus {\n  outline: none;\n}\n[dir] .swiper-pagination .swiper-pagination-bullet.swiper-pagination-bullet-active {\n  background-color: #7367f0;\n}\n[dir] .swiper-pagination.swiper-pagination-progressbar .swiper-pagination-progressbar-fill {\n  background-color: #7367f0;\n}\n.swiper-centered-slides.swiper-container .swiper-slide {\n  font-weight: 500;\n  height: auto;\n  width: auto !important;\n}\n[dir] .swiper-centered-slides.swiper-container .swiper-slide {\n  text-align: center;\n  background-color: #fff;\n  padding: 2rem 5.5rem;\n  cursor: pointer;\n}\n[dir] .swiper-centered-slides.swiper-container .swiper-slide.swiper-slide-active {\n  border: 2px solid #7367f0;\n}\n.swiper-centered-slides.swiper-container .swiper-slide.swiper-slide-active i,\n.swiper-centered-slides.swiper-container .swiper-slide.swiper-slide-active svg {\n  color: #7367f0;\n}\n[dir] .swiper-centered-slides .swiper-button-next:after {\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-chevron-right'%3E%3Cpolyline points='9 18 15 12 9 6'%3E%3C/polyline%3E%3C/svg%3E\");\n}\n[dir] .swiper-centered-slides .swiper-button-prev:after {\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-chevron-left'%3E%3Cpolyline points='15 18 9 12 15 6'%3E%3C/polyline%3E%3C/svg%3E\");\n}\n.swiper-centered-slides .swiper-button-next,\n.swiper-centered-slides .swiper-button-prev {\n  height: 40px !important;\n  width: 40px !important;\n}\n.swiper-centered-slides .swiper-button-next:after,\n.swiper-centered-slides .swiper-button-prev:after {\n  height: 40px !important;\n  width: 40px !important;\n}\n[dir] .swiper-centered-slides .swiper-button-next:after, [dir] .swiper-centered-slides .swiper-button-prev:after {\n  border-radius: 50%;\n  background-color: #7367f0;\n  box-shadow: 0 2px 4px 0 rgba(34, 41, 47, 0.5) !important;\n  background-size: 24px !important;\n}\n[dir] .swiper-centered-slides.swiper-container-rtl .swiper-button-next:after {\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-chevron-left'%3E%3Cpolyline points='15 18 9 12 15 6'%3E%3C/polyline%3E%3C/svg%3E\");\n}\n[dir] .swiper-centered-slides.swiper-container-rtl .swiper-button-prev:after {\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-chevron-right'%3E%3Cpolyline points='9 18 15 12 9 6'%3E%3C/polyline%3E%3C/svg%3E\");\n}\n.swiper-centered-slides-2.swiper-container .swiper-slide {\n  font-weight: 500;\n  height: auto;\n  width: auto !important;\n}\n[dir] .swiper-centered-slides-2.swiper-container .swiper-slide {\n  background-color: #f2f4f4;\n  cursor: pointer;\n}\n.swiper-centered-slides-2.swiper-container .swiper-slide.swiper-slide-active {\n  color: #fff;\n}\n[dir] .swiper-centered-slides-2.swiper-container .swiper-slide.swiper-slide-active {\n  background-color: #7367f0 !important;\n  box-shadow: 0 3px 6px 0 rgba(115, 103, 240, 0.5) !important;\n}\n\n/* cube effect */\n.swiper-cube-effect.swiper-container {\n  width: 300px;\n}\n[dir] .swiper-cube-effect.swiper-container {\n  margin-top: -12px;\n}\n[dir=ltr] .swiper-cube-effect.swiper-container {\n  left: 50%;\n  margin-left: -150px;\n}\n[dir=rtl] .swiper-cube-effect.swiper-container {\n  right: 50%;\n  margin-right: -150px;\n}\n\n/* swiper coverflow slide width */\n.swiper-coverflow.swiper-container .swiper-slide {\n  width: 300px;\n}\n[dir] .gallery-thumbs {\n  padding: 10px 0;\n  background: #22292f;\n}\n.gallery-thumbs .swiper-slide {\n  opacity: 0.4;\n}\n.gallery-thumbs .swiper-slide-thumb-active {\n  opacity: 1;\n}\n[dir] .swiper-parallax .swiper-slide {\n  padding: 2.67rem 4rem;\n}\n.swiper-parallax .swiper-slide .title {\n  font-size: 1.07rem;\n}\n[dir] .swiper-parallax .swiper-slide .title {\n  padding: 0.5rem 0;\n}\n.swiper-parallax .swiper-slide .text {\n  font-size: 1rem;\n}\n.swiper-parallax .parallax-bg {\n  position: absolute;\n  width: 130%;\n}\n.swiper-virtual.swiper-container {\n  height: 300px;\n}\n.swiper-virtual.swiper-container .swiper-slide {\n  /* virtual slides  */\n  font-size: 1.5rem;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n[dir] .swiper-virtual.swiper-container .swiper-slide {\n  background-color: #eee;\n}\n.swiper-button-prev,\n.swiper-button-next,\n.swiper-container-rtl .swiper-button-prev,\n.swiper-container-rtl .swiper-button-next {\n  color: #fff;\n  width: 38px;\n  font-size: 2rem;\n}\n[dir] .swiper-button-prev, [dir] .swiper-button-next, [dir] .swiper-container-rtl .swiper-button-prev, [dir] .swiper-container-rtl .swiper-button-next {\n  background-image: none;\n}\n.swiper-button-prev:focus,\n.swiper-button-next:focus,\n.swiper-container-rtl .swiper-button-prev:focus,\n.swiper-container-rtl .swiper-button-next:focus {\n  outline: none;\n}\n.swiper-button-prev:after {\n  color: #6e6b7b;\n  width: 44px;\n  height: 44px;\n  content: \"\";\n}\n[dir] .swiper-button-prev:after {\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%237367f0' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-chevron-left'%3E%3Cpolyline points='15 18 9 12 15 6'%3E%3C/polyline%3E%3C/svg%3E\");\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: 44px;\n}\n[dir=ltr] .swiper-button-prev:after {\n  padding-right: 1px;\n}\n[dir=rtl] .swiper-button-prev:after {\n  padding-left: 1px;\n}\n.swiper-button-next:after {\n  color: #6e6b7b;\n  width: 44px;\n  height: 44px;\n  content: \"\";\n}\n[dir] .swiper-button-next:after {\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%237367f0' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-chevron-right'%3E%3Cpolyline points='9 18 15 12 9 6'%3E%3C/polyline%3E%3C/svg%3E\");\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: 44px;\n}\n[dir=ltr] .swiper-button-next:after {\n  padding-right: 2px;\n}\n[dir=rtl] .swiper-button-next:after {\n  padding-left: 2px;\n}\n.swiper-container-rtl .swiper-button-prev:after {\n  color: #6e6b7b;\n  width: 44px;\n  height: 44px;\n  content: \"\";\n}\n[dir] .swiper-container-rtl .swiper-button-prev:after {\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%237367f0' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-chevron-right'%3E%3Cpolyline points='9 18 15 12 9 6'%3E%3C/polyline%3E%3C/svg%3E\");\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: 44px;\n}\n.swiper-container-rtl .swiper-button-next:after {\n  color: #6e6b7b;\n  width: 44px;\n  height: 44px;\n  content: \"\";\n}\n[dir] .swiper-container-rtl .swiper-button-next:after {\n  background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%237367f0' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-chevron-left'%3E%3Cpolyline points='15 18 9 12 15 6'%3E%3C/polyline%3E%3C/svg%3E\");\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: 44px;\n}\n@media only screen and (max-width: 768px) {\n.swiper-button-prev {\n    font-size: 1.286rem;\n    top: 55%;\n}\n.swiper-button-prev:after {\n    height: 28px;\n    width: 28px;\n}\n[dir] .swiper-button-prev:after {\n    background-size: 24px;\n}\n.swiper-button-next {\n    font-size: 1.286rem;\n    top: 55%;\n}\n[dir] .swiper-button-next:after {\n    background-size: 24px;\n}\n.swiper-centered-slides .swiper-button-next:after,\n.swiper-centered-slides .swiper-button-prev:after {\n    height: 28px;\n    width: 28px;\n}\n[dir] .swiper-centered-slides .swiper-button-next:after, [dir] .swiper-centered-slides .swiper-button-prev:after {\n    background-size: 18px;\n}\n[dir] .swiper-parallax .swiper-slide {\n    padding: 1rem 1.2rem;\n}\n.swiper-parallax img {\n    height: 100% !important;\n}\n}\n@media only screen and (max-width: 576px) {\n[dir] .swiper-centered-slides.swiper-container .swiper-slide {\n    padding: 1.6rem 2.5rem;\n}\n.swiper-centered-slides.swiper-container .swiper-slide i,\n.swiper-centered-slides.swiper-container .swiper-slide svg {\n    height: 1.07rem !important;\n    width: 1.07rem !important;\n    font-size: 1.07rem !important;\n}\n.swiper-cube-effect.swiper-container {\n    width: 150px;\n}\n[dir=ltr] .swiper-cube-effect.swiper-container {\n    left: 70%;\n}\n[dir=rtl] .swiper-cube-effect.swiper-container {\n    right: 70%;\n}\n[dir] .swiper-parallax .swiper-slide {\n    padding: 1rem 1.3rem;\n}\n.swiper-virtual.swiper-container .swiper-slide {\n    font-size: 1rem;\n}\n}\n[dir] .dark-layout .swiper-container:not(.swiper-parallax) .swiper-slide {\n  background-color: #161d31;\n}\n[dir] .dark-layout .swiper-container.swiper-centered-slides .swiper-slide {\n  background-color: #283046;\n}\n.dark-layout .swiper-container.swiper-parallax .swiper-slide * {\n  color: #6e6b7b;\n}\n.swiper-slide.swiper-slide-active {\n  opacity: 1;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=style&index=0&id=67b582a1&lang=scss&scoped=true&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=style&index=0&id=67b582a1&lang=scss&scoped=true& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".swiper[data-v-67b582a1]  .swiper-wrapper {\n  flex-direction: row !important;\n}\n[dir] .swiper .swiper-slide[data-v-67b582a1] {\n  margin-top: 30px;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=style&index=0&lang=scss&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=style&index=0&lang=scss& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Swiper.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=style&index=0&lang=scss&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=style&index=0&id=67b582a1&lang=scss&scoped=true&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=style&index=0&id=67b582a1&lang=scss&scoped=true& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperMultiRowSlides.vue?vue&type=style&index=0&id=67b582a1&lang=scss&scoped=true& */ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=style&index=0&id=67b582a1&lang=scss&scoped=true&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=template&id=70dd9744&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=template&id=70dd9744& ***!
  \**************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-row",
    [
      _c(
        "b-col",
        { attrs: { cols: "12" } },
        [
          _c("swiper-default"),
          _vm._v(" "),
          _c("swiper-navigation"),
          _vm._v(" "),
          _c("swiper-pagination"),
          _vm._v(" "),
          _c("swiper-progress"),
          _vm._v(" "),
          _c("swiper-multiple-slides"),
          _vm._v(" "),
          _c("swiper-multi-row-slides"),
          _vm._v(" "),
          _c("swiper-centered-slides"),
          _vm._v(" "),
          _c("swiper-centered-slides2"),
          _vm._v(" "),
          _c("swiper-fade-effect"),
          _vm._v(" "),
          _c("swiper-cube"),
          _vm._v(" "),
          _c("swiper-coverflow-effect"),
          _vm._v(" "),
          _c("swiper-autoplay"),
          _vm._v(" "),
          _c("swiper-gallery"),
          _vm._v(" "),
          _c("swiper-parallax"),
          _vm._v(" "),
          _c("swiper-lazy"),
          _vm._v(" "),
          _c("swiper-responsive"),
          _vm._v(" "),
          _c("swiper-virtual"),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperAutoplay.vue?vue&type=template&id=41d5f261&":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperAutoplay.vue?vue&type=template&id=41d5f261& ***!
  \**********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Autoplay" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeAutoplay) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "swiper",
        {
          staticClass: "swiper-autoplay",
          attrs: {
            options: _vm.swiperOptions,
            dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr",
          },
        },
        [
          _vm._l(_vm.swiperData, function (data) {
            return _c(
              "swiper-slide",
              { key: data.img },
              [_c("b-img", { attrs: { src: data.img, fluid: "" } })],
              1
            )
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination",
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-next",
            attrs: { slot: "button-next" },
            slot: "button-next",
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-prev",
            attrs: { slot: "button-prev" },
            slot: "button-prev",
          }),
        ],
        2
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperCenteredSlides.vue?vue&type=template&id=618878b4&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperCenteredSlides.vue?vue&type=template&id=618878b4& ***!
  \****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      staticClass: "bg-transparent shadow-none",
      attrs: { title: "Centered Slides Option-1" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeCenterSlides) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "swiper",
        {
          staticClass: "swiper-centered-slides p-1",
          attrs: {
            options: _vm.swiperOptions,
            dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr",
          },
        },
        [
          _vm._l(_vm.swiperData, function (data) {
            return _c(
              "swiper-slide",
              { key: data.text, staticClass: "rounded swiper-shadow" },
              [
                _c("feather-icon", { attrs: { icon: data.icon, size: "28" } }),
                _vm._v(" "),
                _c("div", { staticClass: "swiper-text pt-md-1 pt-sm-50" }, [
                  _vm._v("\n        " + _vm._s(data.text) + "\n      "),
                ]),
              ],
              1
            )
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-next",
            attrs: { slot: "button-next" },
            slot: "button-next",
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-prev",
            attrs: { slot: "button-prev" },
            slot: "button-prev",
          }),
        ],
        2
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperCenteredSlides2.vue?vue&type=template&id=60c371a4&":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperCenteredSlides2.vue?vue&type=template&id=60c371a4& ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Centered Slides  Option-2" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeCenterSlides2) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "swiper",
        {
          staticClass: "swiper-centered-slides-2 p-1",
          attrs: {
            options: _vm.swiperOptions,
            dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr",
          },
        },
        _vm._l(_vm.swiperData, function (data, index) {
          return _c(
            "swiper-slide",
            {
              key: index,
              staticClass: "rounded swiper-shadow py-1 px-3 d-flex",
            },
            [
              _c("feather-icon", {
                staticClass: "mr-50",
                attrs: { icon: data.icon, size: "18" },
              }),
              _vm._v(" "),
              _c("div", { staticClass: "swiper-text" }, [
                _vm._v("\n        " + _vm._s(data.text) + "\n      "),
              ]),
            ],
            1
          )
        }),
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperCoverflowEffect.vue?vue&type=template&id=534cc048&":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperCoverflowEffect.vue?vue&type=template&id=534cc048& ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "3d Effect Coverflow Effect" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeCoverflowEffect) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "swiper",
        {
          staticClass: "swiper-coverflow",
          attrs: {
            options: _vm.swiperOptions,
            dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr",
          },
        },
        [
          _vm._l(_vm.swiperData, function (data, index) {
            return _c(
              "swiper-slide",
              { key: index },
              [_c("b-img", { attrs: { src: data.img, fluid: "" } })],
              1
            )
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination",
          }),
        ],
        2
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperCube.vue?vue&type=template&id=ad7e319a&":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperCube.vue?vue&type=template&id=ad7e319a& ***!
  \******************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "3-D Cube Effect" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeCube) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "swiper",
        {
          staticClass: "swiper-cube-effect",
          attrs: {
            options: _vm.swiperOptions,
            dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr",
          },
        },
        [
          _vm._l(_vm.swiperData, function (data, index) {
            return _c(
              "swiper-slide",
              { key: index },
              [_c("b-img", { attrs: { src: data.img, fluid: "" } })],
              1
            )
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination swiper-pagination-white",
            attrs: { slot: "pagination" },
            slot: "pagination",
          }),
        ],
        2
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperDefault.vue?vue&type=template&id=574f889a&":
/*!*********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperDefault.vue?vue&type=template&id=574f889a& ***!
  \*********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Default" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeDefault) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "swiper",
        {
          ref: "mySwiper",
          attrs: { dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr" },
        },
        _vm._l(_vm.swiperData, function (data) {
          return _c(
            "swiper-slide",
            { key: data.img },
            [_c("b-img", { attrs: { src: data.img, fluid: "" } })],
            1
          )
        }),
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperFadeEffect.vue?vue&type=template&id=5cdf51ab&":
/*!************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperFadeEffect.vue?vue&type=template&id=5cdf51ab& ***!
  \************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Fade Effect" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeFadeEffect) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "swiper",
        {
          staticClass: "swiper-navigations",
          attrs: {
            options: _vm.swiperOptions,
            dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr",
          },
        },
        [
          _vm._l(_vm.swiperData, function (data, index) {
            return _c(
              "swiper-slide",
              { key: index },
              [_c("b-img", { attrs: { src: data.img, fluid: "" } })],
              1
            )
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-next",
            attrs: { slot: "button-next" },
            slot: "button-next",
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-prev",
            attrs: { slot: "button-prev" },
            slot: "button-prev",
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination",
          }),
        ],
        2
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperGallery.vue?vue&type=template&id=6e47ec44&":
/*!*********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperGallery.vue?vue&type=template&id=6e47ec44& ***!
  \*********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Gallery" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeGallery) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "swiper",
        {
          ref: "swiperTop",
          staticClass: "swiper-gallery gallery-top",
          attrs: {
            options: _vm.swiperOptions,
            dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr",
          },
        },
        [
          _vm._l(_vm.swiperData, function (data, index) {
            return _c(
              "swiper-slide",
              { key: index },
              [_c("b-img", { attrs: { src: data.img, fluid: "" } })],
              1
            )
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-next swiper-button-white",
            attrs: { slot: "button-next" },
            slot: "button-next",
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-prev swiper-button-white",
            attrs: { slot: "button-prev" },
            slot: "button-prev",
          }),
        ],
        2
      ),
      _vm._v(" "),
      _c(
        "swiper",
        {
          ref: "swiperThumbs",
          staticClass: "swiper gallery-thumbs",
          attrs: { options: _vm.swiperOptionThumbs },
        },
        _vm._l(_vm.swiperData, function (data, index) {
          return _c(
            "swiper-slide",
            { key: index },
            [_c("b-img", { attrs: { src: data.img, fluid: "" } })],
            1
          )
        }),
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperLazy.vue?vue&type=template&id=583cfef2&":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperLazy.vue?vue&type=template&id=583cfef2& ***!
  \******************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Lazy Loading" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeLazy) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "swiper",
        {
          staticClass: "swiper-lazy-loading",
          attrs: {
            options: _vm.swiperOptions,
            dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr",
          },
        },
        [
          _vm._l(_vm.swiperData, function (data, index) {
            return _c(
              "swiper-slide",
              { key: index },
              [
                _c("b-img", {
                  staticClass: "swiper-lazy",
                  attrs: { src: data.img, fluid: "" },
                }),
                _vm._v(" "),
                _c("div", {
                  staticClass:
                    "swiper-lazy-preloader swiper-lazy-preloader-white",
                }),
              ],
              1
            )
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination",
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-next",
            attrs: { slot: "button-next" },
            slot: "button-next",
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-prev",
            attrs: { slot: "button-prev" },
            slot: "button-prev",
          }),
        ],
        2
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=template&id=67b582a1&scoped=true&":
/*!****************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=template&id=67b582a1&scoped=true& ***!
  \****************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Multi Row Slides Layout" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeMultiRowSlides) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "swiper",
        {
          staticClass: "swiper",
          attrs: {
            options: _vm.swiperOption,
            dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr",
          },
        },
        [
          _vm._l(_vm.swiperData, function (data, index) {
            return _c(
              "swiper-slide",
              { key: index },
              [_c("b-img", { attrs: { src: data.img, fluid: "" } })],
              1
            )
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination",
          }),
        ],
        2
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperMultipleSlides.vue?vue&type=template&id=683277e0&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperMultipleSlides.vue?vue&type=template&id=683277e0& ***!
  \****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Multiple Slides Per View" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeMultipleSlides) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "swiper",
        {
          staticClass: "swiper-multiple",
          attrs: {
            options: _vm.swiperOptions,
            dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr",
          },
        },
        [
          _vm._l(_vm.swiperData, function (data, index) {
            return _c(
              "swiper-slide",
              { key: index },
              [_c("b-img", { attrs: { src: data.img, fluid: "" } })],
              1
            )
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination",
          }),
        ],
        2
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperNavigation.vue?vue&type=template&id=6c57e112&":
/*!************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperNavigation.vue?vue&type=template&id=6c57e112& ***!
  \************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Navigations" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeNavigation) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "swiper",
        {
          staticClass: "swiper-navigations",
          attrs: {
            options: _vm.swiperOptions,
            dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr",
          },
        },
        [
          _vm._l(_vm.swiperData, function (data, index) {
            return _c(
              "swiper-slide",
              { key: index },
              [_c("b-img", { attrs: { src: data.img, fluid: "" } })],
              1
            )
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-next",
            attrs: { slot: "button-next" },
            slot: "button-next",
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-prev",
            attrs: { slot: "button-prev" },
            slot: "button-prev",
          }),
        ],
        2
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperPagination.vue?vue&type=template&id=6aacdb98&":
/*!************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperPagination.vue?vue&type=template&id=6aacdb98& ***!
  \************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Pagination" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codePagination) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "swiper",
        {
          staticClass: "swiper-paginations",
          attrs: {
            options: _vm.swiperOptions,
            dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr",
          },
        },
        [
          _vm._l(_vm.swiperData, function (data, index) {
            return _c(
              "swiper-slide",
              { key: index },
              [_c("b-img", { attrs: { src: data.img, fluid: "" } })],
              1
            )
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination",
          }),
        ],
        2
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperParallax.vue?vue&type=template&id=6f7cec95&":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperParallax.vue?vue&type=template&id=6f7cec95& ***!
  \**********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Parallax" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeParallax) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "swiper",
        {
          staticClass: "swiper-parallax",
          attrs: {
            options: _vm.swiperOptions,
            dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr",
          },
        },
        [
          _c(
            "div",
            {
              staticClass: "parallax-bg",
              attrs: { slot: "parallax-bg", "data-swiper-parallax": "-23%" },
              slot: "parallax-bg",
            },
            [
              _c("b-img", {
                staticClass: "img-fluid",
                attrs: {
                  src: __webpack_require__(/*! @/assets/images/banner/parallax-4.jpg */ "./resources/js/src/assets/images/banner/parallax-4.jpg"),
                  alt: "banner",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _vm._l(_vm.swiperData, function (data, index) {
            return _c("swiper-slide", { key: index }, [
              _c(
                "div",
                {
                  staticClass: "title",
                  attrs: { "data-swiper-parallax": "-300" },
                },
                [_vm._v("\n        " + _vm._s(data.title) + "\n      ")]
              ),
              _vm._v(" "),
              _c(
                "div",
                {
                  staticClass: "subtitle",
                  attrs: { "data-swiper-parallax": "-200" },
                },
                [_vm._v("\n        " + _vm._s(data.subtitle) + "\n      ")]
              ),
              _vm._v(" "),
              _c(
                "div",
                {
                  staticClass: "text",
                  attrs: { "data-swiper-parallax": "-100" },
                },
                [
                  _c("b-card-text", [
                    _vm._v("\n          " + _vm._s(data.text) + "\n        "),
                  ]),
                ],
                1
              ),
            ])
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination",
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-next",
            attrs: { slot: "button-next" },
            slot: "button-next",
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-prev",
            attrs: { slot: "button-prev" },
            slot: "button-prev",
          }),
        ],
        2
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperProgress.vue?vue&type=template&id=0ad7462b&":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperProgress.vue?vue&type=template&id=0ad7462b& ***!
  \**********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Progress" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeProgress) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "swiper",
        {
          staticClass: "swiper-progress",
          attrs: {
            options: _vm.swiperOptions,
            dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr",
          },
        },
        [
          _vm._l(_vm.swiperData, function (data, index) {
            return _c(
              "swiper-slide",
              { key: index },
              [_c("b-img", { attrs: { src: data.img, fluid: "" } })],
              1
            )
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-next",
            attrs: { slot: "button-next" },
            slot: "button-next",
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-prev",
            attrs: { slot: "button-prev" },
            slot: "button-prev",
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination",
          }),
        ],
        2
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperResponsive.vue?vue&type=template&id=765e2cb2&":
/*!************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperResponsive.vue?vue&type=template&id=765e2cb2& ***!
  \************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Responsive Breakpoints" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeResponsive) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "swiper",
        {
          staticClass: "swiper-responsive-breakpoints",
          attrs: {
            options: _vm.swiperOptions,
            dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr",
          },
        },
        [
          _vm._l(_vm.swiperData, function (data, index) {
            return _c(
              "swiper-slide",
              { key: index },
              [_c("b-img", { attrs: { src: data.img, fluid: "" } })],
              1
            )
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination",
          }),
        ],
        2
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperVirtual.vue?vue&type=template&id=996fe106&":
/*!*********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/swiper/SwiperVirtual.vue?vue&type=template&id=996fe106& ***!
  \*********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Virtual Slides" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeVirtual) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "swiper",
        {
          ref: "mySwiper15",
          staticClass: "swiper-virtual",
          attrs: {
            options: _vm.swiperOptions,
            dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr",
          },
        },
        [
          _c("div", {
            staticClass: "swiper-pagination",
            attrs: { slot: "pagination" },
            slot: "pagination",
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-next",
            attrs: { slot: "button-next" },
            slot: "button-next",
          }),
          _vm._v(" "),
          _c("div", {
            staticClass: "swiper-button-prev",
            attrs: { slot: "button-prev" },
            slot: "button-prev",
          }),
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "demo-inline-spacing justify-content-center" },
        [
          _c(
            "b-button",
            {
              directives: [
                {
                  name: "ripple",
                  rawName: "v-ripple.400",
                  value: "rgba(113, 102, 240, 0.15)",
                  expression: "'rgba(113, 102, 240, 0.15)'",
                  modifiers: { 400: true },
                },
              ],
              staticClass: "font-small-3",
              attrs: { variant: "outline-primary" },
              on: {
                click: function ($event) {
                  $event.preventDefault()
                  return _vm.prependSlides.apply(null, arguments)
                },
              },
            },
            [_vm._v("\n      Prepend 2 Slides\n    ")]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              directives: [
                {
                  name: "ripple",
                  rawName: "v-ripple.400",
                  value: "rgba(113, 102, 240, 0.15)",
                  expression: "'rgba(113, 102, 240, 0.15)'",
                  modifiers: { 400: true },
                },
              ],
              staticClass: "font-small-3",
              attrs: { variant: "outline-primary" },
              on: {
                click: function ($event) {
                  $event.preventDefault()
                  return _vm.toSlide(0)
                },
              },
            },
            [_vm._v("\n      Slide 1\n    ")]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              directives: [
                {
                  name: "ripple",
                  rawName: "v-ripple.400",
                  value: "rgba(113, 102, 240, 0.15)",
                  expression: "'rgba(113, 102, 240, 0.15)'",
                  modifiers: { 400: true },
                },
              ],
              staticClass: "font-small-3",
              attrs: { variant: "outline-primary" },
              on: {
                click: function ($event) {
                  $event.preventDefault()
                  return _vm.toSlide(250)
                },
              },
            },
            [_vm._v("\n      Slide 250\n    ")]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              directives: [
                {
                  name: "ripple",
                  rawName: "v-ripple.400",
                  value: "rgba(113, 102, 240, 0.15)",
                  expression: "'rgba(113, 102, 240, 0.15)'",
                  modifiers: { 400: true },
                },
              ],
              staticClass: "font-sm-3",
              attrs: { variant: "outline-primary" },
              on: {
                click: function ($event) {
                  $event.preventDefault()
                  return _vm.toSlide(500)
                },
              },
            },
            [_vm._v("\n      Slide 500\n    ")]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              directives: [
                {
                  name: "ripple",
                  rawName: "v-ripple.400",
                  value: "rgba(113, 102, 240, 0.15)",
                  expression: "'rgba(113, 102, 240, 0.15)'",
                  modifiers: { 400: true },
                },
              ],
              staticClass: "font-small-3",
              attrs: { variant: "outline-primary" },
              on: {
                click: function ($event) {
                  $event.preventDefault()
                  return _vm.appendSlide.apply(null, arguments)
                },
              },
            },
            [_vm._v("\n      Append Slide\n    ")]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-1.jpg":
/*!************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-1.jpg ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-1.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-10.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-10.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-10.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-11.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-11.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-11.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-13.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-13.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-13.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-14.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-14.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-14.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-15.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-15.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-15.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-16.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-16.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-16.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-17.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-17.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-17.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-18.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-18.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-18.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-19.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-19.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-19.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-2.jpg":
/*!************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-2.jpg ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-2.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-20.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-20.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-20.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-21.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-21.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-21.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-23.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-23.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-23.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-24.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-24.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-24.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-26.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-26.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-26.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-28.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-28.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-28.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-29.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-29.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-29.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-3.jpg":
/*!************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-3.jpg ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-3.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-30.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-30.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-30.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-31.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-31.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-31.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-32.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-32.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-32.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-33.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-33.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-33.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-34.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-34.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-34.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-36.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-36.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-36.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-37.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-37.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-37.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-38.jpg":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-38.jpg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-38.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-4.jpg":
/*!************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-4.jpg ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-4.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-5.jpg":
/*!************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-5.jpg ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-5.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-7.jpg":
/*!************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-7.jpg ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-7.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-8.jpg":
/*!************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-8.jpg ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-8.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/banner-9.jpg":
/*!************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/banner-9.jpg ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/banner-9.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/banner/parallax-4.jpg":
/*!**************************************************************!*\
  !*** ./resources/js/src/assets/images/banner/parallax-4.jpg ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channable/resources/js/src/assets/images/banner/parallax-4.jpg";

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/Swiper.vue":
/*!*************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/Swiper.vue ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Swiper_vue_vue_type_template_id_70dd9744___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Swiper.vue?vue&type=template&id=70dd9744& */ "./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=template&id=70dd9744&");
/* harmony import */ var _Swiper_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Swiper.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Swiper_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Swiper.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Swiper_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Swiper_vue_vue_type_template_id_70dd9744___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Swiper_vue_vue_type_template_id_70dd9744___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/Swiper.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=script&lang=js&":
/*!**************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Swiper_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Swiper.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Swiper_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Swiper_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/style-loader!../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Swiper.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Swiper_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Swiper_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Swiper_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Swiper_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=template&id=70dd9744&":
/*!********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=template&id=70dd9744& ***!
  \********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Swiper_vue_vue_type_template_id_70dd9744___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Swiper.vue?vue&type=template&id=70dd9744& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/Swiper.vue?vue&type=template&id=70dd9744&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Swiper_vue_vue_type_template_id_70dd9744___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Swiper_vue_vue_type_template_id_70dd9744___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperAutoplay.vue":
/*!*********************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperAutoplay.vue ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SwiperAutoplay_vue_vue_type_template_id_41d5f261___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SwiperAutoplay.vue?vue&type=template&id=41d5f261& */ "./resources/js/src/views/extensions/swiper/SwiperAutoplay.vue?vue&type=template&id=41d5f261&");
/* harmony import */ var _SwiperAutoplay_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperAutoplay.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/SwiperAutoplay.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SwiperAutoplay_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SwiperAutoplay_vue_vue_type_template_id_41d5f261___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SwiperAutoplay_vue_vue_type_template_id_41d5f261___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/SwiperAutoplay.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperAutoplay.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperAutoplay.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperAutoplay_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperAutoplay.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperAutoplay.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperAutoplay_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperAutoplay.vue?vue&type=template&id=41d5f261&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperAutoplay.vue?vue&type=template&id=41d5f261& ***!
  \****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperAutoplay_vue_vue_type_template_id_41d5f261___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperAutoplay.vue?vue&type=template&id=41d5f261& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperAutoplay.vue?vue&type=template&id=41d5f261&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperAutoplay_vue_vue_type_template_id_41d5f261___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperAutoplay_vue_vue_type_template_id_41d5f261___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperCenteredSlides.vue":
/*!***************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperCenteredSlides.vue ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SwiperCenteredSlides_vue_vue_type_template_id_618878b4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SwiperCenteredSlides.vue?vue&type=template&id=618878b4& */ "./resources/js/src/views/extensions/swiper/SwiperCenteredSlides.vue?vue&type=template&id=618878b4&");
/* harmony import */ var _SwiperCenteredSlides_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperCenteredSlides.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/SwiperCenteredSlides.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SwiperCenteredSlides_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SwiperCenteredSlides_vue_vue_type_template_id_618878b4___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SwiperCenteredSlides_vue_vue_type_template_id_618878b4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/SwiperCenteredSlides.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperCenteredSlides.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperCenteredSlides.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCenteredSlides_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperCenteredSlides.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperCenteredSlides.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCenteredSlides_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperCenteredSlides.vue?vue&type=template&id=618878b4&":
/*!**********************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperCenteredSlides.vue?vue&type=template&id=618878b4& ***!
  \**********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCenteredSlides_vue_vue_type_template_id_618878b4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperCenteredSlides.vue?vue&type=template&id=618878b4& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperCenteredSlides.vue?vue&type=template&id=618878b4&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCenteredSlides_vue_vue_type_template_id_618878b4___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCenteredSlides_vue_vue_type_template_id_618878b4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperCenteredSlides2.vue":
/*!****************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperCenteredSlides2.vue ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SwiperCenteredSlides2_vue_vue_type_template_id_60c371a4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SwiperCenteredSlides2.vue?vue&type=template&id=60c371a4& */ "./resources/js/src/views/extensions/swiper/SwiperCenteredSlides2.vue?vue&type=template&id=60c371a4&");
/* harmony import */ var _SwiperCenteredSlides2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperCenteredSlides2.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/SwiperCenteredSlides2.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SwiperCenteredSlides2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SwiperCenteredSlides2_vue_vue_type_template_id_60c371a4___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SwiperCenteredSlides2_vue_vue_type_template_id_60c371a4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/SwiperCenteredSlides2.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperCenteredSlides2.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperCenteredSlides2.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCenteredSlides2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperCenteredSlides2.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperCenteredSlides2.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCenteredSlides2_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperCenteredSlides2.vue?vue&type=template&id=60c371a4&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperCenteredSlides2.vue?vue&type=template&id=60c371a4& ***!
  \***********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCenteredSlides2_vue_vue_type_template_id_60c371a4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperCenteredSlides2.vue?vue&type=template&id=60c371a4& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperCenteredSlides2.vue?vue&type=template&id=60c371a4&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCenteredSlides2_vue_vue_type_template_id_60c371a4___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCenteredSlides2_vue_vue_type_template_id_60c371a4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperCoverflowEffect.vue":
/*!****************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperCoverflowEffect.vue ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SwiperCoverflowEffect_vue_vue_type_template_id_534cc048___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SwiperCoverflowEffect.vue?vue&type=template&id=534cc048& */ "./resources/js/src/views/extensions/swiper/SwiperCoverflowEffect.vue?vue&type=template&id=534cc048&");
/* harmony import */ var _SwiperCoverflowEffect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperCoverflowEffect.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/SwiperCoverflowEffect.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SwiperCoverflowEffect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SwiperCoverflowEffect_vue_vue_type_template_id_534cc048___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SwiperCoverflowEffect_vue_vue_type_template_id_534cc048___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/SwiperCoverflowEffect.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperCoverflowEffect.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperCoverflowEffect.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCoverflowEffect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperCoverflowEffect.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperCoverflowEffect.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCoverflowEffect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperCoverflowEffect.vue?vue&type=template&id=534cc048&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperCoverflowEffect.vue?vue&type=template&id=534cc048& ***!
  \***********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCoverflowEffect_vue_vue_type_template_id_534cc048___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperCoverflowEffect.vue?vue&type=template&id=534cc048& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperCoverflowEffect.vue?vue&type=template&id=534cc048&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCoverflowEffect_vue_vue_type_template_id_534cc048___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCoverflowEffect_vue_vue_type_template_id_534cc048___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperCube.vue":
/*!*****************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperCube.vue ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SwiperCube_vue_vue_type_template_id_ad7e319a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SwiperCube.vue?vue&type=template&id=ad7e319a& */ "./resources/js/src/views/extensions/swiper/SwiperCube.vue?vue&type=template&id=ad7e319a&");
/* harmony import */ var _SwiperCube_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperCube.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/SwiperCube.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SwiperCube_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SwiperCube_vue_vue_type_template_id_ad7e319a___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SwiperCube_vue_vue_type_template_id_ad7e319a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/SwiperCube.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperCube.vue?vue&type=script&lang=js&":
/*!******************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperCube.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCube_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperCube.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperCube.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCube_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperCube.vue?vue&type=template&id=ad7e319a&":
/*!************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperCube.vue?vue&type=template&id=ad7e319a& ***!
  \************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCube_vue_vue_type_template_id_ad7e319a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperCube.vue?vue&type=template&id=ad7e319a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperCube.vue?vue&type=template&id=ad7e319a&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCube_vue_vue_type_template_id_ad7e319a___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperCube_vue_vue_type_template_id_ad7e319a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperDefault.vue":
/*!********************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperDefault.vue ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SwiperDefault_vue_vue_type_template_id_574f889a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SwiperDefault.vue?vue&type=template&id=574f889a& */ "./resources/js/src/views/extensions/swiper/SwiperDefault.vue?vue&type=template&id=574f889a&");
/* harmony import */ var _SwiperDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperDefault.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/SwiperDefault.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SwiperDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SwiperDefault_vue_vue_type_template_id_574f889a___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SwiperDefault_vue_vue_type_template_id_574f889a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/SwiperDefault.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperDefault.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperDefault.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperDefault.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperDefault.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperDefault.vue?vue&type=template&id=574f889a&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperDefault.vue?vue&type=template&id=574f889a& ***!
  \***************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperDefault_vue_vue_type_template_id_574f889a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperDefault.vue?vue&type=template&id=574f889a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperDefault.vue?vue&type=template&id=574f889a&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperDefault_vue_vue_type_template_id_574f889a___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperDefault_vue_vue_type_template_id_574f889a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperFadeEffect.vue":
/*!***********************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperFadeEffect.vue ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SwiperFadeEffect_vue_vue_type_template_id_5cdf51ab___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SwiperFadeEffect.vue?vue&type=template&id=5cdf51ab& */ "./resources/js/src/views/extensions/swiper/SwiperFadeEffect.vue?vue&type=template&id=5cdf51ab&");
/* harmony import */ var _SwiperFadeEffect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperFadeEffect.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/SwiperFadeEffect.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SwiperFadeEffect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SwiperFadeEffect_vue_vue_type_template_id_5cdf51ab___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SwiperFadeEffect_vue_vue_type_template_id_5cdf51ab___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/SwiperFadeEffect.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperFadeEffect.vue?vue&type=script&lang=js&":
/*!************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperFadeEffect.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperFadeEffect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperFadeEffect.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperFadeEffect.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperFadeEffect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperFadeEffect.vue?vue&type=template&id=5cdf51ab&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperFadeEffect.vue?vue&type=template&id=5cdf51ab& ***!
  \******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperFadeEffect_vue_vue_type_template_id_5cdf51ab___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperFadeEffect.vue?vue&type=template&id=5cdf51ab& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperFadeEffect.vue?vue&type=template&id=5cdf51ab&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperFadeEffect_vue_vue_type_template_id_5cdf51ab___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperFadeEffect_vue_vue_type_template_id_5cdf51ab___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperGallery.vue":
/*!********************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperGallery.vue ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SwiperGallery_vue_vue_type_template_id_6e47ec44___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SwiperGallery.vue?vue&type=template&id=6e47ec44& */ "./resources/js/src/views/extensions/swiper/SwiperGallery.vue?vue&type=template&id=6e47ec44&");
/* harmony import */ var _SwiperGallery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperGallery.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/SwiperGallery.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SwiperGallery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SwiperGallery_vue_vue_type_template_id_6e47ec44___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SwiperGallery_vue_vue_type_template_id_6e47ec44___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/SwiperGallery.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperGallery.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperGallery.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperGallery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperGallery.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperGallery.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperGallery_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperGallery.vue?vue&type=template&id=6e47ec44&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperGallery.vue?vue&type=template&id=6e47ec44& ***!
  \***************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperGallery_vue_vue_type_template_id_6e47ec44___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperGallery.vue?vue&type=template&id=6e47ec44& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperGallery.vue?vue&type=template&id=6e47ec44&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperGallery_vue_vue_type_template_id_6e47ec44___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperGallery_vue_vue_type_template_id_6e47ec44___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperLazy.vue":
/*!*****************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperLazy.vue ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SwiperLazy_vue_vue_type_template_id_583cfef2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SwiperLazy.vue?vue&type=template&id=583cfef2& */ "./resources/js/src/views/extensions/swiper/SwiperLazy.vue?vue&type=template&id=583cfef2&");
/* harmony import */ var _SwiperLazy_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperLazy.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/SwiperLazy.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SwiperLazy_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SwiperLazy_vue_vue_type_template_id_583cfef2___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SwiperLazy_vue_vue_type_template_id_583cfef2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/SwiperLazy.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperLazy.vue?vue&type=script&lang=js&":
/*!******************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperLazy.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperLazy_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperLazy.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperLazy.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperLazy_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperLazy.vue?vue&type=template&id=583cfef2&":
/*!************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperLazy.vue?vue&type=template&id=583cfef2& ***!
  \************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperLazy_vue_vue_type_template_id_583cfef2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperLazy.vue?vue&type=template&id=583cfef2& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperLazy.vue?vue&type=template&id=583cfef2&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperLazy_vue_vue_type_template_id_583cfef2___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperLazy_vue_vue_type_template_id_583cfef2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue":
/*!***************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SwiperMultiRowSlides_vue_vue_type_template_id_67b582a1_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SwiperMultiRowSlides.vue?vue&type=template&id=67b582a1&scoped=true& */ "./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=template&id=67b582a1&scoped=true&");
/* harmony import */ var _SwiperMultiRowSlides_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperMultiRowSlides.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _SwiperMultiRowSlides_vue_vue_type_style_index_0_id_67b582a1_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SwiperMultiRowSlides.vue?vue&type=style&index=0&id=67b582a1&lang=scss&scoped=true& */ "./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=style&index=0&id=67b582a1&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _SwiperMultiRowSlides_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SwiperMultiRowSlides_vue_vue_type_template_id_67b582a1_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SwiperMultiRowSlides_vue_vue_type_template_id_67b582a1_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "67b582a1",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperMultiRowSlides_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperMultiRowSlides.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperMultiRowSlides_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=style&index=0&id=67b582a1&lang=scss&scoped=true&":
/*!*************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=style&index=0&id=67b582a1&lang=scss&scoped=true& ***!
  \*************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperMultiRowSlides_vue_vue_type_style_index_0_id_67b582a1_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/style-loader!../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperMultiRowSlides.vue?vue&type=style&index=0&id=67b582a1&lang=scss&scoped=true& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=style&index=0&id=67b582a1&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperMultiRowSlides_vue_vue_type_style_index_0_id_67b582a1_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperMultiRowSlides_vue_vue_type_style_index_0_id_67b582a1_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperMultiRowSlides_vue_vue_type_style_index_0_id_67b582a1_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperMultiRowSlides_vue_vue_type_style_index_0_id_67b582a1_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=template&id=67b582a1&scoped=true&":
/*!**********************************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=template&id=67b582a1&scoped=true& ***!
  \**********************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperMultiRowSlides_vue_vue_type_template_id_67b582a1_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperMultiRowSlides.vue?vue&type=template&id=67b582a1&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperMultiRowSlides.vue?vue&type=template&id=67b582a1&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperMultiRowSlides_vue_vue_type_template_id_67b582a1_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperMultiRowSlides_vue_vue_type_template_id_67b582a1_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperMultipleSlides.vue":
/*!***************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperMultipleSlides.vue ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SwiperMultipleSlides_vue_vue_type_template_id_683277e0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SwiperMultipleSlides.vue?vue&type=template&id=683277e0& */ "./resources/js/src/views/extensions/swiper/SwiperMultipleSlides.vue?vue&type=template&id=683277e0&");
/* harmony import */ var _SwiperMultipleSlides_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperMultipleSlides.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/SwiperMultipleSlides.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SwiperMultipleSlides_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SwiperMultipleSlides_vue_vue_type_template_id_683277e0___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SwiperMultipleSlides_vue_vue_type_template_id_683277e0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/SwiperMultipleSlides.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperMultipleSlides.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperMultipleSlides.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperMultipleSlides_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperMultipleSlides.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperMultipleSlides.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperMultipleSlides_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperMultipleSlides.vue?vue&type=template&id=683277e0&":
/*!**********************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperMultipleSlides.vue?vue&type=template&id=683277e0& ***!
  \**********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperMultipleSlides_vue_vue_type_template_id_683277e0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperMultipleSlides.vue?vue&type=template&id=683277e0& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperMultipleSlides.vue?vue&type=template&id=683277e0&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperMultipleSlides_vue_vue_type_template_id_683277e0___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperMultipleSlides_vue_vue_type_template_id_683277e0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperNavigation.vue":
/*!***********************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperNavigation.vue ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SwiperNavigation_vue_vue_type_template_id_6c57e112___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SwiperNavigation.vue?vue&type=template&id=6c57e112& */ "./resources/js/src/views/extensions/swiper/SwiperNavigation.vue?vue&type=template&id=6c57e112&");
/* harmony import */ var _SwiperNavigation_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperNavigation.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/SwiperNavigation.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SwiperNavigation_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SwiperNavigation_vue_vue_type_template_id_6c57e112___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SwiperNavigation_vue_vue_type_template_id_6c57e112___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/SwiperNavigation.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperNavigation.vue?vue&type=script&lang=js&":
/*!************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperNavigation.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperNavigation_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperNavigation.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperNavigation.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperNavigation_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperNavigation.vue?vue&type=template&id=6c57e112&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperNavigation.vue?vue&type=template&id=6c57e112& ***!
  \******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperNavigation_vue_vue_type_template_id_6c57e112___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperNavigation.vue?vue&type=template&id=6c57e112& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperNavigation.vue?vue&type=template&id=6c57e112&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperNavigation_vue_vue_type_template_id_6c57e112___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperNavigation_vue_vue_type_template_id_6c57e112___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperPagination.vue":
/*!***********************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperPagination.vue ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SwiperPagination_vue_vue_type_template_id_6aacdb98___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SwiperPagination.vue?vue&type=template&id=6aacdb98& */ "./resources/js/src/views/extensions/swiper/SwiperPagination.vue?vue&type=template&id=6aacdb98&");
/* harmony import */ var _SwiperPagination_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperPagination.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/SwiperPagination.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SwiperPagination_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SwiperPagination_vue_vue_type_template_id_6aacdb98___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SwiperPagination_vue_vue_type_template_id_6aacdb98___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/SwiperPagination.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperPagination.vue?vue&type=script&lang=js&":
/*!************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperPagination.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperPagination_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperPagination.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperPagination.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperPagination_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperPagination.vue?vue&type=template&id=6aacdb98&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperPagination.vue?vue&type=template&id=6aacdb98& ***!
  \******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperPagination_vue_vue_type_template_id_6aacdb98___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperPagination.vue?vue&type=template&id=6aacdb98& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperPagination.vue?vue&type=template&id=6aacdb98&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperPagination_vue_vue_type_template_id_6aacdb98___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperPagination_vue_vue_type_template_id_6aacdb98___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperParallax.vue":
/*!*********************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperParallax.vue ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SwiperParallax_vue_vue_type_template_id_6f7cec95___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SwiperParallax.vue?vue&type=template&id=6f7cec95& */ "./resources/js/src/views/extensions/swiper/SwiperParallax.vue?vue&type=template&id=6f7cec95&");
/* harmony import */ var _SwiperParallax_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperParallax.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/SwiperParallax.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SwiperParallax_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SwiperParallax_vue_vue_type_template_id_6f7cec95___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SwiperParallax_vue_vue_type_template_id_6f7cec95___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/SwiperParallax.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperParallax.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperParallax.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperParallax_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperParallax.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperParallax.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperParallax_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperParallax.vue?vue&type=template&id=6f7cec95&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperParallax.vue?vue&type=template&id=6f7cec95& ***!
  \****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperParallax_vue_vue_type_template_id_6f7cec95___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperParallax.vue?vue&type=template&id=6f7cec95& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperParallax.vue?vue&type=template&id=6f7cec95&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperParallax_vue_vue_type_template_id_6f7cec95___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperParallax_vue_vue_type_template_id_6f7cec95___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperProgress.vue":
/*!*********************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperProgress.vue ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SwiperProgress_vue_vue_type_template_id_0ad7462b___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SwiperProgress.vue?vue&type=template&id=0ad7462b& */ "./resources/js/src/views/extensions/swiper/SwiperProgress.vue?vue&type=template&id=0ad7462b&");
/* harmony import */ var _SwiperProgress_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperProgress.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/SwiperProgress.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SwiperProgress_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SwiperProgress_vue_vue_type_template_id_0ad7462b___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SwiperProgress_vue_vue_type_template_id_0ad7462b___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/SwiperProgress.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperProgress.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperProgress.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperProgress_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperProgress.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperProgress.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperProgress_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperProgress.vue?vue&type=template&id=0ad7462b&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperProgress.vue?vue&type=template&id=0ad7462b& ***!
  \****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperProgress_vue_vue_type_template_id_0ad7462b___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperProgress.vue?vue&type=template&id=0ad7462b& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperProgress.vue?vue&type=template&id=0ad7462b&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperProgress_vue_vue_type_template_id_0ad7462b___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperProgress_vue_vue_type_template_id_0ad7462b___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperResponsive.vue":
/*!***********************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperResponsive.vue ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SwiperResponsive_vue_vue_type_template_id_765e2cb2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SwiperResponsive.vue?vue&type=template&id=765e2cb2& */ "./resources/js/src/views/extensions/swiper/SwiperResponsive.vue?vue&type=template&id=765e2cb2&");
/* harmony import */ var _SwiperResponsive_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperResponsive.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/SwiperResponsive.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SwiperResponsive_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SwiperResponsive_vue_vue_type_template_id_765e2cb2___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SwiperResponsive_vue_vue_type_template_id_765e2cb2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/SwiperResponsive.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperResponsive.vue?vue&type=script&lang=js&":
/*!************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperResponsive.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperResponsive_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperResponsive.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperResponsive.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperResponsive_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperResponsive.vue?vue&type=template&id=765e2cb2&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperResponsive.vue?vue&type=template&id=765e2cb2& ***!
  \******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperResponsive_vue_vue_type_template_id_765e2cb2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperResponsive.vue?vue&type=template&id=765e2cb2& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperResponsive.vue?vue&type=template&id=765e2cb2&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperResponsive_vue_vue_type_template_id_765e2cb2___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperResponsive_vue_vue_type_template_id_765e2cb2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperVirtual.vue":
/*!********************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperVirtual.vue ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SwiperVirtual_vue_vue_type_template_id_996fe106___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SwiperVirtual.vue?vue&type=template&id=996fe106& */ "./resources/js/src/views/extensions/swiper/SwiperVirtual.vue?vue&type=template&id=996fe106&");
/* harmony import */ var _SwiperVirtual_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SwiperVirtual.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/swiper/SwiperVirtual.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SwiperVirtual_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SwiperVirtual_vue_vue_type_template_id_996fe106___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SwiperVirtual_vue_vue_type_template_id_996fe106___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/swiper/SwiperVirtual.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperVirtual.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperVirtual.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperVirtual_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperVirtual.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperVirtual.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperVirtual_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/SwiperVirtual.vue?vue&type=template&id=996fe106&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/SwiperVirtual.vue?vue&type=template&id=996fe106& ***!
  \***************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperVirtual_vue_vue_type_template_id_996fe106___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SwiperVirtual.vue?vue&type=template&id=996fe106& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/swiper/SwiperVirtual.vue?vue&type=template&id=996fe106&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperVirtual_vue_vue_type_template_id_996fe106___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SwiperVirtual_vue_vue_type_template_id_996fe106___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/swiper/code.js":
/*!**********************************************************!*\
  !*** ./resources/js/src/views/extensions/swiper/code.js ***!
  \**********************************************************/
/*! exports provided: codeDefault, codeAutoplay, codeCenterSlides, codeCenterSlides2, codeCoverflowEffect, codeCube, codeFadeEffect, codeGallery, codeLazy, codeMultipleSlides, codeMultiRowSlides, codeNavigation, codePagination, codeParallax, codeProgress, codeResponsive, codeVirtual */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeDefault", function() { return codeDefault; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeAutoplay", function() { return codeAutoplay; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeCenterSlides", function() { return codeCenterSlides; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeCenterSlides2", function() { return codeCenterSlides2; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeCoverflowEffect", function() { return codeCoverflowEffect; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeCube", function() { return codeCube; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeFadeEffect", function() { return codeFadeEffect; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeGallery", function() { return codeGallery; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeLazy", function() { return codeLazy; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeMultipleSlides", function() { return codeMultipleSlides; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeMultiRowSlides", function() { return codeMultiRowSlides; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeNavigation", function() { return codeNavigation; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codePagination", function() { return codePagination; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeParallax", function() { return codeParallax; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeProgress", function() { return codeProgress; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeResponsive", function() { return codeResponsive; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeVirtual", function() { return codeVirtual; });
var codeDefault = "\n<template>\n  <swiper\n    ref=\"mySwiper\"\n    :dir=\"$store.state.appConfig.isRTL ? 'rtl' : 'ltr'\"\n  >\n    <swiper-slide\n      v-for=\"data in swiperData\"\n      :key=\"data.img\"\n    >\n      <b-img\n        :src=\"data.img\"\n        fluid\n      />\n    </swiper-slide>\n  </swiper>\n</template>\n\n<script>\nimport { Swiper, SwiperSlide } from 'vue-awesome-swiper'\nimport { BImg } from 'bootstrap-vue'\nimport 'swiper/css/swiper.css'\n\nexport default {\n  components: {\n    Swiper,\n    SwiperSlide,\n    BImg,\n  },\n  data() {\n    return {\n      /* eslint-disable global-require */\n      swiperData: [\n        { img: require('@/assets/images/banner/banner-13.jpg') },\n        { img: require('@/assets/images/banner/banner-7.jpg') },\n        { img: require('@/assets/images/banner/banner-4.jpg') },\n        { img: require('@/assets/images/banner/banner-2.jpg') },\n        { img: require('@/assets/images/banner/banner-1.jpg') },\n      ],\n      /* eslint-disable global-require */\n    }\n  },\n}\n</script>\n\n";
var codeAutoplay = "\n<template>\n  <swiper\n    class=\"swiper-autoplay\"\n    :options=\"swiperOptions\"\n    :dir=\"$store.state.appConfig.isRTL ? 'rtl' : 'ltr'\"\n  >\n    <swiper-slide\n      v-for=\"data in swiperData\"\n      :key=\"data.img\"\n    >\n      <b-img\n        :src=\"data.img\"\n        fluid\n      />\n    </swiper-slide>\n    <div\n      slot=\"pagination\"\n      class=\"swiper-pagination\"\n    />\n    <div\n      slot=\"button-next\"\n      class=\"swiper-button-next\"\n    />\n    <div\n      slot=\"button-prev\"\n      class=\"swiper-button-prev\"\n    />\n  </swiper>\n</template>\n\n<script>\nimport { Swiper, SwiperSlide } from 'vue-awesome-swiper'\nimport { BImg } from 'bootstrap-vue'\nimport 'swiper/css/swiper.css'\n\nexport default {\n  components: {\n    Swiper,\n    SwiperSlide,\n    BImg,\n  },\n  data() {\n    return {\n      swiperOptions: {\n        spaceBetween: 30,\n        centeredSlides: true,\n        autoplay: {\n          delay: 2500,\n          disableOnInteraction: false,\n        },\n        pagination: {\n          el: '.swiper-pagination',\n          clickable: true,\n        },\n        navigation: {\n          nextEl: '.swiper-button-next',\n          prevEl: '.swiper-button-prev',\n        },\n      },\n\n      /* eslint-disable global-require */\n      swiperData: [\n        { img: require('@/assets/images/banner/banner-20.jpg') },\n        { img: require('@/assets/images/banner/banner-7.jpg') },\n        { img: require('@/assets/images/banner/banner-8.jpg') },\n        { img: require('@/assets/images/banner/banner-9.jpg') },\n        { img: require('@/assets/images/banner/banner-10.jpg') },\n        { img: require('@/assets/images/banner/banner-11.jpg') },\n      ],\n      /* eslint-disable global-require */\n\n    }\n  },\n}\n</script>\n";
var codeCenterSlides = "\n<template>\n  <swiper\n    class=\"swiper-centered-slides p-1\"\n    :options=\"swiperOptions\"\n    :dir=\"$store.state.appConfig.isRTL ? 'rtl' : 'ltr'\"\n  >\n\n    <!-- slides -->\n    <swiper-slide\n      v-for=\"data in swiperData\"\n      :key=\"data.text\"\n      class=\"rounded swiper-shadow\"\n    >\n      <feather-icon\n        :icon=\"data.icon\"\n        size=\"28\"\n      />\n      <div class=\"swiper-text pt-md-1 pt-sm-50\">\n        {{ data.text }}\n      </div>\n    </swiper-slide>\n\n    <!-- Add Arrows -->\n    <div\n      slot=\"button-next\"\n      class=\"swiper-button-next\"\n    />\n    <div\n      slot=\"button-prev\"\n      class=\"swiper-button-prev\"\n    />\n  </swiper>\n</template>\n\n<script>\nimport { Swiper, SwiperSlide } from 'vue-awesome-swiper'\nimport 'swiper/css/swiper.css'\n\nexport default {\n  components: {\n    Swiper,\n    SwiperSlide,\n  },\n  data() {\n    return {\n      swiperData: [\n        { icon: 'GithubIcon', text: 'Getting Started' },\n        { icon: 'FacebookIcon', text: 'Pricing & Plans' },\n        { icon: 'TwitterIcon', text: 'Sales Question' },\n        { icon: 'InstagramIcon', text: 'Usage Guides' },\n        { icon: 'GitlabIcon', text: 'General Guide' },\n      ],\n      swiperOptions: {\n        slidesPerView: 'auto',\n        centeredSlides: true,\n        spaceBetween: 30,\n        navigation: {\n          nextEl: '.swiper-button-next',\n          prevEl: '.swiper-button-prev',\n        },\n      },\n    }\n  },\n}\n</script>\n";
var codeCenterSlides2 = "\n<template>\n  <swiper\n    class=\"swiper-centered-slides-2 p-1\"\n    :options=\"swiperOptions\"\n    :dir=\"$store.state.appConfig.isRTL ? 'rtl' : 'ltr'\"\n  >\n    <swiper-slide\n      v-for=\"(data,index) in swiperData\"\n      :key=\"index\"\n      class=\"rounded swiper-shadow py-1 px-3 d-flex\"\n    >\n      <feather-icon\n        :icon=\"data.icon\"\n        size=\"18\"\n        class=\"mr-50\"\n      />\n      <div class=\"swiper-text\">\n        {{ data.text }}\n      </div>\n    </swiper-slide>\n  </swiper>\n</template>\n\n<script>\nimport { Swiper, SwiperSlide } from 'vue-awesome-swiper'\nimport 'swiper/css/swiper.css'\n\nexport default {\n  components: {\n    Swiper,\n    SwiperSlide,\n  },\n  data() {\n    return {\n      swiperData: [\n        { icon: 'GithubIcon', text: 'Getting Started' },\n        { icon: 'FacebookIcon', text: 'Pricing & Plans' },\n        { icon: 'TwitterIcon', text: 'Sales Question' },\n        { icon: 'InstagramIcon', text: 'Usage Guides' },\n        { icon: 'FacebookIcon', text: 'Pricing & Plans' },\n      ],\n      swiperOptions: {\n        slidesPerView: 'auto',\n        centeredSlides: true,\n        spaceBetween: 30,\n      },\n    }\n  },\n}\n</script>\n";
var codeCoverflowEffect = "\n<template>\n  <swiper\n    class=\"swiper-coverflow\"\n    :options=\"swiperOptions\"\n    :dir=\"$store.state.appConfig.isRTL ? 'rtl' : 'ltr'\"\n  >\n    <swiper-slide\n      v-for=\"(data,index) in swiperData\"\n      :key=\"index\"\n    >\n      <b-img\n        :src=\"data.img\"\n        fluid\n      />\n    </swiper-slide>\n    <div\n      slot=\"pagination\"\n      class=\"swiper-pagination\"\n    />\n  </swiper>\n</template>\n\n<script>\nimport { Swiper, SwiperSlide } from 'vue-awesome-swiper'\nimport { BImg } from 'bootstrap-vue'\nimport 'swiper/css/swiper.css'\n\nexport default {\n  components: {\n    Swiper,\n    SwiperSlide,\n    BImg,\n  },\n  data() {\n    return {\n\n      /* eslint-disable global-require */\n      swiperData: [\n        { img: require('@/assets/images/banner/banner-35.jpg') },\n        { img: require('@/assets/images/banner/banner-39.jpg') },\n        { img: require('@/assets/images/banner/banner-38.jpg') },\n        { img: require('@/assets/images/banner/banner-37.jpg') },\n        { img: require('@/assets/images/banner/banner-36.jpg') },\n        { img: require('@/assets/images/banner/banner-34.jpg') },\n        { img: require('@/assets/images/banner/banner-33.jpg') },\n        { img: require('@/assets/images/banner/banner-32.jpg') },\n        { img: require('@/assets/images/banner/banner-31.jpg') },\n      ],\n      /* eslint-disable global-require */\n\n      swiperOptions: {\n        effect: 'coverflow',\n        grabCursor: true,\n        centeredSlides: true,\n        slidesPerView: 'auto',\n        coverflowEffect: {\n          rotate: 50,\n          stretch: 0,\n          depth: 100,\n          modifier: 1,\n          slideShadows: true,\n        },\n        pagination: {\n          el: '.swiper-pagination',\n        },\n      },\n    }\n  },\n}\n</script>\n";
var codeCube = "\n<template>\n  <swiper\n    class=\"swiper-cube-effect\"\n    :options=\"swiperOptions\"\n    :dir=\"$store.state.appConfig.isRTL ? 'rtl' : 'ltr'\"\n  >\n    <swiper-slide\n      v-for=\"(data,index) in swiperData\"\n      :key=\"index\"\n    >\n      <b-img\n        :src=\"data.img\"\n        fluid\n      />\n    </swiper-slide>\n    <div\n      slot=\"pagination\"\n      class=\"swiper-pagination swiper-pagination-white\"\n    />\n  </swiper>\n</template>\n\n<script>\nimport { Swiper, SwiperSlide } from 'vue-awesome-swiper'\nimport { BImg } from 'bootstrap-vue'\nimport 'swiper/css/swiper.css'\n\nexport default {\n  components: {\n    Swiper,\n    SwiperSlide,\n    BImg,\n  },\n  data() {\n    return {\n      /* eslint-disable global-require */\n      swiperData: [\n        { img: require('@/assets/images/banner/banner-21.jpg') },\n        { img: require('@/assets/images/banner/banner-22.jpg') },\n        { img: require('@/assets/images/banner/banner-23.jpg') },\n        { img: require('@/assets/images/banner/banner-24.jpg') },\n      ],\n      /* eslint-disable global-require */\n\n      swiperOptions: {\n        effect: 'cube',\n        grabCursor: true,\n        cubeEffect: {\n          shadow: true,\n          slideShadows: true,\n          shadowOffset: 20,\n          shadowScale: 0.94,\n        },\n        pagination: {\n          el: '.swiper-pagination',\n        },\n      },\n    }\n  },\n}\n</script>\n";
var codeFadeEffect = "\n<template>\n  <swiper\n    class=\"swiper-navigations\"\n    :options=\"swiperOptions\"\n    :dir=\"$store.state.appConfig.isRTL ? 'rtl' : 'ltr'\"\n  >\n    <swiper-slide\n      v-for=\"(data,index) in swiperData\"\n      :key=\"index\"\n    >\n      <b-img\n        :src=\"data.img\"\n        fluid\n      />\n    </swiper-slide>\n\n    <!-- Add Arrows -->\n    <div\n      slot=\"button-next\"\n      class=\"swiper-button-next\"\n    />\n    <div\n      slot=\"button-prev\"\n      class=\"swiper-button-prev\"\n    />\n    <div\n      slot=\"pagination\"\n      class=\"swiper-pagination\"\n    />\n  </swiper>\n</template>\n\n<script>\nimport { Swiper, SwiperSlide } from 'vue-awesome-swiper'\nimport { BImg } from 'bootstrap-vue'\nimport 'swiper/css/swiper.css'\n\nexport default {\n  components: {\n    Swiper,\n    SwiperSlide,\n    BImg,\n  },\n  data() {\n    return {\n\n      /* eslint-disable global-require */\n      swiperData: [\n        { img: require('@/assets/images/banner/banner-20.jpg') },\n        { img: require('@/assets/images/banner/banner-19.jpg') },\n        { img: require('@/assets/images/banner/banner-18.jpg') },\n        { img: require('@/assets/images/banner/banner-17.jpg') },\n        { img: require('@/assets/images/banner/banner-16.jpg') },\n      ],\n      /* eslint-disable global-require */\n\n      swiperOptions: {\n        spaceBetween: 30,\n        effect: 'fade',\n        navigation: {\n          nextEl: '.swiper-button-next',\n          prevEl: '.swiper-button-prev',\n        },\n        pagination: {\n          el: '.swiper-pagination',\n        },\n      },\n    }\n  },\n}\n</script>\n";
var codeGallery = "\n<template>\n  <!-- swiper1 -->\n  <swiper\n    ref=\"swiperTop\"\n    class=\"swiper-gallery gallery-top\"\n    :options=\"swiperOptions\"\n    :dir=\"$store.state.appConfig.isRTL ? 'rtl' : 'ltr'\"\n  >\n    <swiper-slide\n      v-for=\"(data,index) in swiperData\"\n      :key=\"index\"\n    >\n      <b-img\n        :src=\"data.img\"\n        fluid\n      />\n    </swiper-slide>\n\n    <div\n      slot=\"button-next\"\n      class=\"swiper-button-next swiper-button-white\"\n    />\n    <div\n      slot=\"button-prev\"\n      class=\"swiper-button-prev swiper-button-white\"\n    />\n  </swiper>\n\n  <!-- swiper2 Thumbs -->\n  <swiper\n    ref=\"swiperThumbs\"\n    class=\"swiper gallery-thumbs\"\n    :options=\"swiperOptionThumbs\"\n  >\n    <swiper-slide\n      v-for=\"(data,index) in swiperData\"\n      :key=\"index\"\n    >\n      <b-img\n        :src=\"data.img\"\n        fluid\n      />\n    </swiper-slide>\n  </swiper>\n</template>\n\n<script>\nimport { Swiper, SwiperSlide } from 'vue-awesome-swiper'\nimport { BImg } from 'bootstrap-vue'\nimport 'swiper/css/swiper.css'\n\nexport default {\n  components: {\n    Swiper,\n    SwiperSlide,\n    BImg,\n  },\n  data() {\n    return {\n\n      /* eslint-disable global-require */\n      swiperData: [\n        { img: require('@/assets/images/banner/banner-11.jpg') },\n        { img: require('@/assets/images/banner/banner-12.jpg') },\n        { img: require('@/assets/images/banner/banner-13.jpg') },\n        { img: require('@/assets/images/banner/banner-15.jpg') },\n        { img: require('@/assets/images/banner/banner-16.jpg') },\n      ],\n      /* eslint-disable global-require */\n\n      swiperOptions: {\n        loop: true,\n        loopedSlides: 5,\n        spaceBetween: 10,\n        navigation: {\n          nextEl: '.swiper-button-next',\n          prevEl: '.swiper-button-prev',\n        },\n      },\n      swiperOptionThumbs: {\n        loop: true,\n        loopedSlides: 5, // looped slides should be the same\n        spaceBetween: 10,\n        centeredSlides: true,\n        slidesPerView: 4,\n        touchRatio: 0.2,\n        slideToClickedSlide: true,\n      },\n    }\n  },\n  mounted() {\n    this.$nextTick(() => {\n      const swiperTop = this.$refs.swiperTop.$swiper\n      const swiperThumbs = this.$refs.swiperThumbs.$swiper\n      swiperTop.controller.control = swiperThumbs\n      swiperThumbs.controller.control = swiperTop\n    })\n  },\n}\n</script>\n";
var codeLazy = "\n<template>\n  <swiper\n    class=\"swiper-lazy-loading\"\n    :options=\"swiperOptions\"\n    :dir=\"$store.state.appConfig.isRTL ? 'rtl' : 'ltr'\"\n  >\n    <swiper-slide\n      v-for=\"(data,index) in swiperData\"\n      :key=\"index\"\n    >\n      <b-img\n        :src=\"data.img\"\n        fluid\n        class=\"swiper-lazy\"\n      />\n      <div class=\"swiper-lazy-preloader swiper-lazy-preloader-white\" />\n    </swiper-slide>\n\n    <div\n      slot=\"pagination\"\n      class=\"swiper-pagination\"\n    />\n    <div\n      slot=\"button-next\"\n      class=\"swiper-button-next\"\n    />\n    <div\n      slot=\"button-prev\"\n      class=\"swiper-button-prev\"\n    />\n  </swiper>\n</template>\n\n<script>\nimport { Swiper, SwiperSlide } from 'vue-awesome-swiper'\nimport { BImg } from 'bootstrap-vue'\nimport 'swiper/css/swiper.css'\n\nexport default {\n  components: {\n    Swiper,\n    SwiperSlide,\n    BImg,\n  },\n  data() {\n    return {\n      /* eslint-disable global-require */\n      swiperData: [\n        { img: require('@/assets/images/banner/banner-9.jpg') },\n        { img: require('@/assets/images/banner/banner-8.jpg') },\n        { img: require('@/assets/images/banner/banner-7.jpg') },\n        { img: require('@/assets/images/banner/banner-20.jpg') },\n        { img: require('@/assets/images/banner/banner-5.jpg') },\n        { img: require('@/assets/images/banner/banner-4.jpg') },\n      ],\n      /* eslint-disable global-require */\n\n      swiperOptions: {\n        lazy: true,\n        pagination: {\n          el: '.swiper-pagination',\n          clickable: true,\n        },\n        navigation: {\n          nextEl: '.swiper-button-next',\n          prevEl: '.swiper-button-prev',\n        },\n      },\n    }\n  },\n}\n</script>\n";
var codeMultipleSlides = "\n<template>\n  <swiper\n    class=\"swiper-multiple\"\n    :options=\"swiperOptions\"\n    :dir=\"$store.state.appConfig.isRTL ? 'rtl' : 'ltr'\"\n  >\n    <swiper-slide\n      v-for=\"(data,index) in swiperData\"\n      :key=\"index\"\n    >\n      <b-img\n        :src=\"data.img\"\n        fluid\n      />\n    </swiper-slide>\n\n    <div\n      slot=\"pagination\"\n      class=\"swiper-pagination\"\n    />\n  </swiper>\n</template>\n\n<script>\nimport { Swiper, SwiperSlide } from 'vue-awesome-swiper'\nimport { BImg } from 'bootstrap-vue'\nimport 'swiper/css/swiper.css'\n\nexport default {\n  components: {\n    Swiper,\n    SwiperSlide,\n    BImg,\n  },\n  data() {\n    return {\n      /* eslint-disable global-require */\n      swiperData: [\n        { img: require('@/assets/images/banner/banner-31.jpg') },\n        { img: require('@/assets/images/banner/banner-32.jpg') },\n        { img: require('@/assets/images/banner/banner-33.jpg') },\n        { img: require('@/assets/images/banner/banner-34.jpg') },\n        { img: require('@/assets/images/banner/banner-35.jpg') },\n      ],\n      /* eslint-disable global-require */\n\n      swiperOptions: {\n        slidesPerView: 3,\n        spaceBetween: 30,\n        pagination: {\n          el: '.swiper-pagination',\n          clickable: true,\n        },\n      },\n    }\n  },\n}\n</script>\n";
var codeMultiRowSlides = "\n<template>\n  <swiper\n    class=\"swiper\"\n    :options=\"swiperOption\"\n    :dir=\"$store.state.appConfig.isRTL ? 'rtl' : 'ltr'\"\n  >\n    <swiper-slide\n      v-for=\"(data,index) in swiperData\"\n      :key=\"index\"\n    >\n      <b-img\n        :src=\"data.img\"\n        fluid\n      />\n    </swiper-slide>\n\n    <div\n      slot=\"pagination\"\n      class=\"swiper-pagination\"\n    />\n  </swiper>\n</template>\n\n<script>\nimport { Swiper, SwiperSlide } from 'vue-awesome-swiper'\nimport { BImg } from 'bootstrap-vue'\nimport 'swiper/css/swiper.css'\n\nexport default {\n  components: {\n    Swiper,\n    SwiperSlide,\n    BImg,\n  },\n  data() {\n    return {\n      swiperData: [\n        /* eslint-disable global-require */\n        { img: require('@/assets/images/banner/banner-26.jpg') },\n        { img: require('@/assets/images/banner/banner-39.jpg') },\n        { img: require('@/assets/images/banner/banner-28.jpg') },\n        { img: require('@/assets/images/banner/banner-29.jpg') },\n        { img: require('@/assets/images/banner/banner-30.jpg') },\n        { img: require('@/assets/images/banner/banner-31.jpg') },\n        { img: require('@/assets/images/banner/banner-32.jpg') },\n        { img: require('@/assets/images/banner/banner-33.jpg') },\n        { img: require('@/assets/images/banner/banner-34.jpg') },\n        { img: require('@/assets/images/banner/banner-35.jpg') },\n        /* eslint-disable global-require */\n      ],\n      swiperOption: {\n        slidesPerView: 3,\n        slidesPerColumn: 2,\n        spaceBetween: 30,\n        pagination: {\n          el: '.swiper-pagination',\n          clickable: true,\n        },\n        breakpoints: {\n          1024: {\n            slidesPerView: 3,\n            spaceBetween: 30,\n          },\n          768: {\n            slidesPerView: 2,\n            spaceBetween: 30,\n          },\n          640: {\n            slidesPerView: 1,\n            spaceBetween: 20,\n          },\n        },\n      },\n    }\n  },\n}\n</script>\n\n<style lang=\"scss\" scoped>\n.swiper {\n\n  ::v-deep .swiper-wrapper {\n    flex-direction: row !important;\n  }\n  .swiper-slide {\n    margin-top: 30px;\n  }\n}\n\n</style>\n";
var codeNavigation = "\n<template>\n  <swiper\n    class=\"swiper-navigations\"\n    :options=\"swiperOptions\"\n    :dir=\"$store.state.appConfig.isRTL ? 'rtl' : 'ltr'\"\n  >\n    <swiper-slide\n      v-for=\"(data,index) in swiperData\"\n      :key=\"index\"\n    >\n      <b-img\n        :src=\"data.img\"\n        fluid\n      />\n    </swiper-slide>\n\n    <!-- Add Arrows -->\n    <div\n      slot=\"button-next\"\n      class=\"swiper-button-next\"\n    />\n    <div\n      slot=\"button-prev\"\n      class=\"swiper-button-prev\"\n    />\n  </swiper>\n</template>\n\n<script>\nimport { Swiper, SwiperSlide } from 'vue-awesome-swiper'\nimport { BImg } from 'bootstrap-vue'\nimport 'swiper/css/swiper.css'\n\nexport default {\n  components: {\n    Swiper,\n    SwiperSlide,\n    BImg,\n  },\n  data() {\n    return {\n      /* eslint-disable global-require */\n      swiperData: [\n        { img: require('@/assets/images/banner/banner-7.jpg') },\n        { img: require('@/assets/images/banner/banner-4.jpg') },\n        { img: require('@/assets/images/banner/banner-14.jpg') },\n        { img: require('@/assets/images/banner/banner-3.jpg') },\n        { img: require('@/assets/images/banner/banner-2.jpg') },\n      ],\n      /* eslint-disable global-require */\n\n      swiperOptions: {\n        navigation: {\n          nextEl: '.swiper-button-next',\n          prevEl: '.swiper-button-prev',\n        },\n      },\n    }\n  },\n}\n</script>\n";
var codePagination = "\n<template>\n  <swiper\n    class=\"swiper-paginations\"\n    :options=\"swiperOptions\"\n    :dir=\"$store.state.appConfig.isRTL ? 'rtl' : 'ltr'\"\n  >\n    <swiper-slide\n      v-for=\"(data,index) in swiperData\"\n      :key=\"index\"\n    >\n      <b-img\n        :src=\"data.img\"\n        fluid\n      />\n    </swiper-slide>\n\n    <div\n      slot=\"pagination\"\n      class=\"swiper-pagination\"\n    />\n  </swiper>\n</template>\n\n<script>\nimport { Swiper, SwiperSlide } from 'vue-awesome-swiper'\nimport { BImg } from 'bootstrap-vue'\nimport 'swiper/css/swiper.css'\n\nexport default {\n  components: {\n    Swiper,\n    SwiperSlide,\n    BImg,\n  },\n  data() {\n    return {\n\n      /* eslint-disable global-require */\n      swiperData: [\n        { img: require('@/assets/images/banner/banner-12.jpg') },\n        { img: require('@/assets/images/banner/banner-9.jpg') },\n        { img: require('@/assets/images/banner/banner-8.jpg') },\n        { img: require('@/assets/images/banner/banner-7.jpg') },\n        { img: require('@/assets/images/banner/banner-20.jpg') },\n      ],\n      /* eslint-disable global-require */\n\n      swiperOptions: {\n        pagination: {\n          el: '.swiper-pagination',\n        },\n      },\n    }\n  },\n}\n</script>\n";
var codeParallax = "\n<template>\n  <swiper\n    class=\"swiper-parallax\"\n    :options=\"swiperOptions\"\n    :dir=\"$store.state.appConfig.isRTL ? 'rtl' : 'ltr'\"\n  >\n    <div\n      slot=\"parallax-bg\"\n      class=\"parallax-bg\"\n      data-swiper-parallax=\"-23%\"\n    >\n      <b-img\n        class=\"img-fluid\"\n        :src=\"require('@/assets/images/banner/parallax-4.jpg')\"\n        alt=\"banner\"\n      />\n    </div>\n\n    <swiper-slide\n      v-for=\"(data,index) in swiperData\"\n      :key=\"index\"\n    >\n      <div\n        class=\"title\"\n        data-swiper-parallax=\"-300\"\n      >\n        {{ data.title }}\n      </div>\n      <div\n        class=\"subtitle\"\n        data-swiper-parallax=\"-200\"\n      >\n        {{ data.subtitle }}\n      </div>\n      <div\n        class=\"text\"\n        data-swiper-parallax=\"-100\"\n      >\n        <b-card-text>\n          {{ data.text }}\n        </b-card-text>\n      </div>\n    </swiper-slide>\n\n    <div\n      slot=\"pagination\"\n      class=\"swiper-pagination\"\n    />\n    <div\n      slot=\"button-next\"\n      class=\"swiper-button-next\"\n    />\n    <div\n      slot=\"button-prev\"\n      class=\"swiper-button-prev\"\n    />\n  </swiper>\n</template>\n\n<script>\nimport { BImg} from 'bootstrap-vue'\nimport { Swiper, SwiperSlide } from 'vue-awesome-swiper'\nimport 'swiper/css/swiper.css'\n\nexport default {\n  components: {\n    BImg,\n    Swiper,\n    SwiperSlide,\n  },\n  data() {\n    return {\n      swiperData: [\n        { title: 'Slide 1', subtitle: 'Subtitle', text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam dictum mattis velit, sit amet faucibus felis iaculis nec. Nulla laoreet Lorem, ipsum dolor sit amet consectetur..' },\n        { title: 'Slide 2', subtitle: 'Subtitle', text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam dictum mattis velit, sit amet faucibus felis iaculis nec. Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam reiciendis provident atque quod obcaecati voluptatibus ex qui repudiandae sunt dolores. Nulla laoreet justo vitae porttitor porttitor. Suspendisse in sem justo. Integeo. Aenean feugiat non eros quis feugiat.' },\n        { title: 'Slide 3', subtitle: 'Subtitle', text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam dictum mattis velit, sit amet faucibus felis iaculis nec. Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam reiciendis provident atque quod obcaecati voluptatibus ex qui repudiandae sunt dolores. Nulla laoreet justo vitae porttitor porttitor. Suspendisse in sem justo. Integer laoreet magna nec elit suscipit, ac laoreet nibh euismod. Aliquam hendrerit lnt ut libero. Aenean feugiat non eros quis feugiat.' },\n      ],\n      swiperOptions: {\n        speed: 600,\n        parallax: true,\n        pagination: {\n          el: '.swiper-pagination',\n          clickable: true,\n        },\n        navigation: {\n          nextEl: '.swiper-button-next',\n          prevEl: '.swiper-button-prev',\n        },\n      },\n    }\n  },\n}\n</script>\n";
var codeProgress = "\n<template>\n  <swiper\n    class=\"swiper-progress\"\n    :options=\"swiperOptions\"\n    :dir=\"$store.state.appConfig.isRTL ? 'rtl' : 'ltr'\"\n  >\n    <swiper-slide\n      v-for=\"(data,index) in swiperData\"\n      :key=\"index\"\n    >\n      <b-img\n        :src=\"data.img\"\n        fluid\n      />\n    </swiper-slide>\n\n    <!-- Add Arrows -->\n    <div\n      slot=\"button-next\"\n      class=\"swiper-button-next\"\n    />\n    <div\n      slot=\"button-prev\"\n      class=\"swiper-button-prev\"\n    />\n    <div\n      slot=\"pagination\"\n      class=\"swiper-pagination\"\n    />\n  </swiper>\n</template>\n\n<script>\nimport { Swiper, SwiperSlide } from 'vue-awesome-swiper'\nimport { BImg } from 'bootstrap-vue'\nimport 'swiper/css/swiper.css'\n\nexport default {\n  components: {\n    Swiper,\n    SwiperSlide,\n    BImg,\n  },\n  data() {\n    return {\n      /* eslint-disable global-require */\n      swiperData: [\n        { img: require('@/assets/images/banner/banner-8.jpg') },\n        { img: require('@/assets/images/banner/banner-7.jpg') },\n        { img: require('@/assets/images/banner/banner-20.jpg') },\n        { img: require('@/assets/images/banner/banner-4.jpg') },\n        { img: require('@/assets/images/banner/banner-5.jpg') },\n      ],\n      /* eslint-disable global-require */\n\n      swiperOptions: {\n        navigation: {\n          nextEl: '.swiper-button-next',\n          prevEl: '.swiper-button-prev',\n        },\n        pagination: {\n          el: '.swiper-pagination',\n          type: 'progressbar',\n        },\n      },\n    }\n  },\n}\n</script>\n";
var codeResponsive = "\n<template>\n  <swiper\n    class=\"swiper-responsive-breakpoints\"\n    :options=\"swiperOptions\"\n    :dir=\"$store.state.appConfig.isRTL ? 'rtl' : 'ltr'\"\n  >\n    <swiper-slide\n      v-for=\"(data,index) in swiperData\"\n      :key=\"index\"\n    >\n      <b-img\n        :src=\"data.img\"\n        fluid\n      />\n    </swiper-slide>\n\n    <div\n      slot=\"pagination\"\n      class=\"swiper-pagination\"\n    />\n  </swiper>\n</template>\n\n<script>\nimport { Swiper, SwiperSlide } from 'vue-awesome-swiper'\nimport { BImg } from 'bootstrap-vue'\nimport 'swiper/css/swiper.css'\n\nexport default {\n  components: {\n    Swiper,\n    SwiperSlide,\n    BImg,\n  },\n  data() {\n    return {\n      /* eslint-disable global-require */\n      swiperData: [\n        { img: require('@/assets/images/banner/banner-30.jpg') },\n        { img: require('@/assets/images/banner/banner-31.jpg') },\n        { img: require('@/assets/images/banner/banner-32.jpg') },\n        { img: require('@/assets/images/banner/banner-33.jpg') },\n        { img: require('@/assets/images/banner/banner-34.jpg') },\n        { img: require('@/assets/images/banner/banner-35.jpg') },\n        { img: require('@/assets/images/banner/banner-36.jpg') },\n        { img: require('@/assets/images/banner/banner-37.jpg') },\n        { img: require('@/assets/images/banner/banner-38.jpg') },\n      ],\n      /* eslint-disable global-require */\n\n      swiperOptions: {\n        slidesPerView: 5,\n        spaceBetween: 50,\n        pagination: {\n          el: '.swiper-pagination',\n          clickable: true,\n        },\n        breakpoints: {\n          1024: {\n            slidesPerView: 4,\n            spaceBetween: 40,\n          },\n          768: {\n            slidesPerView: 3,\n            spaceBetween: 30,\n          },\n          640: {\n            slidesPerView: 2,\n            spaceBetween: 20,\n          },\n          320: {\n            slidesPerView: 1,\n            spaceBetween: 10,\n          },\n        },\n      },\n    }\n  },\n}\n</script>\n";
var codeVirtual = "\n<template>\n  <b-card-code title=\"Virtual Slides\">\n    <swiper\n      ref=\"mySwiper15\"\n      class=\"swiper-virtual\"\n      :options=\"swiperOptions\"\n      :dir=\"$store.state.appConfig.isRTL ? 'rtl' : 'ltr'\"\n    >\n      <div\n        slot=\"pagination\"\n        class=\"swiper-pagination\"\n      />\n      <div\n        slot=\"button-next\"\n        class=\"swiper-button-next\"\n      />\n      <div\n        slot=\"button-prev\"\n        class=\"swiper-button-prev\"\n      />\n    </swiper>\n\n    <!-- buttons -->\n    <div class=\"demo-inline-spacing justify-content-center\">\n      <b-button\n        v-ripple.400=\"'rgba(113, 102, 240, 0.15)'\"\n        variant=\"outline-primary\"\n        class=\"font-small-3\"\n        @click.prevent=\"prependSlides\"\n      >\n        Prepend 2 Slides\n      </b-button>\n      <b-button\n        v-ripple.400=\"'rgba(113, 102, 240, 0.15)'\"\n        variant=\"outline-primary\"\n        class=\"font-small-3\"\n        @click.prevent=\"toSlide(0)\"\n      >\n        Slide 1\n      </b-button>\n      <b-button\n        v-ripple.400=\"'rgba(113, 102, 240, 0.15)'\"\n        variant=\"outline-primary\"\n        class=\"font-small-3\"\n        @click.prevent=\"toSlide(250)\"\n      >\n        Slide 250\n      </b-button>\n      <b-button\n        v-ripple.400=\"'rgba(113, 102, 240, 0.15)'\"\n        variant=\"outline-primary\"\n        class=\"font-sm-3\"\n        @click.prevent=\"toSlide(500)\"\n      >\n        Slide 500\n      </b-button>\n      <b-button\n        v-ripple.400=\"'rgba(113, 102, 240, 0.15)'\"\n        variant=\"outline-primary\"\n        class=\"font-small-3\"\n        @click.prevent=\"appendSlide\"\n      >\n        Append Slide\n      </b-button>\n    </div>\n\n    <template #code>\n      {{ codeVirtual }}\n    </template>\n  </b-card-code>\n</template>\n\n<script>\nimport BCardCode from '@core/components/b-card-code/BCardCode.vue'\nimport { Swiper } from 'vue-awesome-swiper'\nimport { BButton } from 'bootstrap-vue'\nimport 'swiper/css/swiper.css'\nimport Ripple from 'vue-ripple-directive'\nimport { codeVirtual } from './code'\n\nexport default {\n  components: {\n    Swiper,\n    BCardCode,\n    BButton,\n  },\n  directives: {\n    Ripple,\n  },\n  data() {\n    return {\n      codeVirtual,\n      slides: [],\n      prependNumber: 1,\n      appendNumber: 600,\n      swiperOptions: {\n        slidesPerView: 3,\n        centeredSlides: true,\n        spaceBetween: 30,\n        pagination: {\n          el: '.swiper-pagination',\n          type: 'fraction',\n        },\n        navigation: {\n          nextEl: '.swiper-button-next',\n          prevEl: '.swiper-button-prev',\n        },\n        virtual: {\n          slides: Array(600)\n            .fill('Slide')\n            .map((item, index) => `${item} ${index + 1}`),\n        },\n      },\n    }\n  },\n  methods: {\n    toSlide(index) {\n      this.$refs.mySwiper15.$swiper.slideTo(index, 1)\n    },\n    prependSlides() {\n      this.$refs.mySwiper15.$swiper.virtual.prependSlide([\n        `Slide ${(this.prependNumber -= 1)}`,\n        `Slide ${(this.prependNumber -= 1)}`,\n      ])\n    },\n    appendSlide() {\n      this.$refs.mySwiper15.$swiper.virtual.appendSlide(`Slide ${(this.appendNumber += 1)}`)\n    },\n  },\n}\n</script>\n";

/***/ })

}]);