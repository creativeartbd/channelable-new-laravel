(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[36],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/Slider.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/Slider.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SliderSingle_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SliderSingle.vue */ "./resources/js/src/views/extensions/slider/SliderSingle.vue");
/* harmony import */ var _SliderMultiple_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SliderMultiple.vue */ "./resources/js/src/views/extensions/slider/SliderMultiple.vue");
/* harmony import */ var _SliderRangerValue_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SliderRangerValue.vue */ "./resources/js/src/views/extensions/slider/SliderRangerValue.vue");
/* harmony import */ var _SliderRtl_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./SliderRtl.vue */ "./resources/js/src/views/extensions/slider/SliderRtl.vue");
/* harmony import */ var _SliderLazy_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./SliderLazy.vue */ "./resources/js/src/views/extensions/slider/SliderLazy.vue");
/* harmony import */ var _SliderDisabled_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./SliderDisabled.vue */ "./resources/js/src/views/extensions/slider/SliderDisabled.vue");
/* harmony import */ var _SliderAdsorb_vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./SliderAdsorb.vue */ "./resources/js/src/views/extensions/slider/SliderAdsorb.vue");
/* harmony import */ var _SliderContained_vue__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./SliderContained.vue */ "./resources/js/src/views/extensions/slider/SliderContained.vue");
/* harmony import */ var _SliderBehavior_vue__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./SliderBehavior.vue */ "./resources/js/src/views/extensions/slider/SliderBehavior.vue");
/* harmony import */ var _SliderColor_vue__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./SliderColor.vue */ "./resources/js/src/views/extensions/slider/SliderColor.vue");
/* harmony import */ var _SliderInput_vue__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./SliderInput.vue */ "./resources/js/src/views/extensions/slider/SliderInput.vue");
/* harmony import */ var _SliderVertical_vue__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./SliderVertical.vue */ "./resources/js/src/views/extensions/slider/SliderVertical.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//












/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    SliderSingle: _SliderSingle_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    SliderMultiple: _SliderMultiple_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    SliderRangerValue: _SliderRangerValue_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    SliderRtl: _SliderRtl_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    SliderLazy: _SliderLazy_vue__WEBPACK_IMPORTED_MODULE_4__["default"],
    SliderDisabled: _SliderDisabled_vue__WEBPACK_IMPORTED_MODULE_5__["default"],
    SliderAdsorb: _SliderAdsorb_vue__WEBPACK_IMPORTED_MODULE_6__["default"],
    SliderContained: _SliderContained_vue__WEBPACK_IMPORTED_MODULE_7__["default"],
    SliderBehavior: _SliderBehavior_vue__WEBPACK_IMPORTED_MODULE_8__["default"],
    SliderColor: _SliderColor_vue__WEBPACK_IMPORTED_MODULE_9__["default"],
    SliderInput: _SliderInput_vue__WEBPACK_IMPORTED_MODULE_10__["default"],
    SliderVertical: _SliderVertical_vue__WEBPACK_IMPORTED_MODULE_11__["default"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderAdsorb.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderAdsorb.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-slider-component */ "./node_modules/vue-slider-component/dist/vue-slider-component.umd.min.js");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_slider_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/store/index */ "./resources/js/src/store/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/slider/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardText"],
    VueSlider: vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default.a,
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    return {
      codeAdsorb: _code__WEBPACK_IMPORTED_MODULE_4__["codeAdsorb"],
      value1: 20,
      value2: 'c',
      value3: 60,
      data: ['a', 'b', 'c', 'd', 'e', 'f', 'g'],
      marks: [0, 10, 30, 60, 100],
      dir: 'ltr'
    };
  },
  computed: {
    direction: function direction() {
      if (_store_index__WEBPACK_IMPORTED_MODULE_3__["default"].state.appConfig.isRTL) {
        // eslint-disable-next-line vue/no-side-effects-in-computed-properties
        this.dir = 'rtl';
        return this.dir;
      } // eslint-disable-next-line vue/no-side-effects-in-computed-properties


      this.dir = 'ltr';
      return this.dir;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderBehavior.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderBehavior.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-slider-component */ "./node_modules/vue-slider-component/dist/vue-slider-component.umd.min.js");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_slider_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/store/index */ "./resources/js/src/store/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/slider/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    VueSlider: vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default.a,
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardText"],
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    return {
      codebehavior: _code__WEBPACK_IMPORTED_MODULE_4__["codebehavior"],
      value: 10,
      value1: 30,
      value2: 50,
      value3: [10, 40],
      value4: [10, 50],
      dir: 'ltr'
    };
  },
  computed: {
    direction: function direction() {
      if (_store_index__WEBPACK_IMPORTED_MODULE_3__["default"].state.appConfig.isRTL) {
        // eslint-disable-next-line vue/no-side-effects-in-computed-properties
        this.dir = 'rtl';
        return this.dir;
      } // eslint-disable-next-line vue/no-side-effects-in-computed-properties


      this.dir = 'ltr';
      return this.dir;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderColor.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderColor.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-slider-component */ "./node_modules/vue-slider-component/dist/vue-slider-component.umd.min.js");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_slider_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/store/index */ "./resources/js/src/store/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/slider/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardText"],
    VueSlider: vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default.a,
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    return {
      codeColors: _code__WEBPACK_IMPORTED_MODULE_4__["codeColors"],
      value: 50,
      value1: [0, 50],
      value2: [0, 30, 100],
      value3: 45,
      value4: [30, 60],
      value5: [20, 40],
      value6: [0, 20, 40, 60, 80, 100],
      dir: 'ltr'
    };
  },
  computed: {
    direction: function direction() {
      if (_store_index__WEBPACK_IMPORTED_MODULE_3__["default"].state.appConfig.isRTL) {
        // eslint-disable-next-line vue/no-side-effects-in-computed-properties
        this.dir = 'rtl';
        return this.dir;
      } // eslint-disable-next-line vue/no-side-effects-in-computed-properties


      this.dir = 'ltr';
      return this.dir;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-slider-component */ "./node_modules/vue-slider-component/dist/vue-slider-component.umd.min.js");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_slider_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/store/index */ "./resources/js/src/store/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/slider/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardText"],
    VueSlider: vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default.a,
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    return {
      codeContained: _code__WEBPACK_IMPORTED_MODULE_4__["codeContained"],
      value: 50,
      dir: 'ltr'
    };
  },
  computed: {
    direction: function direction() {
      if (_store_index__WEBPACK_IMPORTED_MODULE_3__["default"].state.appConfig.isRTL) {
        // eslint-disable-next-line vue/no-side-effects-in-computed-properties
        this.dir = 'rtl';
        return this.dir;
      } // eslint-disable-next-line vue/no-side-effects-in-computed-properties


      this.dir = 'ltr';
      return this.dir;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderDisabled.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderDisabled.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-slider-component */ "./node_modules/vue-slider-component/dist/vue-slider-component.umd.min.js");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_slider_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/store/index */ "./resources/js/src/store/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/slider/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardText"],
    VueSlider: vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default.a,
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    return {
      codeDisabled: _code__WEBPACK_IMPORTED_MODULE_4__["codeDisabled"],
      dir: 'ltr',
      value1: 0,
      value2: [0, 50],
      dotOptions: [{
        disabled: false
      }, {
        disabled: true
      }]
    };
  },
  computed: {
    direction: function direction() {
      if (_store_index__WEBPACK_IMPORTED_MODULE_3__["default"].state.appConfig.isRTL) {
        // eslint-disable-next-line vue/no-side-effects-in-computed-properties
        this.dir = 'rtl';
        return this.dir;
      } // eslint-disable-next-line vue/no-side-effects-in-computed-properties


      this.dir = 'ltr';
      return this.dir;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderInput.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderInput.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_Work_laravel_Channel_New_vuexy_admin_v8_2_0_vue_laravel_version_vuexy_bootstrapvue_channable_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vue-slider-component */ "./node_modules/vue-slider-component/dist/vue-slider-component.umd.min.js");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(vue_slider_component__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/store/index */ "./resources/js/src/store/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/slider/code.js");

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    VueSlider: vue_slider_component__WEBPACK_IMPORTED_MODULE_3___default.a,
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    BFormSelect: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BFormSelect"],
    BFormGroup: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BFormGroup"],
    BFormInput: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BFormInput"],
    BFormSelectOption: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BFormSelectOption"]
  },
  data: function data() {
    return {
      codeInput: _code__WEBPACK_IMPORTED_MODULE_5__["codeInput"],
      ldot: 1,
      rdot: 50,
      dir: 'ltr'
    };
  },
  computed: {
    value: {
      get: function get() {
        return [this.ldot, this.rdot];
      },
      set: function set(_ref) {
        var _ref2 = Object(D_Work_laravel_Channel_New_vuexy_admin_v8_2_0_vue_laravel_version_vuexy_bootstrapvue_channable_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref, 2),
            ldot = _ref2[0],
            rdot = _ref2[1];

        this.ldot = ldot;
        this.rdot = rdot;
      }
    },
    direction: function direction() {
      if (_store_index__WEBPACK_IMPORTED_MODULE_4__["default"].state.appConfig.isRTL) {
        // eslint-disable-next-line vue/no-side-effects-in-computed-properties
        this.dir = 'rtl';
        return this.dir;
      } // eslint-disable-next-line vue/no-side-effects-in-computed-properties


      this.dir = 'ltr';
      return this.dir;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderLazy.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderLazy.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-slider-component */ "./node_modules/vue-slider-component/dist/vue-slider-component.umd.min.js");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_slider_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/store/index */ "./resources/js/src/store/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/slider/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardText"],
    VueSlider: vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default.a,
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    return {
      codeLazy: _code__WEBPACK_IMPORTED_MODULE_4__["codeLazy"],
      value: 0,
      dir: 'ltr'
    };
  },
  computed: {
    direction: function direction() {
      if (_store_index__WEBPACK_IMPORTED_MODULE_3__["default"].state.appConfig.isRTL) {
        // eslint-disable-next-line vue/no-side-effects-in-computed-properties
        this.dir = 'rtl';
        return this.dir;
      } // eslint-disable-next-line vue/no-side-effects-in-computed-properties


      this.dir = 'ltr';
      return this.dir;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderMultiple.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderMultiple.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-slider-component */ "./node_modules/vue-slider-component/dist/vue-slider-component.umd.min.js");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_slider_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/store/index */ "./resources/js/src/store/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/slider/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardText"],
    VueSlider: vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default.a,
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    return {
      codeMultiple: _code__WEBPACK_IMPORTED_MODULE_4__["codeMultiple"],
      value_2: [0, 50],
      value_3: [0, 50, 80],
      value_4: [0, 50, 80, 100],
      dir: 'ltr'
    };
  },
  computed: {
    direction: function direction() {
      if (_store_index__WEBPACK_IMPORTED_MODULE_3__["default"].state.appConfig.isRTL) {
        // eslint-disable-next-line vue/no-side-effects-in-computed-properties
        this.dir = 'rtl';
        return this.dir;
      } // eslint-disable-next-line vue/no-side-effects-in-computed-properties


      this.dir = 'ltr';
      return this.dir;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderRangerValue.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderRangerValue.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-slider-component */ "./node_modules/vue-slider-component/dist/vue-slider-component.umd.min.js");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_slider_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/store/index */ "./resources/js/src/store/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/slider/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardText"],
    VueSlider: vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default.a,
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    return {
      codeRange: _code__WEBPACK_IMPORTED_MODULE_4__["codeRange"],
      value: 0.3,
      dir: 'ltr'
    };
  },
  computed: {
    direction: function direction() {
      if (_store_index__WEBPACK_IMPORTED_MODULE_3__["default"].state.appConfig.isRTL) {
        // eslint-disable-next-line vue/no-side-effects-in-computed-properties
        this.dir = 'rtl';
        return this.dir;
      } // eslint-disable-next-line vue/no-side-effects-in-computed-properties


      this.dir = 'ltr';
      return this.dir;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderRtl.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderRtl.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-slider-component */ "./node_modules/vue-slider-component/dist/vue-slider-component.umd.min.js");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_slider_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/slider/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardText"],
    VueSlider: vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default.a,
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    return {
      codeRTL: _code__WEBPACK_IMPORTED_MODULE_3__["codeRTL"],
      value: 50
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderSingle.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderSingle.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-slider-component */ "./node_modules/vue-slider-component/dist/vue-slider-component.umd.min.js");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_slider_component__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _store_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/store/index */ "./resources/js/src/store/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/slider/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    VueSlider: vue_slider_component__WEBPACK_IMPORTED_MODULE_1___default.a,
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      codeSingle: _code__WEBPACK_IMPORTED_MODULE_3__["codeSingle"],
      value: 50,
      dir: 'ltr'
    };
  },
  computed: {
    direction: function direction() {
      if (_store_index__WEBPACK_IMPORTED_MODULE_2__["default"].state.appConfig.isRTL) {
        // eslint-disable-next-line vue/no-side-effects-in-computed-properties
        this.dir = 'rtl';
        return this.dir;
      } // eslint-disable-next-line vue/no-side-effects-in-computed-properties


      this.dir = 'ltr';
      return this.dir;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderVertical.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderVertical.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code/BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-slider-component */ "./node_modules/vue-slider-component/dist/vue-slider-component.umd.min.js");
/* harmony import */ var vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_slider_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/extensions/slider/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    VueSlider: vue_slider_component__WEBPACK_IMPORTED_MODULE_2___default.a,
    BCardCode: _core_components_b_card_code_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    BRow: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BRow"],
    BCol: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCol"]
  },
  data: function data() {
    return {
      value: 60,
      value1: 50,
      value2: 40,
      value3: 60,
      value4: 70,
      value5: 85,
      value6: 60,
      value7: 50,
      value8: 40,
      value9: 60,
      value10: 70,
      value11: 85,
      value12: 60,
      value13: 50,
      value14: 40,
      value15: 60,
      value16: 70,
      value17: 85,
      value18: 60,
      value19: 70,
      value20: 85,
      value21: 60,
      value22: 'a',
      value23: 60,
      value24: [20, 50],
      value25: [40, 80],
      value26: [20, 50],
      value27: [40, 80],
      value28: [20, 50],
      value29: [40, 80],
      data: ['a', 'b', 'c', 'd', 'e'],
      marks: [0, 10, 30, 60, 100],
      codeVerticalDefault: _code__WEBPACK_IMPORTED_MODULE_3__["codeVerticalDefault"],
      codeConntectLower: _code__WEBPACK_IMPORTED_MODULE_3__["codeConntectLower"],
      codeTooltips: _code__WEBPACK_IMPORTED_MODULE_3__["codeTooltips"],
      codeConnectUpper: _code__WEBPACK_IMPORTED_MODULE_3__["codeConnectUpper"],
      codeTopBottom: _code__WEBPACK_IMPORTED_MODULE_3__["codeTopBottom"],
      codeLimit: _code__WEBPACK_IMPORTED_MODULE_3__["codeLimit"]
    };
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/Slider.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/Slider.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "/* Set the theme color of the component */\n/* import theme style */\n/* component style */\n.vue-slider-disabled {\n  opacity: 0.5;\n}\n[dir] .vue-slider-disabled {\n  cursor: not-allowed;\n}\n\n/* rail style */\n[dir] .vue-slider-rail {\n  background-color: rgba(115, 103, 240, 0.12);\n  border-radius: 15px;\n}\n\n/* process style */\n[dir] .vue-slider-process {\n  background-color: #7367f0;\n  border-radius: 15px;\n}\n\n/* mark style */\n.vue-slider-mark {\n  z-index: 4;\n}\n.vue-slider-mark:first-child .vue-slider-mark-step, .vue-slider-mark:last-child .vue-slider-mark-step {\n  display: none;\n}\n.vue-slider-mark-step {\n  width: 100%;\n  height: 100%;\n}\n[dir] .vue-slider-mark-step {\n  border-radius: 50%;\n  background-color: rgba(0, 0, 0, 0.16);\n}\n.vue-slider-mark-label {\n  font-size: 14px;\n  white-space: nowrap;\n}\n\n/* dot style */\n.vue-slider-dot-handle {\n  width: 100%;\n  height: 100%;\n  box-sizing: border-box;\n}\n[dir] .vue-slider-dot-handle {\n  cursor: pointer;\n  border-radius: 50%;\n  background-color: #fff;\n  box-shadow: none;\n}\n[dir] .vue-slider-dot-handle-focus {\n  box-shadow: 0px 0px 1px 2px rgba(115, 103, 240, 0.36);\n}\n[dir] .vue-slider-dot-handle-disabled {\n  cursor: not-allowed;\n  background-color: #ccc;\n}\n.vue-slider-dot-tooltip-inner {\n  font-size: 14px;\n  white-space: nowrap;\n  min-width: 20px;\n  color: #fff;\n  box-sizing: content-box;\n}\n[dir] .vue-slider-dot-tooltip-inner {\n  padding: 2px 5px;\n  text-align: center;\n  border-radius: 5px;\n  border-color: #7367f0;\n  background-color: #7367f0;\n}\n.vue-slider-dot-tooltip-inner::after {\n  content: \"\";\n  position: absolute;\n}\n.vue-slider-dot-tooltip-inner-top::after {\n  top: 100%;\n  height: 0;\n  width: 0;\n}\n[dir] .vue-slider-dot-tooltip-inner-top::after {\n  border-color: transparent;\n  border-style: solid;\n  border-width: 5px;\n  border-top-color: inherit;\n}\n[dir=ltr] .vue-slider-dot-tooltip-inner-top::after {\n  left: 50%;\n  transform: translate(-50%, 0);\n}\n[dir=rtl] .vue-slider-dot-tooltip-inner-top::after {\n  right: 50%;\n  transform: translate(50%, 0);\n}\n.vue-slider-dot-tooltip-inner-bottom::after {\n  bottom: 100%;\n  height: 0;\n  width: 0;\n}\n[dir] .vue-slider-dot-tooltip-inner-bottom::after {\n  border-color: transparent;\n  border-style: solid;\n  border-width: 5px;\n  border-bottom-color: inherit;\n}\n[dir=ltr] .vue-slider-dot-tooltip-inner-bottom::after {\n  left: 50%;\n  transform: translate(-50%, 0);\n}\n[dir=rtl] .vue-slider-dot-tooltip-inner-bottom::after {\n  right: 50%;\n  transform: translate(50%, 0);\n}\n.vue-slider-dot-tooltip-inner-left::after {\n  top: 50%;\n  height: 0;\n  width: 0;\n}\n[dir] .vue-slider-dot-tooltip-inner-left::after {\n  transform: translate(0, -50%);\n  border-color: transparent;\n  border-style: solid;\n  border-width: 5px;\n}\n[dir=ltr] .vue-slider-dot-tooltip-inner-left::after {\n  left: 100%;\n  border-left-color: inherit;\n}\n[dir=rtl] .vue-slider-dot-tooltip-inner-left::after {\n  right: 100%;\n  border-right-color: inherit;\n}\n.vue-slider-dot-tooltip-inner-right::after {\n  top: 50%;\n  height: 0;\n  width: 0;\n}\n[dir] .vue-slider-dot-tooltip-inner-right::after {\n  transform: translate(0, -50%);\n  border-color: transparent;\n  border-style: solid;\n  border-width: 5px;\n}\n[dir=ltr] .vue-slider-dot-tooltip-inner-right::after {\n  right: 100%;\n  border-right-color: inherit;\n}\n[dir=rtl] .vue-slider-dot-tooltip-inner-right::after {\n  left: 100%;\n  border-left-color: inherit;\n}\n.vue-slider-dot-tooltip-wrapper {\n  opacity: 0;\n  transition: all 0.3s;\n}\n.vue-slider-dot-tooltip-wrapper-show {\n  opacity: 1;\n}\n[dir] .vue-slider-dot-handle {\n  border: 2px solid #7367f0;\n}\n[dir] .vue-slider-dot-tooltip-inner {\n  background-color: #7367f0;\n  border-color: #7367f0;\n}\n\n/* Generate:\n*  Border color according to event class\n*/\n[dir] .vue-slider-white .vue-slider-dot-handle {\n  border: 2px solid #ffffff;\n}\n[dir] .vue-slider-white .vue-slider-dot-handle-focus {\n  box-shadow: 0px 0px 1px 2px rgba(255, 255, 255, 0.36);\n}\n[dir] .vue-slider-white .vue-slider-process {\n  background-color: #ffffff;\n}\n[dir] .vue-slider-white .vue-slider-rail {\n  background-color: rgba(255, 255, 255, 0.12);\n}\n[dir] .vue-slider-white .vue-slider-dot-tooltip-inner {\n  background-color: #ffffff;\n  border-color: #ffffff;\n}\n[dir] .vue-slider-black .vue-slider-dot-handle {\n  border: 2px solid #000000;\n}\n[dir] .vue-slider-black .vue-slider-dot-handle-focus {\n  box-shadow: 0px 0px 1px 2px rgba(0, 0, 0, 0.36);\n}\n[dir] .vue-slider-black .vue-slider-process {\n  background-color: #000000;\n}\n[dir] .vue-slider-black .vue-slider-rail {\n  background-color: rgba(0, 0, 0, 0.12);\n}\n[dir] .vue-slider-black .vue-slider-dot-tooltip-inner {\n  background-color: #000000;\n  border-color: #000000;\n}\n[dir] .vue-slider-dark .vue-slider-dot-handle {\n  border: 2px solid #4b4b4b;\n}\n[dir] .vue-slider-dark .vue-slider-dot-handle-focus {\n  box-shadow: 0px 0px 1px 2px rgba(75, 75, 75, 0.36);\n}\n[dir] .vue-slider-dark .vue-slider-process {\n  background-color: #4b4b4b;\n}\n[dir] .vue-slider-dark .vue-slider-rail {\n  background-color: rgba(75, 75, 75, 0.12);\n}\n[dir] .vue-slider-dark .vue-slider-dot-tooltip-inner {\n  background-color: #4b4b4b;\n  border-color: #4b4b4b;\n}\n[dir] .vue-slider-light .vue-slider-dot-handle {\n  border: 2px solid #f6f6f6;\n}\n[dir] .vue-slider-light .vue-slider-dot-handle-focus {\n  box-shadow: 0px 0px 1px 2px rgba(246, 246, 246, 0.36);\n}\n[dir] .vue-slider-light .vue-slider-process {\n  background-color: #f6f6f6;\n}\n[dir] .vue-slider-light .vue-slider-rail {\n  background-color: rgba(246, 246, 246, 0.12);\n}\n[dir] .vue-slider-light .vue-slider-dot-tooltip-inner {\n  background-color: #f6f6f6;\n  border-color: #f6f6f6;\n}\n[dir] .vue-slider-primary .vue-slider-dot-handle {\n  border: 2px solid #7367f0;\n}\n[dir] .vue-slider-primary .vue-slider-dot-handle-focus {\n  box-shadow: 0px 0px 1px 2px rgba(115, 103, 240, 0.36);\n}\n[dir] .vue-slider-primary .vue-slider-process {\n  background-color: #7367f0;\n}\n[dir] .vue-slider-primary .vue-slider-rail {\n  background-color: rgba(115, 103, 240, 0.12);\n}\n[dir] .vue-slider-primary .vue-slider-dot-tooltip-inner {\n  background-color: #7367f0;\n  border-color: #7367f0;\n}\n[dir] .vue-slider-secondary .vue-slider-dot-handle {\n  border: 2px solid #82868b;\n}\n[dir] .vue-slider-secondary .vue-slider-dot-handle-focus {\n  box-shadow: 0px 0px 1px 2px rgba(130, 134, 139, 0.36);\n}\n[dir] .vue-slider-secondary .vue-slider-process {\n  background-color: #82868b;\n}\n[dir] .vue-slider-secondary .vue-slider-rail {\n  background-color: rgba(130, 134, 139, 0.12);\n}\n[dir] .vue-slider-secondary .vue-slider-dot-tooltip-inner {\n  background-color: #82868b;\n  border-color: #82868b;\n}\n[dir] .vue-slider-success .vue-slider-dot-handle {\n  border: 2px solid #28c76f;\n}\n[dir] .vue-slider-success .vue-slider-dot-handle-focus {\n  box-shadow: 0px 0px 1px 2px rgba(40, 199, 111, 0.36);\n}\n[dir] .vue-slider-success .vue-slider-process {\n  background-color: #28c76f;\n}\n[dir] .vue-slider-success .vue-slider-rail {\n  background-color: rgba(40, 199, 111, 0.12);\n}\n[dir] .vue-slider-success .vue-slider-dot-tooltip-inner {\n  background-color: #28c76f;\n  border-color: #28c76f;\n}\n[dir] .vue-slider-info .vue-slider-dot-handle {\n  border: 2px solid #00cfe8;\n}\n[dir] .vue-slider-info .vue-slider-dot-handle-focus {\n  box-shadow: 0px 0px 1px 2px rgba(0, 207, 232, 0.36);\n}\n[dir] .vue-slider-info .vue-slider-process {\n  background-color: #00cfe8;\n}\n[dir] .vue-slider-info .vue-slider-rail {\n  background-color: rgba(0, 207, 232, 0.12);\n}\n[dir] .vue-slider-info .vue-slider-dot-tooltip-inner {\n  background-color: #00cfe8;\n  border-color: #00cfe8;\n}\n[dir] .vue-slider-warning .vue-slider-dot-handle {\n  border: 2px solid #ff9f43;\n}\n[dir] .vue-slider-warning .vue-slider-dot-handle-focus {\n  box-shadow: 0px 0px 1px 2px rgba(255, 159, 67, 0.36);\n}\n[dir] .vue-slider-warning .vue-slider-process {\n  background-color: #ff9f43;\n}\n[dir] .vue-slider-warning .vue-slider-rail {\n  background-color: rgba(255, 159, 67, 0.12);\n}\n[dir] .vue-slider-warning .vue-slider-dot-tooltip-inner {\n  background-color: #ff9f43;\n  border-color: #ff9f43;\n}\n[dir] .vue-slider-danger .vue-slider-dot-handle {\n  border: 2px solid #ea5455;\n}\n[dir] .vue-slider-danger .vue-slider-dot-handle-focus {\n  box-shadow: 0px 0px 1px 2px rgba(234, 84, 85, 0.36);\n}\n[dir] .vue-slider-danger .vue-slider-process {\n  background-color: #ea5455;\n}\n[dir] .vue-slider-danger .vue-slider-rail {\n  background-color: rgba(234, 84, 85, 0.12);\n}\n[dir] .vue-slider-danger .vue-slider-dot-tooltip-inner {\n  background-color: #ea5455;\n  border-color: #ea5455;\n}\n[dir] body.dark-layout .vue-slider-dot-handle {\n  background-color: #161d31;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "[dir] .wrap {\n  padding: 10px 0;\n}[dir=ltr] .wrap {\n  border-left: 1px dashed #ddd;\n  border-right: 1px dashed #ddd;\n}[dir=rtl] .wrap {\n  border-right: 1px dashed #ddd;\n  border-left: 1px dashed #ddd;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/Slider.vue?vue&type=style&index=0&lang=scss&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/Slider.vue?vue&type=style&index=0&lang=scss& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Slider.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/Slider.vue?vue&type=style&index=0&lang=scss&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=style&index=0&lang=scss&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=style&index=0&lang=scss& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderContained.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=style&index=0&lang=scss&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/Slider.vue?vue&type=template&id=b3a8a784&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/Slider.vue?vue&type=template&id=b3a8a784& ***!
  \**************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("slider-single"),
      _vm._v(" "),
      _c("slider-multiple"),
      _vm._v(" "),
      _c("slider-ranger-value"),
      _vm._v(" "),
      _c("slider-rtl"),
      _vm._v(" "),
      _c("slider-lazy"),
      _vm._v(" "),
      _c("slider-disabled"),
      _vm._v(" "),
      _c("slider-adsorb"),
      _vm._v(" "),
      _c("slider-contained"),
      _vm._v(" "),
      _c("slider-behavior"),
      _vm._v(" "),
      _c("slider-color"),
      _vm._v(" "),
      _c("slider-input"),
      _vm._v(" "),
      _c("slider-vertical"),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderAdsorb.vue?vue&type=template&id=5760bc8d&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderAdsorb.vue?vue&type=template&id=5760bc8d& ***!
  \********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Adsorb Slider" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeAdsorb) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [_vm._v("When ")]),
        _vm._v(" "),
        _c("code", [_vm._v("adsorb")]),
        _vm._v(" "),
        _c("span", [_vm._v(" is set to ")]),
        _vm._v(" "),
        _c("code", [_vm._v("true")]),
        _vm._v(" "),
        _c("span", [
          _vm._v(", the slider automatically adsorb to the nearest value."),
        ]),
      ]),
      _vm._v(" "),
      _c(
        "div",
        [
          _c("vue-slider", {
            staticClass: "mb-3",
            attrs: {
              adsorb: true,
              interval: 10,
              marks: true,
              direction: _vm.direction,
            },
            model: {
              value: _vm.value1,
              callback: function ($$v) {
                _vm.value1 = $$v
              },
              expression: "value1",
            },
          }),
          _vm._v(" "),
          _c("vue-slider", {
            staticClass: "mb-3",
            attrs: {
              adsorb: true,
              data: _vm.data,
              marks: true,
              direction: _vm.direction,
            },
            model: {
              value: _vm.value2,
              callback: function ($$v) {
                _vm.value2 = $$v
              },
              expression: "value2",
            },
          }),
          _vm._v(" "),
          _c("vue-slider", {
            staticClass: "mb-2",
            attrs: {
              adsorb: true,
              marks: _vm.marks,
              included: true,
              direction: _vm.direction,
            },
            model: {
              value: _vm.value3,
              callback: function ($$v) {
                _vm.value3 = $$v
              },
              expression: "value3",
            },
          }),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderBehavior.vue?vue&type=template&id=f79198a0&":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderBehavior.vue?vue&type=template&id=f79198a0& ***!
  \**********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Slider behavior" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codebehavior) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("h6", [_vm._v("Default")]),
      _vm._v(" "),
      _c("b-card-text", [_vm._v("It is the default behavior of slider.")]),
      _vm._v(" "),
      _c("vue-slider", {
        attrs: { direction: _vm.direction },
        model: {
          value: _vm.value,
          callback: function ($$v) {
            _vm.value = $$v
          },
          expression: "value",
        },
      }),
      _vm._v(" "),
      _c("h6", { staticClass: "mt-2" }, [_vm._v("\n    Drag on Click\n  ")]),
      _vm._v(" "),
      _c("b-card-text", [
        _c("span", [_vm._v("When ")]),
        _vm._v(" "),
        _c("code", [_vm._v("drag-on-click")]),
        _vm._v(" "),
        _c("span", [_vm._v(" is set to ")]),
        _vm._v(" "),
        _c("code", [_vm._v("true")]),
        _vm._v(" "),
        _c("span", [
          _vm._v(", can drag the slider directly when pressing the process."),
        ]),
      ]),
      _vm._v(" "),
      _c("vue-slider", {
        attrs: { direction: _vm.direction, "drag-on-click": true },
        model: {
          value: _vm.value1,
          callback: function ($$v) {
            _vm.value1 = $$v
          },
          expression: "value1",
        },
      }),
      _vm._v(" "),
      _c("h6", { staticClass: "mt-2" }, [
        _vm._v("\n    Process not filled\n  "),
      ]),
      _vm._v(" "),
      _c("b-card-text", [
        _c("span", [_vm._v("User ")]),
        _vm._v(" "),
        _c("code", [_vm._v("process")]),
        _vm._v(" "),
        _c("span", [_vm._v(" prop false for unfill the processbar.")]),
      ]),
      _vm._v(" "),
      _c("vue-slider", {
        attrs: { direction: _vm.direction, process: false },
        model: {
          value: _vm.value2,
          callback: function ($$v) {
            _vm.value2 = $$v
          },
          expression: "value2",
        },
      }),
      _vm._v(" "),
      _c("h6", { staticClass: "mt-2" }, [_vm._v("\n    Min & Max\n  ")]),
      _vm._v(" "),
      _c("b-card-text", [
        _c("span", [_vm._v("Use ")]),
        _vm._v(" "),
        _c("code", [_vm._v("min-range")]),
        _vm._v(" "),
        _c("span", [_vm._v(" and ")]),
        _vm._v(" "),
        _c("code", [_vm._v("max-range")]),
        _vm._v(" "),
        _c("span", [_vm._v(" prop to limit the slider.")]),
      ]),
      _vm._v(" "),
      _c("vue-slider", {
        attrs: { "min-range": 10, direction: _vm.direction, "max-range": 50 },
        model: {
          value: _vm.value3,
          callback: function ($$v) {
            _vm.value3 = $$v
          },
          expression: "value3",
        },
      }),
      _vm._v(" "),
      _c("h6", { staticClass: "mt-2" }, [_vm._v("\n    Fixed\n  ")]),
      _vm._v(" "),
      _c("b-card-text", [
        _c("span", [_vm._v("Use ")]),
        _vm._v("]\n    "),
        _c("code", [_vm._v("fixed")]),
        _vm._v(" "),
        _c("span", [_vm._v(" prop to fixed the slider.")]),
      ]),
      _vm._v(" "),
      _c("vue-slider", {
        attrs: { direction: _vm.direction, fixed: true },
        model: {
          value: _vm.value4,
          callback: function ($$v) {
            _vm.value4 = $$v
          },
          expression: "value4",
        },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderColor.vue?vue&type=template&id=14529316&":
/*!*******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderColor.vue?vue&type=template&id=14529316& ***!
  \*******************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Slider Colors - Handles" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeColors) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [_vm._v("You can use ")]),
        _vm._v(" "),
        _c("code", [_vm._v("process-style")]),
        _vm._v(" "),
        _c("span", [_vm._v(" and ")]),
        _vm._v(" "),
        _c("code", [_vm._v("dot-style")]),
        _vm._v(" "),
        _c("span", [_vm._v(" for style process bar and dot")]),
      ]),
      _vm._v(" "),
      _c("h6", [_vm._v("Default / Primary Color Slider")]),
      _vm._v(" "),
      _c("vue-slider", {
        staticClass: "mb-2",
        attrs: { tooltip: "none", direction: _vm.direction },
        model: {
          value: _vm.value,
          callback: function ($$v) {
            _vm.value = $$v
          },
          expression: "value",
        },
      }),
      _vm._v(" "),
      _c("h6", [_vm._v("Secondary Color Slider")]),
      _vm._v(" "),
      _c("vue-slider", {
        staticClass: "mb-2 vue-slider-secondary",
        attrs: { tooltip: "none", direction: _vm.direction },
        model: {
          value: _vm.value1,
          callback: function ($$v) {
            _vm.value1 = $$v
          },
          expression: "value1",
        },
      }),
      _vm._v(" "),
      _c("h6", [_vm._v("Success Color Slider")]),
      _vm._v(" "),
      _c("vue-slider", {
        staticClass: "mb-2 vue-slider-success",
        attrs: { tooltip: "none", direction: _vm.direction },
        model: {
          value: _vm.value2,
          callback: function ($$v) {
            _vm.value2 = $$v
          },
          expression: "value2",
        },
      }),
      _vm._v(" "),
      _c("h6", [_vm._v("Danger Color Slider")]),
      _vm._v(" "),
      _c("vue-slider", {
        staticClass: "mb-2 vue-slider-danger",
        attrs: { tooltip: "none", direction: _vm.direction, fixed: true },
        model: {
          value: _vm.value4,
          callback: function ($$v) {
            _vm.value4 = $$v
          },
          expression: "value4",
        },
      }),
      _vm._v(" "),
      _c("h6", [_vm._v("Warning Color Slider")]),
      _vm._v(" "),
      _c("vue-slider", {
        staticClass: "mb-2 vue-slider-warning",
        attrs: { tooltip: "none", direction: _vm.direction },
        model: {
          value: _vm.value3,
          callback: function ($$v) {
            _vm.value3 = $$v
          },
          expression: "value3",
        },
      }),
      _vm._v(" "),
      _c("h6", [_vm._v("Info Color Slider")]),
      _vm._v(" "),
      _c("vue-slider", {
        staticClass: "mb-2 vue-slider-info",
        attrs: {
          tooltip: "none",
          "min-range": 20,
          "max-range": 50,
          direction: _vm.direction,
        },
        model: {
          value: _vm.value5,
          callback: function ($$v) {
            _vm.value5 = $$v
          },
          expression: "value5",
        },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=template&id=6b183e85&":
/*!***********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=template&id=6b183e85& ***!
  \***********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Contained Slider" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeContained) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [_vm._v("When ")]),
        _vm._v(" "),
        _c("code", [_vm._v("contained")]),
        _vm._v(" "),
        _c("span", [_vm._v(" is set to ")]),
        _vm._v(" "),
        _c("code", [_vm._v("true")]),
        _vm._v(" "),
        _c("span", [_vm._v(", the edge of the ")]),
        _vm._v(" "),
        _c("code", [_vm._v("dot")]),
        _vm._v(" "),
        _c("span", [_vm._v(" is used to align.")]),
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "wrap" },
        [
          _c("vue-slider", { attrs: { direction: _vm.direction } }),
          _vm._v(" "),
          _c("b-card-text", [_vm._v("contained: false")]),
          _vm._v(" "),
          _c("vue-slider", {
            attrs: { direction: _vm.direction, contained: true },
          }),
          _vm._v(" "),
          _c("b-card-text", [_vm._v("contained: true")]),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderDisabled.vue?vue&type=template&id=54cad24c&":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderDisabled.vue?vue&type=template&id=54cad24c& ***!
  \**********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Disabled Slider" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeDisabled) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [_vm._v("You can disable the entire component with ")]),
        _vm._v(" "),
        _c("code", [_vm._v("disabled")]),
        _vm._v(" "),
        _c("span", [_vm._v(" or disable the slider separately with ")]),
        _vm._v(" "),
        _c("code", [_vm._v("dot-options")]),
      ]),
      _vm._v(" "),
      _c("vue-slider", {
        staticClass: "mb-2",
        attrs: { disabled: true, direction: _vm.direction },
        model: {
          value: _vm.value1,
          callback: function ($$v) {
            _vm.value1 = $$v
          },
          expression: "value1",
        },
      }),
      _vm._v(" "),
      _c("vue-slider", {
        attrs: {
          "dot-options": _vm.dotOptions,
          order: false,
          direction: _vm.direction,
        },
        model: {
          value: _vm.value2,
          callback: function ($$v) {
            _vm.value2 = $$v
          },
          expression: "value2",
        },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderInput.vue?vue&type=template&id=34fb5948&":
/*!*******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderInput.vue?vue&type=template&id=34fb5948& ***!
  \*******************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Slider With Input" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeInput) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c(
        "div",
        { staticClass: "d-flex" },
        [
          _c(
            "b-form-group",
            { staticClass: "mr-2" },
            [
              _c(
                "b-form-select",
                {
                  model: {
                    value: _vm.ldot,
                    callback: function ($$v) {
                      _vm.ldot = $$v
                    },
                    expression: "ldot",
                  },
                },
                _vm._l(100, function (n) {
                  return _c(
                    "b-form-select-option",
                    { key: n, attrs: { value: n } },
                    [_vm._v("\n          " + _vm._s(n) + "\n        ")]
                  )
                }),
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-form-group",
            [
              _c("b-form-input", {
                model: {
                  value: _vm.rdot,
                  callback: function ($$v) {
                    _vm.rdot = $$v
                  },
                  expression: "rdot",
                },
              }),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c("vue-slider", {
        attrs: { direction: _vm.direction },
        model: {
          value: _vm.value,
          callback: function ($$v) {
            _vm.value = $$v
          },
          expression: "value",
        },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderLazy.vue?vue&type=template&id=19cef25c&":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderLazy.vue?vue&type=template&id=19cef25c& ***!
  \******************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Lazy Slider" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeLazy) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _vm._v(
          "\n    The value will only be updated when the drag is over\n  "
        ),
      ]),
      _vm._v(" "),
      _c("b-card-text", [_vm._v("value: " + _vm._s(_vm.value))]),
      _vm._v(" "),
      _c("vue-slider", {
        attrs: { lazy: true, direction: _vm.direction },
        model: {
          value: _vm.value,
          callback: function ($$v) {
            _vm.value = $$v
          },
          expression: "value",
        },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderMultiple.vue?vue&type=template&id=1f65186e&":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderMultiple.vue?vue&type=template&id=1f65186e& ***!
  \**********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Multiple Slider" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeMultiple) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [_vm._v("Set multiple value to slider for multiple ")]),
        _vm._v(" "),
        _c("code", [_vm._v("dots")]),
      ]),
      _vm._v(" "),
      _c("vue-slider", {
        staticClass: "mb-2",
        attrs: { direction: _vm.direction },
        model: {
          value: _vm.value_2,
          callback: function ($$v) {
            _vm.value_2 = $$v
          },
          expression: "value_2",
        },
      }),
      _vm._v(" "),
      _c("vue-slider", {
        staticClass: "mb-2",
        attrs: { direction: _vm.direction },
        model: {
          value: _vm.value_3,
          callback: function ($$v) {
            _vm.value_3 = $$v
          },
          expression: "value_3",
        },
      }),
      _vm._v(" "),
      _c("vue-slider", {
        attrs: { direction: _vm.direction },
        model: {
          value: _vm.value_4,
          callback: function ($$v) {
            _vm.value_4 = $$v
          },
          expression: "value_4",
        },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderRangerValue.vue?vue&type=template&id=0f3a8eae&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderRangerValue.vue?vue&type=template&id=0f3a8eae& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Range of values" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeRange) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [_vm._v("Use ")]),
        _vm._v(" "),
        _c("code", [_vm._v("min")]),
        _vm._v(" "),
        _c("span", [_vm._v(" and ")]),
        _vm._v(" "),
        _c("code", [_vm._v("max")]),
        _vm._v(" "),
        _c("span", [_vm._v(" with ")]),
        _vm._v(" "),
        _c("code", [_vm._v("<vue-slider>")]),
        _vm._v(" "),
        _c("span", [_vm._v(" for range slider.")]),
      ]),
      _vm._v(" "),
      _c("vue-slider", {
        attrs: { min: 0, max: 1, direction: _vm.direction, interval: 0.01 },
        model: {
          value: _vm.value,
          callback: function ($$v) {
            _vm.value = $$v
          },
          expression: "value",
        },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderRtl.vue?vue&type=template&id=3ebcc708&":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderRtl.vue?vue&type=template&id=3ebcc708& ***!
  \*****************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "RTL Slider" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeRTL) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [_vm._v("Use ")]),
        _vm._v(" "),
        _c("code", [_vm._v('direction="rtl"')]),
        _vm._v(" "),
        _c("span", [_vm._v(" prop with ")]),
        _vm._v(" "),
        _c("code", [_vm._v("<vue-slider>")]),
        _vm._v(" "),
        _c("span", [_vm._v(" component for rtl.")]),
      ]),
      _vm._v(" "),
      _c("vue-slider", {
        attrs: { direction: "rtl" },
        model: {
          value: _vm.value,
          callback: function ($$v) {
            _vm.value = $$v
          },
          expression: "value",
        },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderSingle.vue?vue&type=template&id=9d9357b4&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderSingle.vue?vue&type=template&id=9d9357b4& ***!
  \********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Single Slider" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeSingle) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("vue-slider", {
        attrs: { direction: _vm.direction },
        model: {
          value: _vm.value,
          callback: function ($$v) {
            _vm.value = $$v
          },
          expression: "value",
        },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderVertical.vue?vue&type=template&id=0dfdb6d4&":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/extensions/slider/SliderVertical.vue?vue&type=template&id=0dfdb6d4& ***!
  \**********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("h4", { staticClass: "card-title" }, [
        _vm._v("\n    VERTICAL SLIDERS\n  "),
      ]),
      _vm._v(" "),
      _vm._m(0),
      _vm._v(" "),
      _c(
        "b-row",
        [
          _c(
            "b-col",
            { attrs: { lg: "4", md: "6" } },
            [
              _c(
                "b-card-code",
                {
                  attrs: { title: "Default Vertical Slider" },
                  scopedSlots: _vm._u([
                    {
                      key: "code",
                      fn: function () {
                        return [
                          _vm._v(
                            "\n          " +
                              _vm._s(_vm.codeVerticalDefault) +
                              "\n        "
                          ),
                        ]
                      },
                      proxy: true,
                    },
                  ]),
                },
                [
                  _c(
                    "div",
                    { staticClass: "d-flex justify-content-center" },
                    [
                      _c("vue-slider", {
                        staticClass: "mr-1",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          process: false,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value,
                          callback: function ($$v) {
                            _vm.value = $$v
                          },
                          expression: "value",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-secondary",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          process: false,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value1,
                          callback: function ($$v) {
                            _vm.value1 = $$v
                          },
                          expression: "value1",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-success",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          process: false,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value2,
                          callback: function ($$v) {
                            _vm.value2 = $$v
                          },
                          expression: "value2",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-warning",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          process: false,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value3,
                          callback: function ($$v) {
                            _vm.value3 = $$v
                          },
                          expression: "value3",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-danger",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          process: false,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value4,
                          callback: function ($$v) {
                            _vm.value4 = $$v
                          },
                          expression: "value4",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-info",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          process: false,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value5,
                          callback: function ($$v) {
                            _vm.value5 = $$v
                          },
                          expression: "value5",
                        },
                      }),
                    ],
                    1
                  ),
                ]
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-col",
            { attrs: { lg: "4", md: "6" } },
            [
              _c(
                "b-card-code",
                {
                  attrs: { title: "Connect to lower" },
                  scopedSlots: _vm._u([
                    {
                      key: "code",
                      fn: function () {
                        return [
                          _vm._v(
                            "\n          " +
                              _vm._s(_vm.codeConntectLower) +
                              "\n        "
                          ),
                        ]
                      },
                      proxy: true,
                    },
                  ]),
                },
                [
                  _c(
                    "div",
                    { staticClass: "d-flex justify-content-center" },
                    [
                      _c("vue-slider", {
                        staticClass: "mr-1",
                        attrs: {
                          direction: "ttb",
                          height: 200,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value6,
                          callback: function ($$v) {
                            _vm.value6 = $$v
                          },
                          expression: "value6",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-secondary",
                        attrs: {
                          direction: "ttb",
                          height: 200,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value7,
                          callback: function ($$v) {
                            _vm.value7 = $$v
                          },
                          expression: "value7",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-success",
                        attrs: {
                          direction: "ttb",
                          height: 200,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value8,
                          callback: function ($$v) {
                            _vm.value8 = $$v
                          },
                          expression: "value8",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-warning",
                        attrs: {
                          direction: "ttb",
                          height: 200,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value9,
                          callback: function ($$v) {
                            _vm.value9 = $$v
                          },
                          expression: "value9",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-danger",
                        attrs: {
                          direction: "ttb",
                          height: 200,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value10,
                          callback: function ($$v) {
                            _vm.value10 = $$v
                          },
                          expression: "value10",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-info",
                        attrs: {
                          direction: "ttb",
                          height: 200,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value11,
                          callback: function ($$v) {
                            _vm.value11 = $$v
                          },
                          expression: "value11",
                        },
                      }),
                    ],
                    1
                  ),
                ]
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-col",
            { attrs: { lg: "4", md: "6" } },
            [
              _c(
                "b-card-code",
                {
                  attrs: { title: "Connect to upper" },
                  scopedSlots: _vm._u([
                    {
                      key: "code",
                      fn: function () {
                        return [
                          _vm._v(
                            "\n          " +
                              _vm._s(_vm.codeConnectUpper) +
                              "\n        "
                          ),
                        ]
                      },
                      proxy: true,
                    },
                  ]),
                },
                [
                  _c(
                    "div",
                    { staticClass: "d-flex justify-content-center" },
                    [
                      _c("vue-slider", {
                        staticClass: "mr-1",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value12,
                          callback: function ($$v) {
                            _vm.value12 = $$v
                          },
                          expression: "value12",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-secondary",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value13,
                          callback: function ($$v) {
                            _vm.value13 = $$v
                          },
                          expression: "value13",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-success",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value14,
                          callback: function ($$v) {
                            _vm.value14 = $$v
                          },
                          expression: "value14",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-warning",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value15,
                          callback: function ($$v) {
                            _vm.value15 = $$v
                          },
                          expression: "value15",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-danger",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value16,
                          callback: function ($$v) {
                            _vm.value16 = $$v
                          },
                          expression: "value16",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-info",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value17,
                          callback: function ($$v) {
                            _vm.value17 = $$v
                          },
                          expression: "value17",
                        },
                      }),
                    ],
                    1
                  ),
                ]
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-col",
            { attrs: { lg: "4", md: "6" } },
            [
              _c(
                "b-card-code",
                {
                  attrs: { title: "Tooltips" },
                  scopedSlots: _vm._u([
                    {
                      key: "code",
                      fn: function () {
                        return [
                          _vm._v(
                            "\n          " +
                              _vm._s(_vm.codeTooltips) +
                              "\n        "
                          ),
                        ]
                      },
                      proxy: true,
                    },
                  ]),
                },
                [
                  _c(
                    "div",
                    { staticClass: "d-flex justify-content-center" },
                    [
                      _c("vue-slider", {
                        staticClass: "mr-4",
                        attrs: {
                          direction: "btt",
                          tooltip: "always",
                          height: 200,
                          process: false,
                        },
                        model: {
                          value: _vm.value18,
                          callback: function ($$v) {
                            _vm.value18 = $$v
                          },
                          expression: "value18",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-4 vue-slider-success",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          process: false,
                          tooltip: "always",
                        },
                        model: {
                          value: _vm.value19,
                          callback: function ($$v) {
                            _vm.value19 = $$v
                          },
                          expression: "value19",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-4 vue-slider-warning",
                        attrs: {
                          direction: "btt",
                          process: false,
                          tooltip: "always",
                          height: 200,
                        },
                        model: {
                          value: _vm.value20,
                          callback: function ($$v) {
                            _vm.value20 = $$v
                          },
                          expression: "value20",
                        },
                      }),
                    ],
                    1
                  ),
                ]
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-col",
            { attrs: { lg: "4", md: "6" } },
            [
              _c(
                "b-card-code",
                {
                  attrs: { title: "Direction Top To Bottom" },
                  scopedSlots: _vm._u([
                    {
                      key: "code",
                      fn: function () {
                        return [
                          _vm._v(
                            "\n          " +
                              _vm._s(_vm.codeTopBottom) +
                              "\n        "
                          ),
                        ]
                      },
                      proxy: true,
                    },
                  ]),
                },
                [
                  _c(
                    "div",
                    { staticClass: "d-flex justify-content-center" },
                    [
                      _c("vue-slider", {
                        staticClass: "mr-4",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          adsorb: true,
                          tooltip: "none",
                          interval: 20,
                          marks: true,
                        },
                        model: {
                          value: _vm.value21,
                          callback: function ($$v) {
                            _vm.value21 = $$v
                          },
                          expression: "value21",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-4 vue-slider-success",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          adsorb: true,
                          data: _vm.data,
                          marks: true,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value22,
                          callback: function ($$v) {
                            _vm.value22 = $$v
                          },
                          expression: "value22",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-4 vue-slider-warning",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          adsorb: true,
                          included: true,
                          marks: _vm.marks,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value23,
                          callback: function ($$v) {
                            _vm.value23 = $$v
                          },
                          expression: "value23",
                        },
                      }),
                    ],
                    1
                  ),
                ]
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-col",
            { attrs: { lg: "4", md: "6" } },
            [
              _c(
                "b-card-code",
                {
                  attrs: { title: "Limit" },
                  scopedSlots: _vm._u([
                    {
                      key: "code",
                      fn: function () {
                        return [
                          _vm._v(
                            "\n          " +
                              _vm._s(_vm.codeLimit) +
                              "\n        "
                          ),
                        ]
                      },
                      proxy: true,
                    },
                  ]),
                },
                [
                  _c(
                    "div",
                    { staticClass: "d-flex justify-content-center" },
                    [
                      _c("vue-slider", {
                        staticClass: "mr-1",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          "min-range": 20,
                          "max-range": 50,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value24,
                          callback: function ($$v) {
                            _vm.value24 = $$v
                          },
                          expression: "value24",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-secondary",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          tooltip: "none",
                          fixed: true,
                        },
                        model: {
                          value: _vm.value25,
                          callback: function ($$v) {
                            _vm.value25 = $$v
                          },
                          expression: "value25",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-success",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          "min-range": 20,
                          "max-range": 50,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value26,
                          callback: function ($$v) {
                            _vm.value26 = $$v
                          },
                          expression: "value26",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-warning",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          tooltip: "none",
                          fixed: true,
                        },
                        model: {
                          value: _vm.value27,
                          callback: function ($$v) {
                            _vm.value27 = $$v
                          },
                          expression: "value27",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-danger",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          "min-range": 20,
                          "max-range": 50,
                          tooltip: "none",
                        },
                        model: {
                          value: _vm.value28,
                          callback: function ($$v) {
                            _vm.value28 = $$v
                          },
                          expression: "value28",
                        },
                      }),
                      _vm._v(" "),
                      _c("vue-slider", {
                        staticClass: "mr-1 vue-slider-info",
                        attrs: {
                          direction: "btt",
                          height: 200,
                          tooltip: "none",
                          fixed: true,
                        },
                        model: {
                          value: _vm.value29,
                          callback: function ($$v) {
                            _vm.value29 = $$v
                          },
                          expression: "value29",
                        },
                      }),
                    ],
                    1
                  ),
                ]
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("span", [_vm._v("When the value of direction is ")]),
      _vm._v(" "),
      _c("code", [_vm._v("btt")]),
      _vm._v(" "),
      _c("span", [_vm._v(" or ")]),
      _vm._v(" "),
      _c("code", [_vm._v("ttb")]),
      _vm._v(" "),
      _c("span", [_vm._v(", you need to set the component height")]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-prism-component/dist/vue-prism-component.common.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/vue-prism-component/dist/vue-prism-component.common.js ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var Prism = _interopDefault(__webpack_require__(/*! prismjs */ "./node_modules/prismjs/prism.js"));

function assign(obj) {
  for (var i = 1; i < arguments.length; i++) {
    // eslint-disable-next-line guard-for-in, prefer-rest-params
    for (var p in arguments[i]) {
      obj[p] = arguments[i][p];
    }
  }

  return obj;
}

var index = {
  functional: true,
  props: {
    code: {
      type: String
    },
    inline: {
      type: Boolean,
      "default": false
    },
    language: {
      type: String,
      "default": 'markup'
    }
  },
  render: function render(h, ctx) {
    var code = ctx.props.code || (ctx.children && ctx.children.length > 0 ? ctx.children[0].text : '');
    var inline = ctx.props.inline;
    var language = ctx.props.language;
    var prismLanguage = Prism.languages[language];
    var className = "language-".concat(language);

    if ( true && !prismLanguage) {
      throw new Error("Prism component for language \"".concat(language, "\" was not found, did you forget to register it? See all available ones: https://cdn.jsdelivr.net/npm/prismjs/components/"));
    }

    if (inline) {
      return h('code', assign({}, ctx.data, {
        "class": [ctx.data["class"], className],
        domProps: assign({}, ctx.data.domProps, {
          innerHTML: Prism.highlight(code, prismLanguage)
        })
      }));
    }

    return h('pre', assign({}, ctx.data, {
      "class": [ctx.data["class"], className]
    }), [h('code', {
      "class": className,
      domProps: {
        innerHTML: Prism.highlight(code, prismLanguage)
      }
    })]);
  }
};

module.exports = index;


/***/ }),

/***/ "./resources/js/src/views/extensions/slider/Slider.vue":
/*!*************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/Slider.vue ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Slider_vue_vue_type_template_id_b3a8a784___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Slider.vue?vue&type=template&id=b3a8a784& */ "./resources/js/src/views/extensions/slider/Slider.vue?vue&type=template&id=b3a8a784&");
/* harmony import */ var _Slider_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Slider.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/slider/Slider.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Slider_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Slider.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/src/views/extensions/slider/Slider.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Slider_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Slider_vue_vue_type_template_id_b3a8a784___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Slider_vue_vue_type_template_id_b3a8a784___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/slider/Slider.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/Slider.vue?vue&type=script&lang=js&":
/*!**************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/Slider.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Slider_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Slider.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/Slider.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Slider_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/Slider.vue?vue&type=style&index=0&lang=scss&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/Slider.vue?vue&type=style&index=0&lang=scss& ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Slider_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/style-loader!../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Slider.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/Slider.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Slider_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Slider_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Slider_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Slider_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/src/views/extensions/slider/Slider.vue?vue&type=template&id=b3a8a784&":
/*!********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/Slider.vue?vue&type=template&id=b3a8a784& ***!
  \********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Slider_vue_vue_type_template_id_b3a8a784___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Slider.vue?vue&type=template&id=b3a8a784& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/Slider.vue?vue&type=template&id=b3a8a784&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Slider_vue_vue_type_template_id_b3a8a784___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Slider_vue_vue_type_template_id_b3a8a784___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderAdsorb.vue":
/*!*******************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderAdsorb.vue ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SliderAdsorb_vue_vue_type_template_id_5760bc8d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SliderAdsorb.vue?vue&type=template&id=5760bc8d& */ "./resources/js/src/views/extensions/slider/SliderAdsorb.vue?vue&type=template&id=5760bc8d&");
/* harmony import */ var _SliderAdsorb_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SliderAdsorb.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/slider/SliderAdsorb.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SliderAdsorb_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SliderAdsorb_vue_vue_type_template_id_5760bc8d___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SliderAdsorb_vue_vue_type_template_id_5760bc8d___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/slider/SliderAdsorb.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderAdsorb.vue?vue&type=script&lang=js&":
/*!********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderAdsorb.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderAdsorb_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderAdsorb.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderAdsorb.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderAdsorb_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderAdsorb.vue?vue&type=template&id=5760bc8d&":
/*!**************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderAdsorb.vue?vue&type=template&id=5760bc8d& ***!
  \**************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderAdsorb_vue_vue_type_template_id_5760bc8d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderAdsorb.vue?vue&type=template&id=5760bc8d& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderAdsorb.vue?vue&type=template&id=5760bc8d&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderAdsorb_vue_vue_type_template_id_5760bc8d___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderAdsorb_vue_vue_type_template_id_5760bc8d___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderBehavior.vue":
/*!*********************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderBehavior.vue ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SliderBehavior_vue_vue_type_template_id_f79198a0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SliderBehavior.vue?vue&type=template&id=f79198a0& */ "./resources/js/src/views/extensions/slider/SliderBehavior.vue?vue&type=template&id=f79198a0&");
/* harmony import */ var _SliderBehavior_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SliderBehavior.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/slider/SliderBehavior.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SliderBehavior_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SliderBehavior_vue_vue_type_template_id_f79198a0___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SliderBehavior_vue_vue_type_template_id_f79198a0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/slider/SliderBehavior.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderBehavior.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderBehavior.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderBehavior_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderBehavior.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderBehavior.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderBehavior_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderBehavior.vue?vue&type=template&id=f79198a0&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderBehavior.vue?vue&type=template&id=f79198a0& ***!
  \****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderBehavior_vue_vue_type_template_id_f79198a0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderBehavior.vue?vue&type=template&id=f79198a0& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderBehavior.vue?vue&type=template&id=f79198a0&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderBehavior_vue_vue_type_template_id_f79198a0___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderBehavior_vue_vue_type_template_id_f79198a0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderColor.vue":
/*!******************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderColor.vue ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SliderColor_vue_vue_type_template_id_14529316___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SliderColor.vue?vue&type=template&id=14529316& */ "./resources/js/src/views/extensions/slider/SliderColor.vue?vue&type=template&id=14529316&");
/* harmony import */ var _SliderColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SliderColor.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/slider/SliderColor.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SliderColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SliderColor_vue_vue_type_template_id_14529316___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SliderColor_vue_vue_type_template_id_14529316___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/slider/SliderColor.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderColor.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderColor.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderColor.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderColor.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderColor.vue?vue&type=template&id=14529316&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderColor.vue?vue&type=template&id=14529316& ***!
  \*************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderColor_vue_vue_type_template_id_14529316___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderColor.vue?vue&type=template&id=14529316& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderColor.vue?vue&type=template&id=14529316&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderColor_vue_vue_type_template_id_14529316___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderColor_vue_vue_type_template_id_14529316___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderContained.vue":
/*!**********************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderContained.vue ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SliderContained_vue_vue_type_template_id_6b183e85___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SliderContained.vue?vue&type=template&id=6b183e85& */ "./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=template&id=6b183e85&");
/* harmony import */ var _SliderContained_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SliderContained.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _SliderContained_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SliderContained.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _SliderContained_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SliderContained_vue_vue_type_template_id_6b183e85___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SliderContained_vue_vue_type_template_id_6b183e85___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/slider/SliderContained.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderContained_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderContained.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderContained_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderContained_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/style-loader!../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderContained.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderContained_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderContained_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderContained_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderContained_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=template&id=6b183e85&":
/*!*****************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=template&id=6b183e85& ***!
  \*****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderContained_vue_vue_type_template_id_6b183e85___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderContained.vue?vue&type=template&id=6b183e85& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderContained.vue?vue&type=template&id=6b183e85&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderContained_vue_vue_type_template_id_6b183e85___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderContained_vue_vue_type_template_id_6b183e85___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderDisabled.vue":
/*!*********************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderDisabled.vue ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SliderDisabled_vue_vue_type_template_id_54cad24c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SliderDisabled.vue?vue&type=template&id=54cad24c& */ "./resources/js/src/views/extensions/slider/SliderDisabled.vue?vue&type=template&id=54cad24c&");
/* harmony import */ var _SliderDisabled_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SliderDisabled.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/slider/SliderDisabled.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SliderDisabled_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SliderDisabled_vue_vue_type_template_id_54cad24c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SliderDisabled_vue_vue_type_template_id_54cad24c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/slider/SliderDisabled.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderDisabled.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderDisabled.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderDisabled_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderDisabled.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderDisabled.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderDisabled_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderDisabled.vue?vue&type=template&id=54cad24c&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderDisabled.vue?vue&type=template&id=54cad24c& ***!
  \****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderDisabled_vue_vue_type_template_id_54cad24c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderDisabled.vue?vue&type=template&id=54cad24c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderDisabled.vue?vue&type=template&id=54cad24c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderDisabled_vue_vue_type_template_id_54cad24c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderDisabled_vue_vue_type_template_id_54cad24c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderInput.vue":
/*!******************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderInput.vue ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SliderInput_vue_vue_type_template_id_34fb5948___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SliderInput.vue?vue&type=template&id=34fb5948& */ "./resources/js/src/views/extensions/slider/SliderInput.vue?vue&type=template&id=34fb5948&");
/* harmony import */ var _SliderInput_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SliderInput.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/slider/SliderInput.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SliderInput_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SliderInput_vue_vue_type_template_id_34fb5948___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SliderInput_vue_vue_type_template_id_34fb5948___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/slider/SliderInput.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderInput.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderInput.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderInput_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderInput.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderInput.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderInput_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderInput.vue?vue&type=template&id=34fb5948&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderInput.vue?vue&type=template&id=34fb5948& ***!
  \*************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderInput_vue_vue_type_template_id_34fb5948___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderInput.vue?vue&type=template&id=34fb5948& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderInput.vue?vue&type=template&id=34fb5948&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderInput_vue_vue_type_template_id_34fb5948___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderInput_vue_vue_type_template_id_34fb5948___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderLazy.vue":
/*!*****************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderLazy.vue ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SliderLazy_vue_vue_type_template_id_19cef25c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SliderLazy.vue?vue&type=template&id=19cef25c& */ "./resources/js/src/views/extensions/slider/SliderLazy.vue?vue&type=template&id=19cef25c&");
/* harmony import */ var _SliderLazy_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SliderLazy.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/slider/SliderLazy.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SliderLazy_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SliderLazy_vue_vue_type_template_id_19cef25c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SliderLazy_vue_vue_type_template_id_19cef25c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/slider/SliderLazy.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderLazy.vue?vue&type=script&lang=js&":
/*!******************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderLazy.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderLazy_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderLazy.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderLazy.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderLazy_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderLazy.vue?vue&type=template&id=19cef25c&":
/*!************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderLazy.vue?vue&type=template&id=19cef25c& ***!
  \************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderLazy_vue_vue_type_template_id_19cef25c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderLazy.vue?vue&type=template&id=19cef25c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderLazy.vue?vue&type=template&id=19cef25c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderLazy_vue_vue_type_template_id_19cef25c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderLazy_vue_vue_type_template_id_19cef25c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderMultiple.vue":
/*!*********************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderMultiple.vue ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SliderMultiple_vue_vue_type_template_id_1f65186e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SliderMultiple.vue?vue&type=template&id=1f65186e& */ "./resources/js/src/views/extensions/slider/SliderMultiple.vue?vue&type=template&id=1f65186e&");
/* harmony import */ var _SliderMultiple_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SliderMultiple.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/slider/SliderMultiple.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SliderMultiple_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SliderMultiple_vue_vue_type_template_id_1f65186e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SliderMultiple_vue_vue_type_template_id_1f65186e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/slider/SliderMultiple.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderMultiple.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderMultiple.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderMultiple_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderMultiple.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderMultiple.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderMultiple_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderMultiple.vue?vue&type=template&id=1f65186e&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderMultiple.vue?vue&type=template&id=1f65186e& ***!
  \****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderMultiple_vue_vue_type_template_id_1f65186e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderMultiple.vue?vue&type=template&id=1f65186e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderMultiple.vue?vue&type=template&id=1f65186e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderMultiple_vue_vue_type_template_id_1f65186e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderMultiple_vue_vue_type_template_id_1f65186e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderRangerValue.vue":
/*!************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderRangerValue.vue ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SliderRangerValue_vue_vue_type_template_id_0f3a8eae___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SliderRangerValue.vue?vue&type=template&id=0f3a8eae& */ "./resources/js/src/views/extensions/slider/SliderRangerValue.vue?vue&type=template&id=0f3a8eae&");
/* harmony import */ var _SliderRangerValue_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SliderRangerValue.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/slider/SliderRangerValue.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SliderRangerValue_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SliderRangerValue_vue_vue_type_template_id_0f3a8eae___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SliderRangerValue_vue_vue_type_template_id_0f3a8eae___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/slider/SliderRangerValue.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderRangerValue.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderRangerValue.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderRangerValue_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderRangerValue.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderRangerValue.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderRangerValue_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderRangerValue.vue?vue&type=template&id=0f3a8eae&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderRangerValue.vue?vue&type=template&id=0f3a8eae& ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderRangerValue_vue_vue_type_template_id_0f3a8eae___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderRangerValue.vue?vue&type=template&id=0f3a8eae& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderRangerValue.vue?vue&type=template&id=0f3a8eae&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderRangerValue_vue_vue_type_template_id_0f3a8eae___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderRangerValue_vue_vue_type_template_id_0f3a8eae___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderRtl.vue":
/*!****************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderRtl.vue ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SliderRtl_vue_vue_type_template_id_3ebcc708___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SliderRtl.vue?vue&type=template&id=3ebcc708& */ "./resources/js/src/views/extensions/slider/SliderRtl.vue?vue&type=template&id=3ebcc708&");
/* harmony import */ var _SliderRtl_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SliderRtl.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/slider/SliderRtl.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SliderRtl_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SliderRtl_vue_vue_type_template_id_3ebcc708___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SliderRtl_vue_vue_type_template_id_3ebcc708___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/slider/SliderRtl.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderRtl.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderRtl.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderRtl_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderRtl.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderRtl.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderRtl_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderRtl.vue?vue&type=template&id=3ebcc708&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderRtl.vue?vue&type=template&id=3ebcc708& ***!
  \***********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderRtl_vue_vue_type_template_id_3ebcc708___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderRtl.vue?vue&type=template&id=3ebcc708& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderRtl.vue?vue&type=template&id=3ebcc708&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderRtl_vue_vue_type_template_id_3ebcc708___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderRtl_vue_vue_type_template_id_3ebcc708___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderSingle.vue":
/*!*******************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderSingle.vue ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SliderSingle_vue_vue_type_template_id_9d9357b4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SliderSingle.vue?vue&type=template&id=9d9357b4& */ "./resources/js/src/views/extensions/slider/SliderSingle.vue?vue&type=template&id=9d9357b4&");
/* harmony import */ var _SliderSingle_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SliderSingle.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/slider/SliderSingle.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SliderSingle_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SliderSingle_vue_vue_type_template_id_9d9357b4___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SliderSingle_vue_vue_type_template_id_9d9357b4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/slider/SliderSingle.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderSingle.vue?vue&type=script&lang=js&":
/*!********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderSingle.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderSingle_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderSingle.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderSingle.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderSingle_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderSingle.vue?vue&type=template&id=9d9357b4&":
/*!**************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderSingle.vue?vue&type=template&id=9d9357b4& ***!
  \**************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderSingle_vue_vue_type_template_id_9d9357b4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderSingle.vue?vue&type=template&id=9d9357b4& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderSingle.vue?vue&type=template&id=9d9357b4&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderSingle_vue_vue_type_template_id_9d9357b4___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderSingle_vue_vue_type_template_id_9d9357b4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderVertical.vue":
/*!*********************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderVertical.vue ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SliderVertical_vue_vue_type_template_id_0dfdb6d4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SliderVertical.vue?vue&type=template&id=0dfdb6d4& */ "./resources/js/src/views/extensions/slider/SliderVertical.vue?vue&type=template&id=0dfdb6d4&");
/* harmony import */ var _SliderVertical_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SliderVertical.vue?vue&type=script&lang=js& */ "./resources/js/src/views/extensions/slider/SliderVertical.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SliderVertical_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SliderVertical_vue_vue_type_template_id_0dfdb6d4___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SliderVertical_vue_vue_type_template_id_0dfdb6d4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/extensions/slider/SliderVertical.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderVertical.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderVertical.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderVertical_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderVertical.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderVertical.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderVertical_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/extensions/slider/SliderVertical.vue?vue&type=template&id=0dfdb6d4&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/SliderVertical.vue?vue&type=template&id=0dfdb6d4& ***!
  \****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderVertical_vue_vue_type_template_id_0dfdb6d4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./SliderVertical.vue?vue&type=template&id=0dfdb6d4& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/extensions/slider/SliderVertical.vue?vue&type=template&id=0dfdb6d4&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderVertical_vue_vue_type_template_id_0dfdb6d4___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SliderVertical_vue_vue_type_template_id_0dfdb6d4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/extensions/slider/code.js":
/*!**********************************************************!*\
  !*** ./resources/js/src/views/extensions/slider/code.js ***!
  \**********************************************************/
/*! exports provided: codeSingle, codeMultiple, codeRange, codeRTL, codeLazy, codeDisabled, codeAdsorb, codeContained, codebehavior, codeColors, codeInput, codeVerticalDefault, codeConntectLower, codeConnectUpper, codeTooltips, codeTopBottom, codeLimit */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeSingle", function() { return codeSingle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeMultiple", function() { return codeMultiple; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeRange", function() { return codeRange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeRTL", function() { return codeRTL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeLazy", function() { return codeLazy; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeDisabled", function() { return codeDisabled; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeAdsorb", function() { return codeAdsorb; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeContained", function() { return codeContained; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codebehavior", function() { return codebehavior; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeColors", function() { return codeColors; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeInput", function() { return codeInput; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeVerticalDefault", function() { return codeVerticalDefault; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeConntectLower", function() { return codeConntectLower; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeConnectUpper", function() { return codeConnectUpper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeTooltips", function() { return codeTooltips; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeTopBottom", function() { return codeTopBottom; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeLimit", function() { return codeLimit; });
var codeSingle = "\n<template>\n  <vue-slider\n    v-model=\"value\"\n    :direction=\"direction\"\n  />\n</template>\n\n<script>\nimport VueSlider from 'vue-slider-component'\nimport store from '@/store/index'\n\nexport default {\n  components: {\n    VueSlider,\n  },\n  data() {\n    return {\n      value: 50,\n      dir: 'ltr',\n    }\n  },\n  computed: {\n    direction() {\n      if (store.state.appConfig.isRTL) {\n        // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n        this.dir = 'rtl'\n        return this.dir\n      }\n      // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n      this.dir = 'ltr'\n      return this.dir\n    },\n  },\n}\n</script>\n";
var codeMultiple = "\n<template>\n  <div>\n    <b-card-text>\n      <span>Set multiple value to slider for multiple </span>\n      <code>dots</code>\n    </b-card-text>\n\n    <!-- sliders -->\n    <vue-slider\n      v-model=\"value_2\"\n      :direction=\"direction\"\n      class=\"mb-2\"\n    />\n    <vue-slider\n      v-model=\"value_3\"\n      :direction=\"direction\"\n      class=\"mb-2\"\n    />\n    <vue-slider\n      v-model=\"value_4\"\n      :direction=\"direction\"\n    />\n  </div> \n</template>\n\n<script>\nimport VueSlider from 'vue-slider-component'\nimport store from '@/store/index'\n\nexport default {\n  components: {\n    VueSlider,\n  },\n  data() {\n    return {\n      value_2: [0, 50],\n      value_3: [0, 50, 80],\n      value_4: [0, 50, 80, 100],\n      dir: 'ltr',\n    }\n  },\n  computed: {\n    direction() {\n      if (store.state.appConfig.isRTL) {\n        // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n        this.dir = 'rtl'\n        return this.dir\n      }\n      // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n      this.dir = 'ltr'\n      return this.dir\n    },\n  },\n}\n</script>\n";
var codeRange = "\n<template>\n  <!-- slider -->\n  <vue-slider\n    v-model=\"value\"\n    :min=\"0\"\n    :max=\"1\"\n    :direction=\"direction\"\n    :interval=\"0.01\"\n  />\n</template>\n\n<script>\nimport VueSlider from 'vue-slider-component'\nimport store from '@/store/index'\n\nexport default {\n  components: {\n    VueSlider,\n  },\n  data() {\n    return {\n      value: 0.3,\n      dir: 'ltr',\n    }\n  },\n  computed: {\n    direction() {\n      if (store.state.appConfig.isRTL) {\n        // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n        this.dir = 'rtl'\n        return this.dir\n      }\n      // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n      this.dir = 'ltr'\n      return this.dir\n    },\n  },\n}\n</script>\n";
var codeRTL = "\n<template>\n  <!-- slider -->\n  <vue-slider\n    v-model=\"value\"\n    direction=\"rtl\"\n  />\n</template>\n\n<script>\nimport VueSlider from 'vue-slider-component'\n\nexport default {\n  components: {\n    VueSlider,\n  },\n  data() {\n    return {\n      value: 50,\n    }\n  },\n}\n</script>\n";
var codeLazy = "\n<template>\n  <div>\n    <b-card-text>value: {{ value }}</b-card-text>\n\n    <!-- slider -->\n    <vue-slider\n      v-model=\"value\"\n      :lazy=\"true\"\n      :direction=\"direction\"\n    />\n  </div>\n</template>\n\n<script>\nimport { BCardText } from 'bootstrap-vue'\nimport VueSlider from 'vue-slider-component'\nimport store from '@/store/index'\n\nexport default {\n  components: {\n    VueSlider,\n  },\n  data() {\n    return {\n      value: 0,\n      dir: 'ltr',\n    }\n  },\n  computed: {\n    direction() {\n      if (store.state.appConfig.isRTL) {\n        // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n        this.dir = 'rtl'\n        return this.dir\n      }\n      // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n      this.dir = 'ltr'\n      return this.dir\n    },\n  },\n}\n</script>\n";
var codeDisabled = "\n<template>\n  <div>\n    <!--disabled slider -->\n    <vue-slider\n      v-model=\"value1\"\n      :disabled=\"true\"\n      class=\"mb-2\"\n      :direction=\"direction\"\n    />\n\n    <!-- disabled dot -->\n    <vue-slider\n      v-model=\"value2\"\n      :dot-options=\"dotOptions\"\n      :order=\"false\"\n      :direction=\"direction\"\n    />\n  </div>\n</template>\n\n<script>\nimport VueSlider from 'vue-slider-component'\nimport store from '@/store/index'\n\nexport default {\n  components: {\n    VueSlider,\n  },\n  data() {\n    return {\n      dir: 'ltr',\n      value1: 0,\n      value2: [0, 50],\n      dotOptions: [{\n        disabled: false,\n      }, {\n        disabled: true,\n      }],\n    }\n  },\n  computed: {\n    direction() {\n      if (store.state.appConfig.isRTL) {\n        // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n        this.dir = 'rtl'\n        return this.dir\n      }\n      // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n      this.dir = 'ltr'\n      return this.dir\n    },\n  },\n}\n</script>\n";
var codeAdsorb = "\n<template>\n  <div>\n    <vue-slider\n      v-model=\"value1\"\n      :adsorb=\"true\"\n      :interval=\"10\"\n      :marks=\"true\"\n      class=\"mb-3\"\n      :direction=\"direction\"\n    />\n    <vue-slider\n      v-model=\"value2\"\n      :adsorb=\"true\"\n      :data=\"data\"\n      :marks=\"true\"\n      class=\"mb-3\"\n      :direction=\"direction\"\n    />\n    <vue-slider\n      v-model=\"value3\"\n      :adsorb=\"true\"\n      :marks=\"marks\"\n      :included=\"true\"\n      class=\"mb-2\"\n      :direction=\"direction\"\n    />\n  </div>\n</template>\n\n<script>\nimport VueSlider from 'vue-slider-component'\nimport store from '@/store/index'\n\nexport default {\n  components: {\n    VueSlider,\n  },\n  data() {\n    return {\n      value1: 20,\n      value2: 'c',\n      value3: 60,\n      data: ['a', 'b', 'c', 'd', 'e', 'f', 'g'],\n      marks: [0, 10, 30, 60, 100],\n      dir: 'ltr',\n    }\n  },\n  computed: {\n    direction() {\n      if (store.state.appConfig.isRTL) {\n        // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n        this.dir = 'rtl'\n        return this.dir\n      }\n      // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n      this.dir = 'ltr'\n      return this.dir\n    },\n  },\n}\n</script>\n";
var codeContained = "\n<template>\n  <!-- contatined -->\n  <div class=\"wrap\">\n    <vue-slider :direction=\"direction\" />\n    <b-card-text>contained: false</b-card-text>\n    <vue-slider\n      :direction=\"direction\"\n      :contained=\"true\"\n    />\n    <b-card-text>contained: true</b-card-text>\n  </div>\n</template>\n\n<script>\nimport { BCardText } from 'bootstrap-vue'\nimport VueSlider from 'vue-slider-component'\nimport store from '@/store/index'\n\nexport default {\n  components: {\n    BCardText,\n    VueSlider,\n  },\n  data() {\n    return {\n      value: 50,\n      dir: 'ltr',\n    }\n  },\n  computed: {\n    direction() {\n      if (store.state.appConfig.isRTL) {\n        // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n        this.dir = 'rtl'\n        return this.dir\n      }\n      // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n      this.dir = 'ltr'\n      return this.dir\n    },\n  },\n}\n</script>\n\n<style lang=\"scss\" >\n// container style\n.wrap {\n  border-left: 1px dashed #ddd;\n  border-right: 1px dashed #ddd;\n  padding: 10px 0;\n}\n</style>\n";
var codebehavior = "\n<template>\n  <div>\n\n    <!-- default slider -->\n    <h6>Default</h6>\n    <b-card-text>It is the default behavior of slider.</b-card-text>\n\n    <!-- slider -->\n    <vue-slider\n      v-model=\"value\"\n      :direction=\"direction\"\n    />\n\n    <!-- drang and click slider -->\n    <h6 class=\"mt-2\">\n      Drag on Click\n    </h6>\n    <b-card-text>\n      <span>When </span>\n      <code>drag-on-click</code>\n      <span> is set to </span>\n      <code>true</code>\n      <span>, can drag the slider directly when pressing the process.</span>\n    </b-card-text>\n\n    <!-- slider -->\n    <vue-slider\n      v-model=\"value1\"\n      :direction=\"direction\"\n      :drag-on-click=\"true\"\n    />\n\n    <!-- process not filled slider -->\n    <h6 class=\"mt-2\">\n      Process not filled\n    </h6>\n    <b-card-text>\n      <span>User </span>\n      <code>process</code>\n      <span> prop false for unfill the processbar.</span>\n    </b-card-text>\n\n    <!-- slider -->\n    <vue-slider\n      v-model=\"value2\"\n      :direction=\"direction\"\n      :process=\"false\"\n    />\n\n    <!-- min and max slider -->\n    <h6 class=\"mt-2\">\n      Min & Max\n    </h6>\n    <b-card-text>\n      <span>Use </span>\n      <code>min-range</code>\n      <span> and </span>\n      <code>max-range</code>\n      <span> prop to limit the slider.</span>\n    </b-card-text>\n\n    <!-- slider -->\n    <vue-slider\n      v-model=\"value3\"\n      :min-range=\"10\"\n      :direction=\"direction\"\n      :max-range=\"50\"\n    />\n\n    <!-- fixed slider  -->\n    <h6 class=\"mt-2\">\n      Fixed\n    </h6>\n    <b-card-text>\n      <span>Use </span>]\n      <code>fixed</code>\n      <span> prop to fixed the slider.</span>\n    </b-card-text>\n\n    <!-- slider -->\n    <vue-slider\n      v-model=\"value4\"\n      :direction=\"direction\"\n      :fixed=\"true\"\n    />\n  </div>\n</template>\n\n<script>\nimport { BCardText } from 'bootstrap-vue'\nimport VueSlider from 'vue-slider-component'\nimport store from '@/store/index'\n\nexport default {\n  components: {\n    VueSlider,\n    BCardText,\n  },\n  data() {\n    return {\n      value: 10,\n      value1: 30,\n      value2: 50,\n      value3: [10, 40],\n      value4: [10, 50],\n      dir: 'ltr',\n    }\n  },\n  computed: {\n    direction() {\n      if (store.state.appConfig.isRTL) {\n        // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n        this.dir = 'rtl'\n        return this.dir\n      }\n      // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n      this.dir = 'ltr'\n      return this.dir\n    },\n  },\n}\n</script>\n";
var codeColors = "\n<template>\n  <div>\n    <!-- primary -->\n    <h6>Default / Primary Color Slider</h6>\n    <vue-slider\n      v-model=\"value\"\n      :tooltip=\"'none'\"\n      :direction=\"direction\"\n      class=\"mb-2\"\n    />\n\n    <!-- secondary -->\n    <h6>Secondary Color Slider</h6>\n    <vue-slider\n      v-model=\"value1\"\n      :tooltip=\"'none'\"\n      class=\"mb-2 vue-slider-secondary\"\n      :direction=\"direction\"\n    />\n\n    <!-- success -->\n    <h6>Success Color Slider</h6>\n    <vue-slider\n      v-model=\"value2\"\n      :tooltip=\"'none'\"\n      class=\"mb-2 vue-slider-success\"\n      :direction=\"direction\"\n    />\n\n    <!-- danger -->\n    <h6>Danger Color Slider</h6>\n    <vue-slider\n      v-model=\"value4\"\n      :tooltip=\"'none'\"\n      class=\"mb-2 vue-slider-danger\"\n      :direction=\"direction\"\n      :fixed=\"true\"\n    />\n\n    <!-- warning -->\n    <h6>Warning Color Slider</h6>\n    <vue-slider\n      v-model=\"value3\"\n      :tooltip=\"'none'\"\n      class=\"mb-2 vue-slider-warning\"\n      :direction=\"direction\"\n    />\n\n    <!-- info -->\n    <h6>Info Color Slider</h6>\n    <vue-slider\n      v-model=\"value5\"\n      :tooltip=\"'none'\"\n      :min-range=\"20\"\n      :max-range=\"50\"\n      class=\"mb-2 vue-slider-info\"\n      :direction=\"direction\"\n    />\n  </div>\n</template>\n\n<script>\nimport VueSlider from 'vue-slider-component'\nimport store from '@/store/index'\n\nexport default {\n  components: {\n    VueSlider,\n  },\n  data() {\n    return {\n      value: 50,\n      value1: [0, 50],\n      value2: [0, 30, 100],\n      value3: 45,\n      value4: [30, 60],\n      value5: [20, 40],\n      value6: [0, 20, 40, 60, 80, 100],\n      dir: 'ltr',\n    }\n  },\n  computed: {\n    direction() {\n      if (store.state.appConfig.isRTL) {\n        // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n        this.dir = 'rtl'\n        return this.dir\n      }\n      // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n      this.dir = 'ltr'\n      return this.dir\n    },\n  },\n}\n</script>\n";
var codeInput = "\n<template>\n  <div>\n    <!-- input -->\n    <div class=\"d-flex\">\n      <b-form-group class=\"mr-2\">\n        <b-form-select\n          v-model=\"ldot\"\n        >\n          <b-form-select-option\n            v-for=\"n in 100\"\n            :key=\"n\"\n            :value=\"n\"\n          >\n            {{ n }}\n          </b-form-select-option>\n        </b-form-select>\n      </b-form-group>\n      <b-form-group>\n        <b-form-input\n          v-model=\"rdot\"\n        />\n      </b-form-group>\n    </div>\n\n    <!-- slider -->\n    <vue-slider\n      v-model=\"value\"\n      :direction=\"direction\"\n    />\n  </div>\n</template>\n\n<script>\nimport {\n  BFormSelect, BFormSelectOption, BFormGroup, BFormInput,\n} from 'bootstrap-vue'\nimport VueSlider from 'vue-slider-component'\nimport store from '@/store/index'\n\nexport default {\n  components: {\n    VueSlider,\n    BFormSelect,\n    BFormGroup,\n    BFormInput,\n    BFormSelectOption,\n  },\n  data() {\n    return {\n      ldot: 1,\n      rdot: 50,\n      dir: 'ltr',\n    }\n  },\n  computed: {\n    value: {\n      get() {\n        return [this.ldot, this.rdot]\n      },\n      set([ldot, rdot]) {\n        this.ldot = ldot\n        this.rdot = rdot\n      },\n    },\n    direction() {\n      if (store.state.appConfig.isRTL) {\n        // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n        this.dir = 'rtl'\n        return this.dir\n      }\n      // eslint-disable-next-line vue/no-side-effects-in-computed-properties\n      this.dir = 'ltr'\n      return this.dir\n    },\n  },\n}\n</script>\n";
var codeVerticalDefault = "\n<template>\n  <div class=\"d-flex justify-content-center\">\n    <vue-slider\n      v-model=\"value\"\n      direction=\"btt\"\n      :height=\"200\"\n      :process=\"false\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#7267f0'}\"\n    />\n    <vue-slider\n      v-model=\"value1\"\n      direction=\"btt\"\n      :height=\"200\"\n      :process=\"false\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#82868B'}\"\n    />\n    <vue-slider\n      v-model=\"value2\"\n      direction=\"btt\"\n      :height=\"200\"\n      :process=\"false\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#28C76F'}\"\n    />\n    <vue-slider\n      v-model=\"value3\"\n      direction=\"btt\"\n      :height=\"200\"\n      :process=\"false\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#FF9F43'}\"\n    />\n    <vue-slider\n      v-model=\"value4\"\n      direction=\"btt\"\n      :height=\"200\"\n      :process=\"false\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#EA5455'}\"\n    />\n    <vue-slider\n      v-model=\"value5\"\n      direction=\"btt\"\n      :height=\"200\"\n      :process=\"false\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#00CFE8'}\"\n    />\n  </div>\n</template>\n\n<script>\nimport VueSlider from 'vue-slider-component'\n\nexport default {\n  components: {\n    VueSlider,\n  },\n  data() {\n    return {\n      value: 60,\n      value1: 50,\n      value2: 40,\n      value3: 60,\n      value4: 70,\n      value5: 85,\n    }\n  },\n}\n</script>\n";
var codeConntectLower = "\n<template>\n  <div class=\"d-flex justify-content-center\">\n    <vue-slider\n      v-model=\"value\"\n      direction=\"ttb\"\n      :height=\"200\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#7267f0'}\"\n    />\n    <vue-slider\n      v-model=\"value1\"\n      direction=\"ttb\"\n      :height=\"200\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#82868B'}\"\n      :process-style=\"{backgroundColor:'#82868B'}\"\n    />\n    <vue-slider\n      v-model=\"value2\"\n      direction=\"ttb\"\n      :height=\"200\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#28C76F'}\"\n      :process-style=\"{backgroundColor:'#28C76F'}\"\n    />\n    <vue-slider\n      v-model=\"value3\"\n      direction=\"ttb\"\n      :height=\"200\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#FF9F43'}\"\n      :process-style=\"{backgroundColor:'#FF9F43'}\"\n    />\n    <vue-slider\n      v-model=\"value4\"\n      direction=\"ttb\"\n      :height=\"200\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#EA5455'}\"\n      :process-style=\"{backgroundColor:'#EA5455'}\"\n    />\n    <vue-slider\n      v-model=\"value5\"\n      direction=\"ttb\"\n      :height=\"200\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#00CFE8'}\"\n      :process-style=\"{backgroundColor:'#00CFE8'}\"\n    />\n  </div>\n</template>\n\n<script>\nimport VueSlider from 'vue-slider-component'\n\nexport default {\n  components: {\n    VueSlider,\n  },\n  data() {\n    return {\n      value: 60,\n      value1: 50,\n      value2: 40,\n      value3: 60,\n      value4: 70,\n      value5: 85,\n    }\n  },\n}\n</script>\n";
var codeConnectUpper = "\n<template>\n  <div class=\"d-flex justify-content-center\">\n    <vue-slider\n      v-model=\"value\"\n      direction=\"btt\"\n      :height=\"200\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#7267f0'}\"\n    />\n    <vue-slider\n      v-model=\"value1\"\n      direction=\"btt\"\n      :height=\"200\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#82868B'}\"\n      :process-style=\"{backgroundColor:'#82868B'}\"\n    />\n    <vue-slider\n      v-model=\"value2\"\n      direction=\"btt\"\n      :height=\"200\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#28C76F'}\"\n      :process-style=\"{backgroundColor:'#28C76F'}\"\n    />\n    <vue-slider\n      v-model=\"value3\"\n      direction=\"btt\"\n      :height=\"200\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#FF9F43'}\"\n      :process-style=\"{backgroundColor:'#FF9F43'}\"\n    />\n    <vue-slider\n      v-model=\"value4\"\n      direction=\"btt\"\n      :height=\"200\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#EA5455'}\"\n      :process-style=\"{backgroundColor:'#EA5455'}\"\n    />\n    <vue-slider\n      v-model=\"value5\"\n      direction=\"btt\"\n      :height=\"200\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#00CFE8'}\"\n      :process-style=\"{backgroundColor:'#00CFE8'}\"\n    />\n  </div>\n</template>\n\n<script>\nimport VueSlider from 'vue-slider-component'\n\nexport default {\n  components: {\n    VueSlider,\n  },\n  data() {\n    return {\n      value: 60,\n      value1: 50,\n      value2: 40,\n      value3: 60,\n      value4: 70,\n      value5: 85,\n    }\n  },\n}\n</script>\n";
var codeTooltips = "\n<template>\n  <div class=\"d-flex justify-content-center\">\n    <vue-slider\n      v-model=\"value\"\n      direction=\"btt\"\n      :tooltip=\"'always'\"\n      :height=\"200\"\n      class=\"mr-4\"\n      :process=\"false\"\n      :dot-style=\"{backgroundColor:'#7267f0'}\"\n    />\n    <vue-slider\n      v-model=\"value5\"\n      direction=\"btt\"\n      :height=\"200\"\n      :process=\"false\"\n      :tooltip=\"'always'\"\n      class=\"mr-4\"\n      :dot-style=\"{backgroundColor:'#28C76F'}\"\n    />\n    <vue-slider\n      v-model=\"value3\"\n      direction=\"btt\"\n      :process=\"false\"\n      :tooltip=\"'always'\"\n      :height=\"200\"\n      class=\"mr-4\"\n      :dot-style=\"{backgroundColor:'#FF9F43'}\"\n    />\n  </div>\n</template>\n\n<script>\nimport BCardCode from '@core/components/b-card-code/BCardCode.vue'\nimport { BRow, BCol } from 'bootstrap-vue'\nimport VueSlider from 'vue-slider-component'\n\nexport default {\n  components: {\n    VueSlider,\n    BCardCode,\n    BRow,\n    BCol,\n  },\n  data() {\n    return {\n      value1: 50,\n      value3: 60,\n      value5: 85,\n    }\n  },\n}\n</script>\n";
var codeTopBottom = "\n<template>\n  <div class=\"d-flex justify-content-center\">\n    <vue-slider\n      v-model=\"value\"\n      direction=\"btt\"\n      :height=\"200\"\n      class=\"mr-4\"\n      :adsorb=\"true\"\n      :tooltip=\"'none'\"\n      :interval=\"20\"\n      :marks=\"true\"\n      :dot-style=\"{backgroundColor:'#7267f0'}\"\n    />\n    <vue-slider\n      v-model=\"value6\"\n      direction=\"btt\"\n      :height=\"200\"\n      :adsorb=\"true\"\n      :data=\"data\"\n      :marks=\"true\"\n      class=\"mr-4\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#28C76F'}\"\n      :process-style=\"{backgroundColor:'#28C76F'}\"\n    />\n    <vue-slider\n      v-model=\"value3\"\n      direction=\"btt\"\n      :height=\"200\"\n      :adsorb=\"true\"\n      :included=\"true\"\n      :marks=\"marks\"\n      class=\"mr-4\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#FF9F43'}\"\n      :process-style=\"{backgroundColor:'#FF9F43'}\"\n    />\n  </div>\n</template>\n\n<script>\nimport VueSlider from 'vue-slider-component'\n\nexport default {\n  components: {\n    VueSlider,\n  },\n  data() {\n    return {\n      value: 60,\n      value3: 60,\n      value6: 'a',\n      data: ['a', 'b', 'c', 'd', 'e'],\n      marks: [0, 10, 30, 60, 100],\n    }\n  },\n}\n</script>\n";
var codeLimit = "\n<template>\n  <div class=\"d-flex justify-content-center\">\n    <vue-slider\n      v-model=\"value7\"\n      direction=\"btt\"\n      :height=\"200\"\n      :min-range=\"20\"\n      :max-range=\"50\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#7267f0'}\"\n    />\n    <vue-slider\n      v-model=\"value8\"\n      direction=\"btt\"\n      :height=\"200\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :fixed=\"true\"\n      :dot-style=\"{backgroundColor:'#82868B'}\"\n      :process-style=\"{backgroundColor:'#82868B'}\"\n    />\n    <vue-slider\n      v-model=\"value7\"\n      direction=\"btt\"\n      :height=\"200\"\n      :min-range=\"20\"\n      :max-range=\"50\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#28C76F'}\"\n      :process-style=\"{backgroundColor:'#28C76F'}\"\n    />\n    <vue-slider\n      v-model=\"value8\"\n      direction=\"btt\"\n      :height=\"200\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :fixed=\"true\"\n      :dot-style=\"{backgroundColor:'#FF9F43'}\"\n      :process-style=\"{backgroundColor:'#FF9F43'}\"\n    />\n    <vue-slider\n      v-model=\"value7\"\n      direction=\"btt\"\n      :height=\"200\"\n      :min-range=\"20\"\n      :max-range=\"50\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :dot-style=\"{backgroundColor:'#EA5455'}\"\n      :process-style=\"{backgroundColor:'#EA5455'}\"\n    />\n    <vue-slider\n      v-model=\"value8\"\n      direction=\"btt\"\n      :height=\"200\"\n      class=\"mr-1\"\n      :tooltip=\"'none'\"\n      :fixed=\"true\"\n      :dot-style=\"{backgroundColor:'#00CFE8'}\"\n      :process-style=\"{backgroundColor:'#00CFE8'}\"\n    />\n  </div>\n</template>\n\n<script>\nimport VueSlider from 'vue-slider-component'\n\nexport default {\n  components: {\n    VueSlider,\n  },\n  data() {\n    return {\n      value7: [20, 50],\n      value8: [40, 80],\n    }\n  },\n}\n</script>\n";

/***/ })

}]);