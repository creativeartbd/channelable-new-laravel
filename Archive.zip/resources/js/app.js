require("./src/main.js");
