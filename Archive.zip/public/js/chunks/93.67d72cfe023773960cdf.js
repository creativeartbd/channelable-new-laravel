(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[93],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter.js */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.symbol.description.js */ "./node_modules/core-js/modules/es.symbol.description.js");
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");





//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_6__["BButton"]
  },
  data: function data() {
    return {
      old_password: '',
      new_password: '',
      confirm_new_password: '',
      popupActive: false,
      name: '',
      xml_file_url: '',
      projectFields: {},
      xmlFields: {},
      http: 'http',
      authentication: 'no_authentication',
      encoding: 0,
      activeTab: 'setting',
      no_action: 'no_action',
      title: true,
      description: true,
      image: true,
      productMappings: {
        importField: '',
        internalChannableField: '',
        isCustom: false
      }
    };
  },
  computed: {
    activeUserInfo: function activeUserInfo() {
      return this.$store.state.AppActiveUser;
    },
    validateForm: function validateForm() {
      return (
        /*!this.errors.any() && */
        this.name !== '' && this.xml_file_url !== '' && this.http !== '' && this.authentication !== '' && this.encoding !== ''
      );
    }
  },
  methods: {
    continueXml: function continueXml() {
      var _this = this;

      this.$vs.loading({
        background: this.backgroundLoading,
        color: this.colorLoading,
        container: '#button-with-loading',
        scale: 0.45
      });

      if (this.validateForm) {
        axios__WEBPACK_IMPORTED_MODULE_5___default.a.post('xml-import', {
          name: this.name,
          xml_file_url: this.xml_file_url
        }).then(function (response) {
          _this.projectFields = response.data;
          _this.activeTab = 'mapping';

          _this.$vs.loading.close('#button-with-loading > .con-vs-loading');
        })["catch"](function (error) {
          _this.$vs.loading.close('#button-with-loading > .con-vs-loading');
        });
      }
    },
    tab: function tab(_tab) {
      this.activeTab = _tab;
    },
    saveImport: function saveImport() {
      console.log(this.productMappings);
      this.activeTab = 'safety';
    },
    existCustom: function existCustom(value) {
      var obj = this.xmlFields.filter(function (elem) {
        if (elem.field_title == value) return elem.field_title;
      });

      if (obj.length > 0) {
        return true;
      } else {
        return false;
      }
    },
    getXmlFields: function getXmlFields() {
      var _this2 = this;

      axios__WEBPACK_IMPORTED_MODULE_5___default.a.get('xml-fields', {
        name: this.name,
        xml_file_url: this.xml_file_url
      }).then(function (response) {
        _this2.xmlFields = response.data;
      })["catch"](function (error) {});
    },
    save: function save() {
      var _this3 = this;

      this.$vs.loading({
        background: this.backgroundLoading,
        color: this.colorLoading,
        container: '#loading-save',
        scale: 0.45
      });
      axios__WEBPACK_IMPORTED_MODULE_5___default.a.post('save-import-data', {
        name: this.name,
        http: this.http,
        authentication: this.authentication,
        encoding: this.encoding,
        xml_file_url: this.xml_file_url,
        no_action: this.no_action,
        projectFields: this.projectFields,
        import_type: 'XML',
        id_project: 1,
        title: this.title,
        image: this.image,
        description: this.description
      }).then(function (response) {
        // this.xmlFields = response.data
        _this3.$vs.loading.close('#loading-save > .con-vs-loading');
      })["catch"](function (error) {
        _this3.$vs.loading.close('#loading-save > .con-vs-loading');
      });
    }
  },
  mounted: function mounted() {
    this.getXmlFields();
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _services_requests__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/services/requests */ "./resources/js/src/services/requests.js");
/* harmony import */ var _ProjectSettingsGeneral_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ProjectSettingsGeneral.vue */ "./resources/js/src/views/pages/project-product/ProjectSettingsGeneral.vue");
/* harmony import */ var _ProjectSettingsInfo_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ProjectSettingsInfo.vue */ "./resources/js/src/views/pages/project-product/ProjectSettingsInfo.vue");
/* harmony import */ var _ProductImport_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ProductImport.vue */ "./resources/js/src/views/pages/project-product/ProductImport.vue");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    ProjectSettingsGeneral: _ProjectSettingsGeneral_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    ProjectSettingsInfo: _ProjectSettingsInfo_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    ProductImport: _ProductImport_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    BTabs: bootstrap_vue__WEBPACK_IMPORTED_MODULE_4__["BTabs"],
    BTab: bootstrap_vue__WEBPACK_IMPORTED_MODULE_4__["BTab"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_4__["BCardText"]
  },
  data: function data() {
    return {
      project: {},
      options: {}
    };
  },
  computed: {
    isSmallerScreen: function isSmallerScreen() {
      return this.$store.state.windowWidth < 768;
    }
  },
  methods: {
    getProject: function getProject() {
      var _this = this;

      _services_requests__WEBPACK_IMPORTED_MODULE_0__["http"].get('projects/' + localStorage.getItem('selectedProjectId')).then(function (response) {
        console.log(response.data, 12212);
        _this.project = response.data;
      })["catch"](function (error) {});
    }
  },
  mounted: function mounted() {
    this.getProject();
  },
  beforeCreate: function beforeCreate() {
    var _this2 = this;

    this.$http.get('/projects/data').then(function (res) {
      _this2.options = res.data;
    });
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProjectSettingsGeneral.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/project-product/ProjectSettingsGeneral.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_requests__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/services/requests */ "./resources/js/src/services/requests.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");

//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BButton"],
    BCard: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BCard"],
    BCardTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BCardTitle"],
    BCardSubTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BCardSubTitle"],
    BCardBody: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BCardBody"],
    BCollapse: bootstrap_vue__WEBPACK_IMPORTED_MODULE_2__["BCollapse"]
  },
  data: function data() {
    return {
      name: '',
      website: ''
    };
  },
  computed: {
    activeUserInfo: function activeUserInfo() {
      return this.$store.state.AppActiveUser;
    },
    currentUser: function currentUser() {
      return authentication.currentUser.source._value;
    }
  },
  methods: {
    updateProjectGeneralData: function updateProjectGeneralData() {
      var _this = this;

      _services_requests__WEBPACK_IMPORTED_MODULE_1__["http"].put('projects/update/' + localStorage.getItem('selectedProjectId'), {
        name: this.name,
        website: this.website
      }).then(function (response) {
        _this.$vs.notify({
          text: 'Update',
          color: 'success',
          iconPack: 'feather',
          icon: 'icon-check'
        });
      })["catch"](function (error) {});
    },
    getProject: function getProject() {
      var _this2 = this;

      _services_requests__WEBPACK_IMPORTED_MODULE_1__["http"].get('projects/' + localStorage.getItem('selectedProjectId')).then(function (response) {
        _this2.name = response.data.name;
        _this2.website = response.data.website;
      })["catch"](function (error) {});
    }
  },
  created: function created() {
    this.getProject();
  },
  mounted: function mounted() {}
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProjectSettingsInfo.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/project-product/ProjectSettingsInfo.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var vue_flatpickr_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-flatpickr-component */ "./node_modules/vue-flatpickr-component/dist/vue-flatpickr.min.js");
/* harmony import */ var vue_flatpickr_component__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_flatpickr_component__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var flatpickr_dist_flatpickr_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! flatpickr/dist/flatpickr.css */ "./node_modules/flatpickr/dist/flatpickr.css");
/* harmony import */ var flatpickr_dist_flatpickr_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(flatpickr_dist_flatpickr_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var vue_select__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue-select */ "./node_modules/vue-select/dist/vue-select.js");
/* harmony import */ var vue_select__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(vue_select__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _services_requests__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/services/requests */ "./resources/js/src/services/requests.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");


//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    flatPickr: vue_flatpickr_component__WEBPACK_IMPORTED_MODULE_2___default.a,
    vSelect: vue_select__WEBPACK_IMPORTED_MODULE_4___default.a,
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_6__["BButton"],
    BCard: bootstrap_vue__WEBPACK_IMPORTED_MODULE_6__["BCard"],
    BCardTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_6__["BCardTitle"],
    BCardSubTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_6__["BCardSubTitle"],
    BCardBody: bootstrap_vue__WEBPACK_IMPORTED_MODULE_6__["BCardBody"],
    BCollapse: bootstrap_vue__WEBPACK_IMPORTED_MODULE_6__["BCollapse"]
  },
  data: function data() {
    return {
      countries: [],
      currencies: [],
      timezones: [],
      country: '',
      currency: '',
      timezone: '',
      projects: {
        country: '',
        currency: '',
        timezone: ''
      }
    };
  },
  computed: {
    activeUserInfo: function activeUserInfo() {
      return this.$store.state.AppActiveUser;
    }
  },
  methods: {
    updateProjectInfo: function updateProjectInfo() {
      var _this2 = this;

      _services_requests__WEBPACK_IMPORTED_MODULE_5__["http"].put('projects/update/' + localStorage.getItem('selectedProjectId'), {
        country_id: this.projects.country.id_country,
        currency_id: this.projects.currency.id_currency,
        timezone_id: this.projects.timezone.id_timezone
      }).then(function (response) {
        _this2.$vs.notify({
          text: 'Update',
          color: 'success',
          iconPack: 'feather',
          icon: 'icon-check'
        });
      })["catch"](function (error) {});
    },
    getProject: function getProject() {
      var _this = this;

      _services_requests__WEBPACK_IMPORTED_MODULE_5__["http"].get('projects/' + localStorage.getItem('selectedProjectId')).then(function (response) {
        _this.countries.forEach(function (entry) {
          if (entry.id_country == response.data.country_id) {
            _this.projects.country = entry;
          }
        });

        _this.currencies.forEach(function (entry) {
          if (entry.id_currency == response.data.currency_id) {
            _this.projects.currency = entry;
          }
        });

        _this.timezones.forEach(function (entry) {
          if (entry.id_timezone == response.data.timezone_id) {
            _this.projects.timezone = entry;
          }
        });
      })["catch"](function (error) {});
    },
    chooseCountry: function chooseCountry(event) {
      this.getTimezones(event);
      this.getCurrencies(event);
    },
    getCountries: function getCountries() {
      var _this3 = this;

      _services_requests__WEBPACK_IMPORTED_MODULE_5__["http"].get('countries').then(function (response) {
        _this3.countries = response.data;
      })["catch"](function (error) {});
    },
    getCurrencies: function getCurrencies(country) {
      var _this = this;

      _services_requests__WEBPACK_IMPORTED_MODULE_5__["http"].get('currencies').then(function (response) {
        _this.currencies = response.data;
        response.data.forEach(function (entry) {
          if (entry.state == country.country_name) {
            _this.projects.currency = entry;
          }
        });
      })["catch"](function (error) {});
    },
    getTimezones: function getTimezones(country) {
      var _this = this;

      _services_requests__WEBPACK_IMPORTED_MODULE_5__["http"].get('timezones').then(function (response) {
        _this.timezones = response.data;
        response.data.forEach(function (entry) {
          if (entry.country_code == country.code) {
            _this.projects.timezone = entry;
          }
        });
      })["catch"](function (error) {});
    }
  },
  mounted: function mounted() {
    var _this = this;

    this.getTimezones();
    this.getCountries();
    this.getCurrencies();
    setTimeout(function () {
      _this.getProject();
    }, 100);
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=style&index=0&lang=scss&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=style&index=0&lang=scss& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "[dir] #profile-tabs .b-tabs--content {\n  padding: 0;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=style&index=0&lang=css&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=style&index=0&lang=css& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n.card-img-top {\n  width: 40px;\n  height: 40px;\n}\n.arrow-sign {\n  font-size: 25px;\n}\n.form-control {\n  height: 42px;\n}\n.delete-button{\n  font-size: 24px;\n  color: red;\n}\n\n/* Tabs*/\n[dir] section {\n  padding: 60px 0;\n}\nsection .section-title {\n  color: #007b5e;\n  text-transform: uppercase;\n}\n[dir] section .section-title {\n  text-align: center;\n  margin-bottom: 50px;\n}\n.nav-item{\n  color: #303A73 !important;\n}\n[dir] .nav-item{\n  cursor: pointer;\n}\n#tabs .nav-tabs .nav-item.show .nav-link, .nav-tabs .nav-link.active {\n  color: #f3f3f3;\n  font-size: 20px;\n  font-weight: bold;\n}\n[dir] #tabs .nav-tabs .nav-item.show .nav-link, [dir] .nav-tabs .nav-link.active {\n  background-color: transparent;\n  border-color: transparent transparent #f3f3f3;\n  border-bottom: 4px solid !important;\n}\n#tabs .nav-tabs .nav-link {\n  color: #eee;\n  font-size: 20px;\n}\n[dir] #tabs .nav-tabs .nav-link {\n  border: 1px solid transparent;\n}\n[dir=ltr] #tabs .nav-tabs .nav-link {\n  border-top-left-radius: .25rem;\n  border-top-right-radius: .25rem;\n}\n[dir=rtl] #tabs .nav-tabs .nav-link {\n  border-top-right-radius: .25rem;\n  border-top-left-radius: .25rem;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=style&index=0&lang=scss&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=style&index=0&lang=scss& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ProjectSettings.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=style&index=0&lang=scss&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=style&index=0&lang=css&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader/dist/cjs.js??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=style&index=0&lang=css& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js??ref--6-1!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--6-2!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ProductImport.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=style&index=0&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=template&id=9492404a&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=template&id=9492404a& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("vs-card", { attrs: { "no-shadow": "" } }, [
    _c("div", { staticClass: "col-12 col-sm-12 col-md-12 col-lg-12 mb-4" }, [
      _c(
        "div",
        { staticClass: "card pt-4 pb-4", staticStyle: { width: "100%" } },
        [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-md-1" }, [
              _c("div", { staticClass: "card-body" }, [
                _c("img", {
                  staticClass: "card-img-top",
                  attrs: {
                    src: __webpack_require__(/*! ../../../assets/images/product-image/xml.png */ "./resources/js/src/assets/images/product-image/xml.png"),
                    alt: "XML",
                  },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-7" }, [
              _c("div", { staticClass: "card-body" }, [
                _c("div", [
                  _c("h5", { staticClass: "card-title" }, [_vm._v("XML")]),
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text" }, [
                  _vm._v(
                    "Some quick example text to build on the card title and make "
                  ),
                  _c("br"),
                  _vm._v(" up the bulk of the\n              card's content."),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-3" }, [
              _c("div", { staticClass: "card-body" }, [
                _c(
                  "a",
                  {
                    staticClass: "btn btn-link",
                    staticStyle: { padding: "0" },
                    on: {
                      click: function ($event) {
                        _vm.popupActive = true
                      },
                    },
                  },
                  [_vm._v("Go somewhere")]
                ),
                _vm._v(" "),
                _c("p", { staticClass: "card-text" }, [
                  _vm._v(
                    "Some quick example text to build on the card title and make up the bulk of the card's\n              content."
                  ),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass: "col-md-1",
                staticStyle: { "line-height": "85px" },
              },
              [
                _c("div", { staticClass: "card-body" }, [
                  _c("i", { staticClass: "fa fa-angle-right arrow-sign" }),
                ]),
              ]
            ),
          ]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "demo-alignment" },
            [
              _c(
                "vx-popup",
                {
                  attrs: {
                    fullscreen: "",
                    title: "fullscreen",
                    active: _vm.popupActive,
                  },
                  on: {
                    "update:active": function ($event) {
                      _vm.popupActive = $event
                    },
                  },
                },
                [
                  _c("section", { attrs: { id: "tabs" } }, [
                    _c("div", { staticClass: "container" }, [
                      _c("div", [
                        _c("div", [
                          _c("nav", [
                            _c(
                              "div",
                              {
                                staticClass: "nav nav-tabs nav-fill",
                                attrs: { id: "nav-tab", role: "tablist" },
                              },
                              [
                                _c(
                                  "a",
                                  {
                                    staticClass: "nav-item nav-link",
                                    class: {
                                      active: _vm.activeTab == "setting",
                                    },
                                    attrs: {
                                      id: "nav-home-tab",
                                      "data-toggle": "tab",
                                      role: "tab",
                                      "aria-controls": "nav-home",
                                      "aria-selected": "true",
                                    },
                                    on: {
                                      click: function ($event) {
                                        return _vm.tab("setting")
                                      },
                                    },
                                  },
                                  [
                                    _vm._v(
                                      "\n                        Settings\n                      "
                                    ),
                                  ]
                                ),
                                _vm._v(" "),
                                _c(
                                  "a",
                                  {
                                    staticClass: "nav-item nav-link",
                                    class: {
                                      active: _vm.activeTab == "mapping",
                                    },
                                    attrs: {
                                      id: "nav-profile-tab",
                                      "data-toggle": "tab",
                                      role: "tab",
                                      "aria-controls": "nav-profile",
                                      "aria-selected": "false",
                                    },
                                    on: {
                                      click: function ($event) {
                                        return _vm.tab("mapping")
                                      },
                                    },
                                  },
                                  [
                                    _vm._v(
                                      "\n                        Edit mapping\n                      "
                                    ),
                                  ]
                                ),
                                _vm._v(" "),
                                _c(
                                  "a",
                                  {
                                    staticClass: "nav-item nav-link",
                                    class: {
                                      active: _vm.activeTab == "safety",
                                    },
                                    attrs: {
                                      id: "nav-contact-tab",
                                      "data-toggle": "tab",
                                      role: "tab",
                                      "aria-controls": "nav-contact",
                                      "aria-selected": "false",
                                    },
                                    on: {
                                      click: function ($event) {
                                        return _vm.tab("safety")
                                      },
                                    },
                                  },
                                  [
                                    _vm._v(
                                      "\n                        Safety\n                      "
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]),
                          _vm._v(" "),
                          _c(
                            "div",
                            {
                              staticClass: "tab-content py-3 px-3 px-sm-0",
                              attrs: { id: "nav-tabContent" },
                            },
                            [
                              _vm.activeTab == "setting"
                                ? _c(
                                    "div",
                                    {
                                      staticClass: "tab-pane  show",
                                      class: {
                                        active: _vm.activeTab == "setting",
                                      },
                                      attrs: {
                                        id: "nav-home",
                                        role: "tabpanel",
                                        "aria-labelledby": "nav-home-tab",
                                      },
                                    },
                                    [
                                      _c("vs-input", {
                                        directives: [
                                          {
                                            name: "validate",
                                            rawName: "v-validate",
                                            value: "required",
                                            expression: "'required'",
                                          },
                                        ],
                                        staticClass: "w-full mb-base",
                                        attrs: {
                                          name: "name",
                                          "label-placeholder": "Name",
                                        },
                                        model: {
                                          value: _vm.name,
                                          callback: function ($$v) {
                                            _vm.name = $$v
                                          },
                                          expression: "name",
                                        },
                                      }),
                                      _vm._v(" "),
                                      _c("label", [_vm._v("XML file url:")]),
                                      _vm._v(" "),
                                      _c(
                                        "vs-input-group",
                                        {
                                          staticClass: "mb-base",
                                          attrs: { name: "name_group" },
                                        },
                                        [
                                          _c("template", { slot: "prepend" }, [
                                            _c(
                                              "div",
                                              {
                                                staticClass:
                                                  "prepend-text bg-primary",
                                                staticStyle: {
                                                  "background-color":
                                                    "#ffffff !important",
                                                  "padding-left": "0px",
                                                },
                                              },
                                              [
                                                _c(
                                                  "select",
                                                  {
                                                    directives: [
                                                      {
                                                        name: "model",
                                                        rawName: "v-model",
                                                        value: _vm.http,
                                                        expression: "http",
                                                      },
                                                    ],
                                                    staticClass: "form-control",
                                                    on: {
                                                      change: function (
                                                        $event
                                                      ) {
                                                        var $$selectedVal =
                                                          Array.prototype.filter
                                                            .call(
                                                              $event.target
                                                                .options,
                                                              function (o) {
                                                                return o.selected
                                                              }
                                                            )
                                                            .map(function (o) {
                                                              var val =
                                                                "_value" in o
                                                                  ? o._value
                                                                  : o.value
                                                              return val
                                                            })
                                                        _vm.http = $event.target
                                                          .multiple
                                                          ? $$selectedVal
                                                          : $$selectedVal[0]
                                                      },
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "option",
                                                      {
                                                        attrs: { selected: "" },
                                                      },
                                                      [_vm._v("https")]
                                                    ),
                                                    _vm._v(" "),
                                                    _c("option", [
                                                      _vm._v("http"),
                                                    ]),
                                                    _vm._v(" "),
                                                    _c("option", [
                                                      _vm._v("sftp"),
                                                    ]),
                                                    _vm._v(" "),
                                                    _c("option", [
                                                      _vm._v("ftp"),
                                                    ]),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]),
                                          _vm._v(" "),
                                          _c("vs-input", {
                                            directives: [
                                              {
                                                name: "validate",
                                                rawName: "v-validate",
                                                value: "required",
                                                expression: "'required'",
                                              },
                                            ],
                                            attrs: { name: "xml_file_url" },
                                            model: {
                                              value: _vm.xml_file_url,
                                              callback: function ($$v) {
                                                _vm.xml_file_url = $$v
                                              },
                                              expression: "xml_file_url",
                                            },
                                          }),
                                          _vm._v(" "),
                                          _c("template", { slot: "append" }, [
                                            _c(
                                              "div",
                                              {
                                                staticClass:
                                                  "append-text btn-addon",
                                                staticStyle: {
                                                  "background-color":
                                                    "#ffffff !important",
                                                },
                                              },
                                              [
                                                _c(
                                                  "select",
                                                  {
                                                    directives: [
                                                      {
                                                        name: "validate",
                                                        rawName: "v-validate",
                                                        value: "required",
                                                        expression:
                                                          "'required'",
                                                      },
                                                      {
                                                        name: "model",
                                                        rawName: "v-model",
                                                        value:
                                                          _vm.authentication,
                                                        expression:
                                                          "authentication",
                                                      },
                                                    ],
                                                    staticClass: "form-control",
                                                    attrs: {
                                                      name: "authentication",
                                                    },
                                                    on: {
                                                      change: function (
                                                        $event
                                                      ) {
                                                        var $$selectedVal =
                                                          Array.prototype.filter
                                                            .call(
                                                              $event.target
                                                                .options,
                                                              function (o) {
                                                                return o.selected
                                                              }
                                                            )
                                                            .map(function (o) {
                                                              var val =
                                                                "_value" in o
                                                                  ? o._value
                                                                  : o.value
                                                              return val
                                                            })
                                                        _vm.authentication =
                                                          $event.target.multiple
                                                            ? $$selectedVal
                                                            : $$selectedVal[0]
                                                      },
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "option",
                                                      {
                                                        attrs: {
                                                          value:
                                                            "no_authentication",
                                                        },
                                                      },
                                                      [
                                                        _vm._v(
                                                          "No authentication"
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "option",
                                                      {
                                                        attrs: {
                                                          value:
                                                            "username_password",
                                                        },
                                                      },
                                                      [
                                                        _vm._v(
                                                          "Username & password"
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "option",
                                                      {
                                                        attrs: {
                                                          value:
                                                            "x_api_key_header",
                                                        },
                                                      },
                                                      [
                                                        _vm._v(
                                                          "Authentication header"
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]),
                                        ],
                                        2
                                      ),
                                      _vm._v(" "),
                                      _c("label", [_vm._v("Encoding:")]),
                                      _vm._v(" "),
                                      _c(
                                        "select",
                                        {
                                          directives: [
                                            {
                                              name: "model",
                                              rawName: "v-model",
                                              value: _vm.encoding,
                                              expression: "encoding",
                                            },
                                            {
                                              name: "validate",
                                              rawName: "v-validate",
                                              value: "required",
                                              expression: "'required'",
                                            },
                                          ],
                                          staticClass: "form-control",
                                          attrs: { name: "encoding" },
                                          on: {
                                            change: function ($event) {
                                              var $$selectedVal =
                                                Array.prototype.filter
                                                  .call(
                                                    $event.target.options,
                                                    function (o) {
                                                      return o.selected
                                                    }
                                                  )
                                                  .map(function (o) {
                                                    var val =
                                                      "_value" in o
                                                        ? o._value
                                                        : o.value
                                                    return val
                                                  })
                                              _vm.encoding = $event.target
                                                .multiple
                                                ? $$selectedVal
                                                : $$selectedVal[0]
                                            },
                                          },
                                        },
                                        [
                                          _c(
                                            "option",
                                            { attrs: { value: "0" } },
                                            [_vm._v("Automatically detect")]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "option",
                                            { attrs: { value: "utf-8" } },
                                            [_vm._v("UTF-8")]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "option",
                                            { attrs: { value: "utf-16" } },
                                            [
                                              _vm._v(
                                                "UTF-16 with byte order mark"
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "option",
                                            { attrs: { value: "utf-16le" } },
                                            [_vm._v("UTF-16 (little endian)")]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "option",
                                            { attrs: { value: "utf-16be" } },
                                            [_vm._v("UTF-16 (big endian)")]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "option",
                                            { attrs: { value: "utf-32" } },
                                            [
                                              _vm._v(
                                                "UTF-32 with byte order mark"
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "option",
                                            { attrs: { value: "utf-32le" } },
                                            [_vm._v("UTF-32 (little endian)")]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "option",
                                            { attrs: { value: "utf-32be" } },
                                            [_vm._v("UTF-32 (big endian)")]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "option",
                                            { attrs: { value: "iso8859-1" } },
                                            [_vm._v("ISO-8859-1")]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "option",
                                            { attrs: { value: "iso8859-15" } },
                                            [_vm._v("ISO-8859-15")]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "option",
                                            { attrs: { value: "cp1252" } },
                                            [_vm._v("Windows-1252")]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "option",
                                            { attrs: { value: "cp1254" } },
                                            [_vm._v("Windows-1254")]
                                          ),
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "b-button",
                                        {
                                          directives: [
                                            {
                                              name: "ripple",
                                              rawName: "v-ripple.400",
                                              value:
                                                "rgba(255, 255, 255, 0.15)",
                                              expression:
                                                "'rgba(255, 255, 255, 0.15)'",
                                              modifiers: { 400: true },
                                            },
                                          ],
                                          ref: "loadableButton",
                                          staticClass:
                                            "vs-con-loading__container",
                                          staticStyle: { "margin-top": "20px" },
                                          attrs: {
                                            variant: "primary",
                                            id: "button-with-loading",
                                            disabled: !_vm.validateForm,
                                            type: "relief",
                                          },
                                          on: { click: _vm.continueXml },
                                        },
                                        [
                                          _vm._v(
                                            "\n                        Continue\n                      "
                                          ),
                                        ]
                                      ),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.activeTab == "mapping"
                                ? _c(
                                    "div",
                                    {
                                      staticClass: "tab-pane show",
                                      class: {
                                        active: _vm.activeTab == "mapping",
                                      },
                                      attrs: {
                                        id: "nav-profile",
                                        role: "tabpanel",
                                        "aria-labelledby": "nav-profile-tab",
                                      },
                                    },
                                    [
                                      _vm.projectFields.length
                                        ? _c(
                                            "div",
                                            { staticClass: "mt-5" },
                                            [
                                              _c(
                                                "table",
                                                { staticClass: "table" },
                                                [
                                                  _c("thead", [
                                                    _c("tr", [
                                                      _c(
                                                        "th",
                                                        {
                                                          attrs: {
                                                            scope: "col",
                                                          },
                                                        },
                                                        [_vm._v("Import field")]
                                                      ),
                                                      _vm._v(" "),
                                                      _c(
                                                        "th",
                                                        {
                                                          attrs: {
                                                            scope: "col",
                                                          },
                                                        },
                                                        [
                                                          _vm._v(
                                                            "Internal Channable field"
                                                          ),
                                                        ]
                                                      ),
                                                      _vm._v(" "),
                                                      _c(
                                                        "th",
                                                        {
                                                          attrs: {
                                                            scope: "col",
                                                          },
                                                        },
                                                        [_vm._v("Options")]
                                                      ),
                                                    ]),
                                                  ]),
                                                  _vm._v(" "),
                                                  _c(
                                                    "tbody",
                                                    _vm._l(
                                                      _vm.projectFields,
                                                      function (projectField) {
                                                        return _c(
                                                          "tr",
                                                          {
                                                            key: projectField.id,
                                                          },
                                                          [
                                                            _c("td", [
                                                              _vm._v(
                                                                _vm._s(
                                                                  projectField
                                                                )
                                                              ),
                                                            ]),
                                                            _vm._v(" "),
                                                            _c("td", [
                                                              _vm.existCustom(
                                                                projectField
                                                              )
                                                                ? _c(
                                                                    "select",
                                                                    {
                                                                      directives:
                                                                        [
                                                                          {
                                                                            name: "model",
                                                                            rawName:
                                                                              "v-model",
                                                                            value:
                                                                              _vm
                                                                                .productMappings
                                                                                .importField,
                                                                            expression:
                                                                              "productMappings.importField",
                                                                          },
                                                                        ],
                                                                      staticClass:
                                                                        "form-control",
                                                                      attrs: {
                                                                        name: "productMappings.importField",
                                                                      },
                                                                      on: {
                                                                        change:
                                                                          function (
                                                                            $event
                                                                          ) {
                                                                            var $$selectedVal =
                                                                              Array.prototype.filter
                                                                                .call(
                                                                                  $event
                                                                                    .target
                                                                                    .options,
                                                                                  function (
                                                                                    o
                                                                                  ) {
                                                                                    return o.selected
                                                                                  }
                                                                                )
                                                                                .map(
                                                                                  function (
                                                                                    o
                                                                                  ) {
                                                                                    var val =
                                                                                      "_value" in
                                                                                      o
                                                                                        ? o._value
                                                                                        : o.value
                                                                                    return val
                                                                                  }
                                                                                )
                                                                            _vm.$set(
                                                                              _vm.productMappings,
                                                                              "importField",
                                                                              $event
                                                                                .target
                                                                                .multiple
                                                                                ? $$selectedVal
                                                                                : $$selectedVal[0]
                                                                            )
                                                                          },
                                                                      },
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "option",
                                                                        {
                                                                          attrs:
                                                                            {
                                                                              value:
                                                                                "0",
                                                                            },
                                                                        },
                                                                        [
                                                                          _vm._v(
                                                                            "- do not import -"
                                                                          ),
                                                                        ]
                                                                      ),
                                                                      _vm._v(
                                                                        " "
                                                                      ),
                                                                      _vm._l(
                                                                        _vm.xmlFields,
                                                                        function (
                                                                          xmlField
                                                                        ) {
                                                                          return _c(
                                                                            "option",
                                                                            {
                                                                              key: xmlField.id,
                                                                              domProps:
                                                                                {
                                                                                  selected:
                                                                                    xmlField.field_title ==
                                                                                    projectField,
                                                                                  value:
                                                                                    xmlField.id_xml_field,
                                                                                },
                                                                            },
                                                                            [
                                                                              _vm._v(
                                                                                "\n                                    " +
                                                                                  _vm._s(
                                                                                    xmlField.field_title
                                                                                  ) +
                                                                                  "\n                                  "
                                                                              ),
                                                                            ]
                                                                          )
                                                                        }
                                                                      ),
                                                                    ],
                                                                    2
                                                                  )
                                                                : _vm._e(),
                                                              _vm._v(" "),
                                                              !_vm.existCustom(
                                                                projectField
                                                              )
                                                                ? _c("input", {
                                                                    staticClass:
                                                                      "form-control",
                                                                    attrs: {
                                                                      type: "text",
                                                                      name: "productMappings.importField",
                                                                    },
                                                                    domProps: {
                                                                      value:
                                                                        projectField,
                                                                    },
                                                                  })
                                                                : _vm._e(),
                                                            ]),
                                                            _vm._v(" "),
                                                            _c("td", [
                                                              _c(
                                                                "div",
                                                                {
                                                                  staticClass:
                                                                    "row",
                                                                },
                                                                [
                                                                  _c(
                                                                    "div",
                                                                    {
                                                                      staticClass:
                                                                        "col-md-6",
                                                                    },
                                                                    [
                                                                      _c("i", {
                                                                        staticClass:
                                                                          "fa fa-trash-o delete-button",
                                                                        attrs: {
                                                                          "aria-hidden":
                                                                            "true",
                                                                        },
                                                                      }),
                                                                    ]
                                                                  ),
                                                                  _vm._v(" "),
                                                                  _c(
                                                                    "div",
                                                                    {
                                                                      staticClass:
                                                                        "col-md-6",
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "input",
                                                                        {
                                                                          staticClass:
                                                                            "form-control",
                                                                          attrs:
                                                                            {
                                                                              type: "hidden",
                                                                              name: "productMappings.isCustom",
                                                                            },
                                                                          domProps:
                                                                            {
                                                                              value:
                                                                                _vm.existCustom(
                                                                                  projectField
                                                                                ),
                                                                            },
                                                                        }
                                                                      ),
                                                                      _vm._v(
                                                                        " "
                                                                      ),
                                                                      _vm.existCustom(
                                                                        projectField
                                                                      )
                                                                        ? _c(
                                                                            "button",
                                                                            {
                                                                              staticClass:
                                                                                "form-control",
                                                                            },
                                                                            [
                                                                              _vm._v(
                                                                                "Custom"
                                                                              ),
                                                                            ]
                                                                          )
                                                                        : _vm._e(),
                                                                      _vm._v(
                                                                        " "
                                                                      ),
                                                                      !_vm.existCustom(
                                                                        projectField
                                                                      )
                                                                        ? _c(
                                                                            "button",
                                                                            {
                                                                              staticClass:
                                                                                "form-control",
                                                                            },
                                                                            [
                                                                              _vm._v(
                                                                                "Custom check"
                                                                              ),
                                                                            ]
                                                                          )
                                                                        : _vm._e(),
                                                                    ]
                                                                  ),
                                                                ]
                                                              ),
                                                            ]),
                                                          ]
                                                        )
                                                      }
                                                    ),
                                                    0
                                                  ),
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "vs-button",
                                                {
                                                  ref: "loadableButton",
                                                  staticClass:
                                                    "vs-con-loading__container",
                                                  staticStyle: {
                                                    "margin-top": "20px",
                                                  },
                                                  attrs: {
                                                    id: "loading-save-import",
                                                    type: "relief",
                                                  },
                                                  on: { click: _vm.saveImport },
                                                },
                                                [
                                                  _vm._v(
                                                    "\n                            Save & import\n                          "
                                                  ),
                                                ]
                                              ),
                                            ],
                                            1
                                          )
                                        : _vm._e(),
                                    ]
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.activeTab == "safety"
                                ? _c(
                                    "div",
                                    {
                                      staticClass: "tab-pane show",
                                      class: {
                                        active: _vm.activeTab == "safety",
                                      },
                                      attrs: {
                                        id: "nav-contact",
                                        role: "tabpanel",
                                        "aria-labelledby": "nav-contact-tab",
                                      },
                                    },
                                    [
                                      _vm.projectFields.length
                                        ? _c(
                                            "div",
                                            [
                                              _c("label", [
                                                _vm._v("Action on difference:"),
                                              ]),
                                              _vm._v(" "),
                                              _c(
                                                "select",
                                                {
                                                  directives: [
                                                    {
                                                      name: "model",
                                                      rawName: "v-model",
                                                      value: _vm.no_action,
                                                      expression: "no_action",
                                                    },
                                                  ],
                                                  staticClass: "form-control",
                                                  attrs: { name: "no_action" },
                                                  on: {
                                                    change: function ($event) {
                                                      var $$selectedVal =
                                                        Array.prototype.filter
                                                          .call(
                                                            $event.target
                                                              .options,
                                                            function (o) {
                                                              return o.selected
                                                            }
                                                          )
                                                          .map(function (o) {
                                                            var val =
                                                              "_value" in o
                                                                ? o._value
                                                                : o.value
                                                            return val
                                                          })
                                                      _vm.no_action = $event
                                                        .target.multiple
                                                        ? $$selectedVal
                                                        : $$selectedVal[0]
                                                    },
                                                  },
                                                },
                                                [
                                                  _c(
                                                    "option",
                                                    {
                                                      attrs: {
                                                        value: "no_action",
                                                      },
                                                    },
                                                    [_vm._v("No action")]
                                                  ),
                                                  _vm._v(" "),
                                                  _c(
                                                    "option",
                                                    {
                                                      attrs: {
                                                        value:
                                                          "send_notification",
                                                      },
                                                    },
                                                    [
                                                      _vm._v(
                                                        "Send notification"
                                                      ),
                                                    ]
                                                  ),
                                                  _vm._v(" "),
                                                  _c(
                                                    "option",
                                                    {
                                                      attrs: {
                                                        value: "block_import",
                                                      },
                                                    },
                                                    [
                                                      _vm._v(
                                                        "Block and send notification"
                                                      ),
                                                    ]
                                                  ),
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "div",
                                                { staticClass: "mt-5" },
                                                [
                                                  _c(
                                                    "div",
                                                    { staticClass: "row" },
                                                    [
                                                      _c(
                                                        "div",
                                                        {
                                                          staticClass:
                                                            "col-md-6",
                                                        },
                                                        [
                                                          _c("label", [
                                                            _vm._v(
                                                              " Auto update product titles on future updates:"
                                                            ),
                                                          ]),
                                                          _vm._v(" "),
                                                          _c(
                                                            "label",
                                                            {
                                                              staticClass:
                                                                "mt-3",
                                                            },
                                                            [
                                                              _vm._v(
                                                                " Auto update product description on future updates:"
                                                              ),
                                                            ]
                                                          ),
                                                          _vm._v(" "),
                                                          _c(
                                                            "label",
                                                            {
                                                              staticClass:
                                                                "mt-3",
                                                            },
                                                            [
                                                              _vm._v(
                                                                "Auto update future product images:"
                                                              ),
                                                            ]
                                                          ),
                                                        ]
                                                      ),
                                                      _vm._v(" "),
                                                      _c(
                                                        "div",
                                                        {
                                                          staticClass:
                                                            "col-md-6",
                                                        },
                                                        [
                                                          _c(
                                                            "vs-switch",
                                                            {
                                                              attrs: {
                                                                "vs-icon-on":
                                                                  "check",
                                                                color:
                                                                  "success",
                                                                "vs-value":
                                                                  "summer",
                                                              },
                                                              model: {
                                                                value:
                                                                  _vm.title,
                                                                callback:
                                                                  function (
                                                                    $$v
                                                                  ) {
                                                                    _vm.title =
                                                                      $$v
                                                                  },
                                                                expression:
                                                                  "title",
                                                              },
                                                            },
                                                            [
                                                              _c("span", {
                                                                attrs: {
                                                                  slot: "off",
                                                                },
                                                                slot: "off",
                                                              }),
                                                            ]
                                                          ),
                                                          _vm._v(" "),
                                                          _c(
                                                            "vs-switch",
                                                            {
                                                              staticClass:
                                                                "mt-3",
                                                              attrs: {
                                                                "vs-icon-on":
                                                                  "check",
                                                                color:
                                                                  "success",
                                                                "vs-value":
                                                                  "summer",
                                                              },
                                                              model: {
                                                                value:
                                                                  _vm.description,
                                                                callback:
                                                                  function (
                                                                    $$v
                                                                  ) {
                                                                    _vm.description =
                                                                      $$v
                                                                  },
                                                                expression:
                                                                  "description",
                                                              },
                                                            },
                                                            [
                                                              _c("span", {
                                                                attrs: {
                                                                  slot: "off",
                                                                },
                                                                slot: "off",
                                                              }),
                                                            ]
                                                          ),
                                                          _vm._v(" "),
                                                          _c(
                                                            "vs-switch",
                                                            {
                                                              staticClass:
                                                                "mt-3",
                                                              attrs: {
                                                                "vs-icon-on":
                                                                  "check",
                                                                color:
                                                                  "success",
                                                                "vs-value":
                                                                  "summer",
                                                              },
                                                              model: {
                                                                value:
                                                                  _vm.image,
                                                                callback:
                                                                  function (
                                                                    $$v
                                                                  ) {
                                                                    _vm.image =
                                                                      $$v
                                                                  },
                                                                expression:
                                                                  "image",
                                                              },
                                                            },
                                                            [
                                                              _c("span", {
                                                                attrs: {
                                                                  slot: "off",
                                                                },
                                                                slot: "off",
                                                              }),
                                                            ]
                                                          ),
                                                        ],
                                                        1
                                                      ),
                                                    ]
                                                  ),
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "vs-button",
                                                {
                                                  staticStyle: {
                                                    "margin-top": "20px",
                                                  },
                                                  attrs: {
                                                    color: "primary",
                                                    id: "loading-save",
                                                  },
                                                  on: { click: _vm.save },
                                                },
                                                [_vm._v("Save")]
                                              ),
                                            ],
                                            1
                                          )
                                        : _vm._e(),
                                    ]
                                  )
                                : _vm._e(),
                            ]
                          ),
                        ]),
                      ]),
                    ]),
                  ]),
                ]
              ),
            ],
            1
          ),
        ]
      ),
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "col-12 col-sm-12 col-md-12 col-lg-12 mb-4" }, [
      _c(
        "div",
        { staticClass: "card pt-4 pb-4", staticStyle: { width: "100%" } },
        [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-md-1" }, [
              _c("div", { staticClass: "card-body" }, [
                _c("img", {
                  staticClass: "card-img-top",
                  attrs: {
                    src: __webpack_require__(/*! ../../../assets/images/product-image/csv.png */ "./resources/js/src/assets/images/product-image/csv.png"),
                    alt: "XML",
                  },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-7" }, [
              _c("div", { staticClass: "card-body" }, [
                _c("div", [
                  _c("h5", { staticClass: "card-title" }, [_vm._v("CSV")]),
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text" }, [
                  _vm._v(
                    "Some quick example text to build on the card title and make "
                  ),
                  _c("br"),
                  _vm._v(" up the bulk of the\n              card's content."),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-3" }, [
              _c("div", { staticClass: "card-body" }, [
                _c(
                  "a",
                  {
                    staticClass: "btn btn-link",
                    staticStyle: { padding: "0" },
                    attrs: { href: "#" },
                  },
                  [_vm._v("Go somewhere")]
                ),
                _vm._v(" "),
                _c("p", { staticClass: "card-text" }, [
                  _vm._v(
                    "Some quick example text to build on the card title and make up the bulk of the card's\n              content."
                  ),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass: "col-md-1",
                staticStyle: { "line-height": "85px" },
              },
              [
                _c("div", { staticClass: "card-body" }, [
                  _c("i", { staticClass: "fa fa-angle-right arrow-sign" }),
                ]),
              ]
            ),
          ]),
        ]
      ),
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "col-12 col-sm-12 col-md-12 col-lg-12 mb-4" }, [
      _c(
        "div",
        { staticClass: "card pt-4 pb-4", staticStyle: { width: "100%" } },
        [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-md-1" }, [
              _c("div", { staticClass: "card-body" }, [
                _c("img", {
                  staticClass: "card-img-top",
                  attrs: {
                    src: __webpack_require__(/*! ../../../assets/images/product-image/ps.png */ "./resources/js/src/assets/images/product-image/ps.png"),
                    alt: "XML",
                  },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-7" }, [
              _c("div", { staticClass: "card-body" }, [
                _c("div", [
                  _c("h5", { staticClass: "card-title" }, [
                    _vm._v("Prestashop"),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text" }, [
                  _vm._v(
                    "Some quick example text to build on the card title and make "
                  ),
                  _c("br"),
                  _vm._v(" up the bulk of the\n              card's content."),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-3" }, [
              _c("div", { staticClass: "card-body" }, [
                _c(
                  "a",
                  {
                    staticClass: "btn btn-link",
                    staticStyle: { padding: "0" },
                    attrs: { href: "#" },
                  },
                  [_vm._v("Go somewhere")]
                ),
                _vm._v(" "),
                _c("p", { staticClass: "card-text" }, [
                  _vm._v(
                    "Some quick example text to build on the card title and make up the bulk of the card's\n              content."
                  ),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass: "col-md-1",
                staticStyle: { "line-height": "85px" },
              },
              [
                _c("div", { staticClass: "card-body" }, [
                  _c("i", { staticClass: "fa fa-angle-right arrow-sign" }),
                ]),
              ]
            ),
          ]),
        ]
      ),
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "col-12 col-sm-12 col-md-12 col-lg-12 mb-4" }, [
      _c(
        "div",
        { staticClass: "card pt-4 pb-4", staticStyle: { width: "100%" } },
        [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-md-1" }, [
              _c("div", { staticClass: "card-body" }, [
                _c("img", {
                  staticClass: "card-img-top",
                  attrs: {
                    src: __webpack_require__(/*! ../../../assets/images/product-image/mg.png */ "./resources/js/src/assets/images/product-image/mg.png"),
                    alt: "XML",
                  },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-7" }, [
              _c("div", { staticClass: "card-body" }, [
                _c("div", [
                  _c("h5", { staticClass: "card-title" }, [_vm._v("Magento")]),
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text" }, [
                  _vm._v(
                    "Some quick example text to build on the card title and make "
                  ),
                  _c("br"),
                  _vm._v(" up the bulk of the\n              card's content."),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-3" }, [
              _c("div", { staticClass: "card-body" }, [
                _c(
                  "a",
                  {
                    staticClass: "btn btn-link",
                    staticStyle: { padding: "0" },
                    attrs: { href: "#" },
                  },
                  [_vm._v("Go somewhere")]
                ),
                _vm._v(" "),
                _c("p", { staticClass: "card-text" }, [
                  _vm._v(
                    "Some quick example text to build on the card title and make up the bulk of the card's\n              content."
                  ),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass: "col-md-1",
                staticStyle: { "line-height": "85px" },
              },
              [
                _c("div", { staticClass: "card-body" }, [
                  _c("i", { staticClass: "fa fa-angle-right arrow-sign" }),
                ]),
              ]
            ),
          ]),
        ]
      ),
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "col-12 col-sm-12 col-md-12 col-lg-12 mb-4" }, [
      _c(
        "div",
        { staticClass: "card pt-4 pb-4", staticStyle: { width: "100%" } },
        [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-md-1" }, [
              _c("div", { staticClass: "card-body" }, [
                _c("img", {
                  staticClass: "card-img-top",
                  attrs: {
                    src: __webpack_require__(/*! ../../../assets/images/product-image/woo.jpeg */ "./resources/js/src/assets/images/product-image/woo.jpeg"),
                    alt: "XML",
                  },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-7" }, [
              _c("div", { staticClass: "card-body" }, [
                _c("div", [
                  _c("h5", { staticClass: "card-title" }, [
                    _vm._v("WooCommerce"),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text" }, [
                  _vm._v(
                    "Some quick example text to build on the card title and make "
                  ),
                  _c("br"),
                  _vm._v(" up the bulk of the\n              card's content."),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-3" }, [
              _c("div", { staticClass: "card-body" }, [
                _c(
                  "a",
                  {
                    staticClass: "btn btn-link",
                    staticStyle: { padding: "0" },
                    attrs: { href: "#" },
                  },
                  [_vm._v("Go somewhere")]
                ),
                _vm._v(" "),
                _c("p", { staticClass: "card-text" }, [
                  _vm._v(
                    "Some quick example text to build on the card title and make up the bulk of the card's\n              content."
                  ),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass: "col-md-1",
                staticStyle: { "line-height": "85px" },
              },
              [
                _c("div", { staticClass: "card-body" }, [
                  _c("i", { staticClass: "fa fa-angle-right arrow-sign" }),
                ]),
              ]
            ),
          ]),
        ]
      ),
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "col-12 col-sm-12 col-md-12 col-lg-12 mb-4" }, [
      _c(
        "div",
        { staticClass: "card pt-4 pb-4", staticStyle: { width: "100%" } },
        [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-md-1" }, [
              _c("div", { staticClass: "card-body" }, [
                _c("img", {
                  staticClass: "card-img-top",
                  attrs: {
                    src: __webpack_require__(/*! ../../../assets/images/product-image/big.png */ "./resources/js/src/assets/images/product-image/big.png"),
                    alt: "XML",
                  },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-7" }, [
              _c("div", { staticClass: "card-body" }, [
                _c("div", [
                  _c("h5", { staticClass: "card-title" }, [
                    _vm._v("BigCommerce"),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text" }, [
                  _vm._v(
                    "Some quick example text to build on the card title and make "
                  ),
                  _c("br"),
                  _vm._v(" up the bulk of the\n              card's content."),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-3" }, [
              _c("div", { staticClass: "card-body" }, [
                _c(
                  "a",
                  {
                    staticClass: "btn btn-link",
                    staticStyle: { padding: "0" },
                    attrs: { href: "#" },
                  },
                  [_vm._v("Go somewhere")]
                ),
                _vm._v(" "),
                _c("p", { staticClass: "card-text" }, [
                  _vm._v(
                    "Some quick example text to build on the card title and make up the bulk of the card's\n              content."
                  ),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass: "col-md-1",
                staticStyle: { "line-height": "85px" },
              },
              [
                _c("div", { staticClass: "card-body" }, [
                  _c("i", { staticClass: "fa fa-angle-right arrow-sign" }),
                ]),
              ]
            ),
          ]),
        ]
      ),
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "col-12 col-sm-12 col-md-12 col-lg-12 mb-4" }, [
      _c(
        "div",
        { staticClass: "card pt-4 pb-4", staticStyle: { width: "100%" } },
        [
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-md-1" }, [
              _c("div", { staticClass: "card-body" }, [
                _c("img", {
                  staticClass: "card-img-top",
                  attrs: {
                    src: __webpack_require__(/*! ../../../assets/images/product-image/shopify.jpg */ "./resources/js/src/assets/images/product-image/shopify.jpg"),
                    alt: "XML",
                  },
                }),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-7" }, [
              _c("div", { staticClass: "card-body" }, [
                _c("div", [
                  _c("h5", { staticClass: "card-title" }, [_vm._v("Shopify")]),
                ]),
                _vm._v(" "),
                _c("p", { staticClass: "card-text" }, [
                  _vm._v(
                    "Some quick example text to build on the card title and make "
                  ),
                  _c("br"),
                  _vm._v(" up the bulk of the\n              card's content."),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-md-3" }, [
              _c("div", { staticClass: "card-body" }, [
                _c(
                  "a",
                  {
                    staticClass: "btn btn-link",
                    staticStyle: { padding: "0" },
                    attrs: { href: "#" },
                  },
                  [_vm._v("Go somewhere")]
                ),
                _vm._v(" "),
                _c("p", { staticClass: "card-text" }, [
                  _vm._v(
                    "Some quick example text to build on the card title and make up the bulk of the card's\n              content."
                  ),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass: "col-md-1",
                staticStyle: { "line-height": "85px" },
              },
              [
                _c("div", { staticClass: "card-body" }, [
                  _c("i", { staticClass: "fa fa-angle-right arrow-sign" }),
                ]),
              ]
            ),
          ]),
        ]
      ),
    ]),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=template&id=afb88dfa&":
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=template&id=afb88dfa& ***!
  \***************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-tabs",
    {
      attrs: {
        vertical: "",
        "content-class": "col-12 col-md-9 mt-1 mt-md-0",
        pills: "",
        "nav-wrapper-class": "col-md-3 col-12",
        id: "profile-tabs",
      },
    },
    [
      _c(
        "b-tab",
        {
          attrs: { title: "General", active: "" },
          scopedSlots: _vm._u([
            {
              key: "title",
              fn: function () {
                return [
                  _c("feather-icon", {
                    staticClass: "mr-50",
                    attrs: { icon: "UserIcon", size: "18" },
                  }),
                  _vm._v(" "),
                  _c("span", { staticClass: "font-weight-bold" }, [
                    _vm._v("General"),
                  ]),
                ]
              },
              proxy: true,
            },
          ]),
        },
        [_vm._v(" "), _c("project-settings-general")],
        1
      ),
      _vm._v(" "),
      _c(
        "b-tab",
        {
          attrs: {
            "icon-pack": "feather",
            icon: "icon-info",
            title: "Data settings",
          },
          scopedSlots: _vm._u([
            {
              key: "title",
              fn: function () {
                return [
                  _c("feather-icon", {
                    staticClass: "mr-50",
                    attrs: { icon: "UserIcon", size: "18" },
                  }),
                  _vm._v(" "),
                  _c("span", { staticClass: "font-weight-bold" }, [
                    _vm._v("Settings"),
                  ]),
                ]
              },
              proxy: true,
            },
          ]),
        },
        [_vm._v(" "), _c("project-settings-info")],
        1
      ),
      _vm._v(" "),
      _c(
        "b-tab",
        {
          attrs: {
            "icon-pack": "feather",
            icon: "icon-link-2",
            title: "Product Import",
          },
          scopedSlots: _vm._u([
            {
              key: "title",
              fn: function () {
                return [
                  _c("feather-icon", {
                    staticClass: "mr-50",
                    attrs: { icon: "UserIcon", size: "18" },
                  }),
                  _vm._v(" "),
                  _c("span", { staticClass: "font-weight-bold" }, [
                    _vm._v("Import"),
                  ]),
                ]
              },
              proxy: true,
            },
          ]),
        },
        [_vm._v(" "), _c("product-import")],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProjectSettingsGeneral.vue?vue&type=template&id=2d8eaad6&":
/*!**********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/project-product/ProjectSettingsGeneral.vue?vue&type=template&id=2d8eaad6& ***!
  \**********************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card",
    [
      _c("vs-input", {
        staticClass: "w-full mb-base",
        attrs: { "label-placeholder": "Name" },
        model: {
          value: _vm.name,
          callback: function ($$v) {
            _vm.name = $$v
          },
          expression: "name",
        },
      }),
      _vm._v(" "),
      _c("vs-input", {
        staticClass: "w-full mb-base",
        attrs: { "label-placeholder": "Website" },
        model: {
          value: _vm.website,
          callback: function ($$v) {
            _vm.website = $$v
          },
          expression: "website",
        },
      }),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "flex flex-wrap items-center justify-end" },
        [
          _c(
            "b-button",
            {
              directives: [
                {
                  name: "ripple",
                  rawName: "v-ripple.400",
                  value: "rgba(255, 255, 255, 0.15)",
                  expression: "'rgba(255, 255, 255, 0.15)'",
                  modifiers: { 400: true },
                },
              ],
              staticClass: "ml-auto mt-2",
              attrs: { variant: "primary" },
              on: { click: _vm.updateProjectGeneralData },
            },
            [_vm._v("Save Changes")]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              directives: [
                {
                  name: "ripple",
                  rawName: "v-ripple.400",
                  value: "rgba(255, 255, 255, 0.15)",
                  expression: "'rgba(255, 255, 255, 0.15)'",
                  modifiers: { 400: true },
                },
              ],
              staticClass: "ml-4 mt-2",
              attrs: { type: "border", variant: "warning" },
            },
            [_vm._v("Reset")]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProjectSettingsInfo.vue?vue&type=template&id=42624d51&":
/*!*******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/pages/project-product/ProjectSettingsInfo.vue?vue&type=template&id=42624d51& ***!
  \*******************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("vs-card", { attrs: { "no-shadow": "" } }, [
    _c(
      "div",
      { staticClass: "mt-8" },
      [
        _c("v-select", {
          directives: [
            {
              name: "validate",
              rawName: "v-validate",
              value: "required",
              expression: "'required'",
            },
          ],
          staticClass: "w-full mb-4 mt-5",
          attrs: {
            placeholder: "Country",
            name: "country",
            label: "country_name",
            options: _vm.countries,
          },
          on: {
            input: function ($event) {
              return _vm.chooseCountry($event)
            },
          },
          model: {
            value: _vm.projects.country,
            callback: function ($$v) {
              _vm.$set(_vm.projects, "country", $$v)
            },
            expression: "projects.country",
          },
        }),
      ],
      1
    ),
    _vm._v(" "),
    _c(
      "div",
      { staticClass: "mt-8" },
      [
        _c("v-select", {
          directives: [
            {
              name: "validate",
              rawName: "v-validate",
              value: "required",
              expression: "'required'",
            },
          ],
          staticClass: "w-full mb-4 mt-5",
          attrs: {
            placeholder: "Currencies",
            name: "currency",
            label: "currency_name",
            options: _vm.currencies,
          },
          model: {
            value: _vm.projects.currency,
            callback: function ($$v) {
              _vm.$set(_vm.projects, "currency", $$v)
            },
            expression: "projects.currency",
          },
        }),
      ],
      1
    ),
    _vm._v(" "),
    _c(
      "div",
      { staticClass: "mt-8" },
      [
        _c("v-select", {
          directives: [
            {
              name: "validate",
              rawName: "v-validate",
              value: "required",
              expression: "'required'",
            },
          ],
          staticClass: "w-full mb-4 mt-5",
          attrs: {
            placeholder: "Timezones",
            name: "timezones",
            label: "time_zone",
            options: _vm.timezones,
          },
          model: {
            value: _vm.projects.timezone,
            callback: function ($$v) {
              _vm.$set(_vm.projects, "timezone", $$v)
            },
            expression: "projects.timezone",
          },
        }),
      ],
      1
    ),
    _vm._v(" "),
    _c(
      "div",
      { staticClass: "flex flex-wrap items-center justify-end" },
      [
        _c(
          "b-button",
          {
            directives: [
              {
                name: "ripple",
                rawName: "v-ripple.400",
                value: "rgba(255, 255, 255, 0.15)",
                expression: "'rgba(255, 255, 255, 0.15)'",
                modifiers: { 400: true },
              },
            ],
            staticClass: "ml-auto mt-2",
            attrs: { variant: "primary" },
            on: { click: _vm.updateProjectInfo },
          },
          [_vm._v("Save Changes")]
        ),
        _vm._v(" "),
        _c(
          "b-button",
          {
            directives: [
              {
                name: "ripple",
                rawName: "v-ripple.400",
                value: "rgba(255, 255, 255, 0.15)",
                expression: "'rgba(255, 255, 255, 0.15)'",
                modifiers: { 400: true },
              },
            ],
            staticClass: "ml-4 mt-2",
            attrs: { type: "border", variant: "warning" },
          },
          [_vm._v("Reset")]
        ),
      ],
      1
    ),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/assets/images/product-image/big.png":
/*!**************************************************************!*\
  !*** ./resources/js/src/assets/images/product-image/big.png ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channelable-new-laravel/resources/js/src/assets/images/product-image/big.png";

/***/ }),

/***/ "./resources/js/src/assets/images/product-image/csv.png":
/*!**************************************************************!*\
  !*** ./resources/js/src/assets/images/product-image/csv.png ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channelable-new-laravel/resources/js/src/assets/images/product-image/csv.png";

/***/ }),

/***/ "./resources/js/src/assets/images/product-image/mg.png":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/product-image/mg.png ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channelable-new-laravel/resources/js/src/assets/images/product-image/mg.png";

/***/ }),

/***/ "./resources/js/src/assets/images/product-image/ps.png":
/*!*************************************************************!*\
  !*** ./resources/js/src/assets/images/product-image/ps.png ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channelable-new-laravel/resources/js/src/assets/images/product-image/ps.png";

/***/ }),

/***/ "./resources/js/src/assets/images/product-image/shopify.jpg":
/*!******************************************************************!*\
  !*** ./resources/js/src/assets/images/product-image/shopify.jpg ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channelable-new-laravel/resources/js/src/assets/images/product-image/shopify.jpg";

/***/ }),

/***/ "./resources/js/src/assets/images/product-image/woo.jpeg":
/*!***************************************************************!*\
  !*** ./resources/js/src/assets/images/product-image/woo.jpeg ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channelable-new-laravel/resources/js/src/assets/images/product-image/woo.jpeg";

/***/ }),

/***/ "./resources/js/src/assets/images/product-image/xml.png":
/*!**************************************************************!*\
  !*** ./resources/js/src/assets/images/product-image/xml.png ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/images/_/_/_/_/channelable-new-laravel/resources/js/src/assets/images/product-image/xml.png";

/***/ }),

/***/ "./resources/js/src/services/requests.js":
/*!***********************************************!*\
  !*** ./resources/js/src/services/requests.js ***!
  \***********************************************/
/*! exports provided: http */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "http", function() { return http; });
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! js-cookie */ "./node_modules/js-cookie/dist/js.cookie.js");
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_2__);



window.apiUrl = 'http://localhost:8000/api/';

if (window.location.origin === 'http://gads.advancedplugins.com') {
  window.apiUrl = 'http://gadslaravel.advancedplugins.com/api/';
} else if (window.location.origin === 'http://localhost:8080') {
  window.apiUrl = 'http://localhost:8000/api/';
} else {
  window.apiUrl = 'http://localhost:8000/api/';
}

var http = {
  get: function get(url) {
    return new Promise(function (resolve, reject) {
      var header = {
        'Authorization': "Bearer ".concat(js_cookie__WEBPACK_IMPORTED_MODULE_2___default.a.get("jwt-token"))
      };
      axios__WEBPACK_IMPORTED_MODULE_1___default.a.get(window.apiUrl + url, {
        headers: header
      }).then(function (response) {
        resolve(response);
      })["catch"](function (e) {
        reject(e);
      });
    });
  },
  post: function post(url) {
    var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    return new Promise(function (resolve, reject) {
      var header = {
        'Authorization': "Bearer ".concat(js_cookie__WEBPACK_IMPORTED_MODULE_2___default.a.get("jwt-token"))
      };
      axios__WEBPACK_IMPORTED_MODULE_1___default.a.post(window.apiUrl + url, data, {
        headers: header
      }).then(function (response) {
        resolve(response);
      })["catch"](function (e) {
        reject(e);
      });
    });
  },
  put: function put(url) {
    var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    return new Promise(function (resolve, reject) {
      var header = {
        'Authorization': "Bearer ".concat(js_cookie__WEBPACK_IMPORTED_MODULE_2___default.a.get("jwt-token"))
      };
      axios__WEBPACK_IMPORTED_MODULE_1___default.a.put(window.apiUrl + url, data, {
        headers: header
      }).then(function (response) {
        resolve(response);
      })["catch"](function (e) {
        reject(e);
      });
    });
  },
  "delete": function _delete(url) {
    return new Promise(function (resolve, reject) {
      var header = {
        'Authorization': "Bearer ".concat(js_cookie__WEBPACK_IMPORTED_MODULE_2___default.a.get("jwt-token"))
      };
      axios__WEBPACK_IMPORTED_MODULE_1___default.a["delete"](window.apiUrl + url, {
        headers: header
      }).then(function (response) {
        resolve(response);
      })["catch"](function (e) {
        reject(e);
      });
    });
  },
  file: function file(url) {
    var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    return new Promise(function (resolve, reject) {
      var header = {
        'Authorization': "Bearer ".concat(js_cookie__WEBPACK_IMPORTED_MODULE_2___default.a.get("jwt-token")),
        'Content-Type': 'multipart/form-data'
      };
      axios__WEBPACK_IMPORTED_MODULE_1___default.a.post(apiUrl + url, data, {
        headers: header
      }).then(function (response) {
        resolve(response);
      })["catch"](function (e) {
        reject(e);
      });
    });
  },
  postWithoutToken: function postWithoutToken(url) {
    var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    return new Promise(function (resolve, reject) {
      axios__WEBPACK_IMPORTED_MODULE_1___default.a.post(window.apiUrl + url, data).then(function (response) {
        resolve(response);
      })["catch"](function (e) {
        reject(e);
      });
    });
  }
};

/***/ }),

/***/ "./resources/js/src/views/pages/project-product/ProductImport.vue":
/*!************************************************************************!*\
  !*** ./resources/js/src/views/pages/project-product/ProductImport.vue ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ProductImport_vue_vue_type_template_id_9492404a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ProductImport.vue?vue&type=template&id=9492404a& */ "./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=template&id=9492404a&");
/* harmony import */ var _ProductImport_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ProductImport.vue?vue&type=script&lang=js& */ "./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _ProductImport_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ProductImport.vue?vue&type=style&index=0&lang=css& */ "./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _ProductImport_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ProductImport_vue_vue_type_template_id_9492404a___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ProductImport_vue_vue_type_template_id_9492404a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/pages/project-product/ProductImport.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ProductImport_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ProductImport.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ProductImport_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=style&index=0&lang=css&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=style&index=0&lang=css& ***!
  \*********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ProductImport_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/style-loader!../../../../../../node_modules/css-loader/dist/cjs.js??ref--6-1!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--6-2!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ProductImport.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ProductImport_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ProductImport_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ProductImport_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ProductImport_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=template&id=9492404a&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=template&id=9492404a& ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProductImport_vue_vue_type_template_id_9492404a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ProductImport.vue?vue&type=template&id=9492404a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProductImport.vue?vue&type=template&id=9492404a&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProductImport_vue_vue_type_template_id_9492404a___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProductImport_vue_vue_type_template_id_9492404a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/pages/project-product/ProjectSettings.vue":
/*!**************************************************************************!*\
  !*** ./resources/js/src/views/pages/project-product/ProjectSettings.vue ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ProjectSettings_vue_vue_type_template_id_afb88dfa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ProjectSettings.vue?vue&type=template&id=afb88dfa& */ "./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=template&id=afb88dfa&");
/* harmony import */ var _ProjectSettings_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ProjectSettings.vue?vue&type=script&lang=js& */ "./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _ProjectSettings_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ProjectSettings.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _ProjectSettings_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ProjectSettings_vue_vue_type_template_id_afb88dfa___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ProjectSettings_vue_vue_type_template_id_afb88dfa___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/pages/project-product/ProjectSettings.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettings_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ProjectSettings.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettings_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=style&index=0&lang=scss&":
/*!************************************************************************************************************!*\
  !*** ./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=style&index=0&lang=scss& ***!
  \************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettings_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/style-loader!../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ProjectSettings.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettings_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettings_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettings_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettings_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=template&id=afb88dfa&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=template&id=afb88dfa& ***!
  \*********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettings_vue_vue_type_template_id_afb88dfa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ProjectSettings.vue?vue&type=template&id=afb88dfa& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProjectSettings.vue?vue&type=template&id=afb88dfa&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettings_vue_vue_type_template_id_afb88dfa___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettings_vue_vue_type_template_id_afb88dfa___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/pages/project-product/ProjectSettingsGeneral.vue":
/*!*********************************************************************************!*\
  !*** ./resources/js/src/views/pages/project-product/ProjectSettingsGeneral.vue ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ProjectSettingsGeneral_vue_vue_type_template_id_2d8eaad6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ProjectSettingsGeneral.vue?vue&type=template&id=2d8eaad6& */ "./resources/js/src/views/pages/project-product/ProjectSettingsGeneral.vue?vue&type=template&id=2d8eaad6&");
/* harmony import */ var _ProjectSettingsGeneral_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ProjectSettingsGeneral.vue?vue&type=script&lang=js& */ "./resources/js/src/views/pages/project-product/ProjectSettingsGeneral.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ProjectSettingsGeneral_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ProjectSettingsGeneral_vue_vue_type_template_id_2d8eaad6___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ProjectSettingsGeneral_vue_vue_type_template_id_2d8eaad6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/pages/project-product/ProjectSettingsGeneral.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/pages/project-product/ProjectSettingsGeneral.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************!*\
  !*** ./resources/js/src/views/pages/project-product/ProjectSettingsGeneral.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettingsGeneral_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ProjectSettingsGeneral.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProjectSettingsGeneral.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettingsGeneral_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/pages/project-product/ProjectSettingsGeneral.vue?vue&type=template&id=2d8eaad6&":
/*!****************************************************************************************************************!*\
  !*** ./resources/js/src/views/pages/project-product/ProjectSettingsGeneral.vue?vue&type=template&id=2d8eaad6& ***!
  \****************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettingsGeneral_vue_vue_type_template_id_2d8eaad6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ProjectSettingsGeneral.vue?vue&type=template&id=2d8eaad6& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProjectSettingsGeneral.vue?vue&type=template&id=2d8eaad6&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettingsGeneral_vue_vue_type_template_id_2d8eaad6___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettingsGeneral_vue_vue_type_template_id_2d8eaad6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/pages/project-product/ProjectSettingsInfo.vue":
/*!******************************************************************************!*\
  !*** ./resources/js/src/views/pages/project-product/ProjectSettingsInfo.vue ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ProjectSettingsInfo_vue_vue_type_template_id_42624d51___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ProjectSettingsInfo.vue?vue&type=template&id=42624d51& */ "./resources/js/src/views/pages/project-product/ProjectSettingsInfo.vue?vue&type=template&id=42624d51&");
/* harmony import */ var _ProjectSettingsInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ProjectSettingsInfo.vue?vue&type=script&lang=js& */ "./resources/js/src/views/pages/project-product/ProjectSettingsInfo.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ProjectSettingsInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ProjectSettingsInfo_vue_vue_type_template_id_42624d51___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ProjectSettingsInfo_vue_vue_type_template_id_42624d51___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/pages/project-product/ProjectSettingsInfo.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/pages/project-product/ProjectSettingsInfo.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/pages/project-product/ProjectSettingsInfo.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettingsInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ProjectSettingsInfo.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProjectSettingsInfo.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettingsInfo_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/pages/project-product/ProjectSettingsInfo.vue?vue&type=template&id=42624d51&":
/*!*************************************************************************************************************!*\
  !*** ./resources/js/src/views/pages/project-product/ProjectSettingsInfo.vue?vue&type=template&id=42624d51& ***!
  \*************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettingsInfo_vue_vue_type_template_id_42624d51___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./ProjectSettingsInfo.vue?vue&type=template&id=42624d51& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/pages/project-product/ProjectSettingsInfo.vue?vue&type=template&id=42624d51&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettingsInfo_vue_vue_type_template_id_42624d51___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectSettingsInfo_vue_vue_type_template_id_42624d51___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);