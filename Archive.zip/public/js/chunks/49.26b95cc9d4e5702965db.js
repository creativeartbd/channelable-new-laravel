(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[49],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/Overlay.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/Overlay.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _OverlayBasic_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OverlayBasic.vue */ "./resources/js/src/views/components/overlay/OverlayBasic.vue");
/* harmony import */ var _OverlayBackdrop_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./OverlayBackdrop.vue */ "./resources/js/src/views/components/overlay/OverlayBackdrop.vue");
/* harmony import */ var _OverlayFade_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./OverlayFade.vue */ "./resources/js/src/views/components/overlay/OverlayFade.vue");
/* harmony import */ var _OverlaySpinner_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./OverlaySpinner.vue */ "./resources/js/src/views/components/overlay/OverlaySpinner.vue");
/* harmony import */ var _OverlayCornerRound_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./OverlayCornerRound.vue */ "./resources/js/src/views/components/overlay/OverlayCornerRound.vue");
/* harmony import */ var _OverlayCustomContent_vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./OverlayCustomContent.vue */ "./resources/js/src/views/components/overlay/OverlayCustomContent.vue");
/* harmony import */ var _OverlayNoWrapMode_vue__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./OverlayNoWrapMode.vue */ "./resources/js/src/views/components/overlay/OverlayNoWrapMode.vue");
/* harmony import */ var _OverlayForm_vue__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./OverlayForm.vue */ "./resources/js/src/views/components/overlay/OverlayForm.vue");
/* harmony import */ var _OverlayBusyState_vue__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./OverlayBusyState.vue */ "./resources/js/src/views/components/overlay/OverlayBusyState.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//










/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BRow: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BRow"],
    BCol: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCol"],
    OverlayBasic: _OverlayBasic_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    OverlayBackdrop: _OverlayBackdrop_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    OverlayFade: _OverlayFade_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    OverlaySpinner: _OverlaySpinner_vue__WEBPACK_IMPORTED_MODULE_4__["default"],
    OverlayCornerRound: _OverlayCornerRound_vue__WEBPACK_IMPORTED_MODULE_5__["default"],
    OverlayCustomContent: _OverlayCustomContent_vue__WEBPACK_IMPORTED_MODULE_6__["default"],
    OverlayNoWrapMode: _OverlayNoWrapMode_vue__WEBPACK_IMPORTED_MODULE_7__["default"],
    OverlayForm: _OverlayForm_vue__WEBPACK_IMPORTED_MODULE_8__["default"],
    OverlayBusyState: _OverlayBusyState_vue__WEBPACK_IMPORTED_MODULE_9__["default"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayBackdrop.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlayBackdrop.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var vue_ripple_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-ripple-directive */ "./node_modules/vue-ripple-directive/src/ripple.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/components/overlay/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BRow: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BRow"],
    BCol: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCol"],
    BFormGroup: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormGroup"],
    BFormSelect: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormSelect"],
    BFormInput: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormInput"],
    BInputGroupAppend: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BInputGroupAppend"],
    BCard: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCard"],
    BOverlay: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BOverlay"],
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BButton"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"],
    BInputGroup: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BInputGroup"]
  },
  directives: {
    Ripple: vue_ripple_directive__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      variant: 'light',
      opacity: 0.85,
      blur: '2px',
      variants: ['transparent', 'white', 'light', 'dark', 'primary', 'secondary', 'success', 'danger', 'warning', 'info'],
      blurs: [{
        text: 'None',
        value: ''
      }, '1px', '2px', '5px', '0.5em', '1rem'],
      codeBackdrop: _code__WEBPACK_IMPORTED_MODULE_3__["codeBackdrop"]
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayBasic.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlayBasic.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var vue_ripple_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-ripple-directive */ "./node_modules/vue-ripple-directive/src/ripple.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/components/overlay/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BOverlay: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BOverlay"],
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BButton"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"]
  },
  directives: {
    Ripple: vue_ripple_directive__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      show: false,
      codeBasic: _code__WEBPACK_IMPORTED_MODULE_3__["codeBasic"]
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayBusyState.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlayBusyState.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var vue_ripple_directive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue-ripple-directive */ "./node_modules/vue-ripple-directive/src/ripple.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/components/overlay/code.js");


//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BOverlay: bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__["BOverlay"],
    BInputGroup: bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__["BInputGroup"],
    BFormInput: bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__["BFormInput"],
    BInputGroupAppend: bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__["BInputGroupAppend"],
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__["BButton"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__["BCardText"],
    BSpinner: bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__["BSpinner"],
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  directives: {
    Ripple: vue_ripple_directive__WEBPACK_IMPORTED_MODULE_4__["default"]
  },
  data: function data() {
    return {
      value: 'Some value',
      busy: false,
      timeout: null,
      codeBusyState: _code__WEBPACK_IMPORTED_MODULE_5__["codeBusyState"]
    };
  },
  beforeDestroy: function beforeDestroy() {
    this.clearTimeout();
  },
  methods: {
    clearTimeout: function (_clearTimeout) {
      function clearTimeout() {
        return _clearTimeout.apply(this, arguments);
      }

      clearTimeout.toString = function () {
        return _clearTimeout.toString();
      };

      return clearTimeout;
    }(function () {
      if (this.timeout) {
        clearTimeout(this.timeout);
        this.timeout = null;
      }
    }),
    setTimeout: function (_setTimeout) {
      function setTimeout(_x) {
        return _setTimeout.apply(this, arguments);
      }

      setTimeout.toString = function () {
        return _setTimeout.toString();
      };

      return setTimeout;
    }(function (callback) {
      var _this = this;

      this.clearTimeout();
      this.timeout = setTimeout(function () {
        _this.clearTimeout();

        callback();
      }, 5000);
    }),
    onHidden: function onHidden() {
      // Return focus to the button
      this.$refs.button.focus();
    },
    onClick: function onClick() {
      var _this2 = this;

      this.busy = true; // Simulate an async request

      this.setTimeout(function () {
        _this2.busy = false;
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayCornerRound.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlayCornerRound.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var vue_ripple_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-ripple-directive */ "./node_modules/vue-ripple-directive/src/ripple.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/components/overlay/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BOverlay: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BOverlay"],
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BButton"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"],
    BImg: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BImg"],
    BRow: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BRow"],
    BCol: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCol"]
  },
  directives: {
    Ripple: vue_ripple_directive__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      show: false,
      codeCornerRounded: _code__WEBPACK_IMPORTED_MODULE_3__["codeCornerRounded"]
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayCustomContent.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlayCustomContent.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var vue_ripple_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-ripple-directive */ "./node_modules/vue-ripple-directive/src/ripple.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/components/overlay/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"],
    BOverlay: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BOverlay"],
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BButton"]
  },
  directives: {
    Ripple: vue_ripple_directive__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      show: false,
      codeCustomContent: _code__WEBPACK_IMPORTED_MODULE_3__["codeCustomContent"]
    };
  },
  methods: {
    onShown: function onShown() {
      // Focus the cancel button when the overlay is showing
      this.$refs.cancel.focus();
    },
    onHidden: function onHidden() {
      // Focus the show button when the overlay is removed
      this.$refs.show.focus();
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayFade.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlayFade.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var vue_ripple_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-ripple-directive */ "./node_modules/vue-ripple-directive/src/ripple.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/components/overlay/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BOverlay: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BOverlay"],
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BButton"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"]
  },
  directives: {
    Ripple: vue_ripple_directive__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      show: false,
      codeFade: _code__WEBPACK_IMPORTED_MODULE_3__["codeFade"]
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayForm.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlayForm.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var vue_ripple_directive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue-ripple-directive */ "./node_modules/vue-ripple-directive/src/ripple.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/components/overlay/code.js");


//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__["BButton"],
    BOverlay: bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__["BOverlay"],
    BForm: bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__["BForm"],
    BProgress: bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__["BProgress"],
    BFormGroup: bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__["BFormGroup"],
    BInputGroup: bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__["BInputGroup"],
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_2__["default"],
    BInputGroupPrepend: bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__["BInputGroupPrepend"],
    BFormInput: bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__["BFormInput"],
    BFormFile: bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__["BFormFile"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_3__["BCardText"]
  },
  directives: {
    Ripple: vue_ripple_directive__WEBPACK_IMPORTED_MODULE_4__["default"]
  },
  data: function data() {
    return {
      busy: false,
      processing: false,
      counter: 1,
      interval: null,
      codeForm: _code__WEBPACK_IMPORTED_MODULE_5__["codeForm"]
    };
  },
  beforeDestroy: function beforeDestroy() {
    this.clearInterval();
  },
  methods: {
    clearInterval: function (_clearInterval) {
      function clearInterval() {
        return _clearInterval.apply(this, arguments);
      }

      clearInterval.toString = function () {
        return _clearInterval.toString();
      };

      return clearInterval;
    }(function () {
      if (this.interval) {
        clearInterval(this.interval);
        this.interval = null;
      }
    }),
    onShown: function onShown() {
      // Focus the dialog prompt
      this.$refs.dialog.focus();
    },
    onHidden: function onHidden() {
      // In this case, we return focus to the submit button
      // You may need to alter this based on your application requirements
      this.$refs.submit.focus();
    },
    onSubmit: function onSubmit() {
      this.processing = false;
      this.busy = true;
    },
    onCancel: function onCancel() {
      this.busy = false;
    },
    onOK: function onOK() {
      var _this = this;

      this.counter = 1;
      this.processing = true; // Simulate an async request

      this.clearInterval();
      this.interval = setInterval(function () {
        if (_this.counter < 20) {
          _this.counter += 1;
        } else {
          _this.clearInterval();

          _this.$nextTick(function () {
            // eslint-disable-next-line
            _this.busy = _this.processing = false;
          });
        }
      }, 350);
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayNoWrapMode.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlayNoWrapMode.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var vue_ripple_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-ripple-directive */ "./node_modules/vue-ripple-directive/src/ripple.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/components/overlay/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BOverlay: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BOverlay"],
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BButton"],
    BCard: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCard"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"]
  },
  directives: {
    Ripple: vue_ripple_directive__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      show: false,
      codeNoWrapMode: _code__WEBPACK_IMPORTED_MODULE_3__["codeNoWrapMode"]
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlaySpinner.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlaySpinner.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var vue_ripple_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-ripple-directive */ "./node_modules/vue-ripple-directive/src/ripple.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/components/overlay/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BOverlay: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BOverlay"],
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BButton"],
    BCard: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCard"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"]
  },
  directives: {
    Ripple: vue_ripple_directive__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      codeSpinner: _code__WEBPACK_IMPORTED_MODULE_3__["codeSpinner"]
    };
  }
});

/***/ }),

/***/ "./node_modules/core-js/internals/regexp-get-flags.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/internals/regexp-get-flags.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
var isPrototypeOf = __webpack_require__(/*! ../internals/object-is-prototype-of */ "./node_modules/core-js/internals/object-is-prototype-of.js");
var regExpFlags = __webpack_require__(/*! ../internals/regexp-flags */ "./node_modules/core-js/internals/regexp-flags.js");

var RegExpPrototype = RegExp.prototype;

module.exports = function (R) {
  var flags = R.flags;
  return flags === undefined && !('flags' in RegExpPrototype) && !hasOwn(R, 'flags') && isPrototypeOf(RegExpPrototype, R)
    ? call(regExpFlags, R) : flags;
};


/***/ }),

/***/ "./node_modules/core-js/modules/es.regexp.to-string.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/es.regexp.to-string.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var PROPER_FUNCTION_NAME = __webpack_require__(/*! ../internals/function-name */ "./node_modules/core-js/internals/function-name.js").PROPER;
var defineBuiltIn = __webpack_require__(/*! ../internals/define-built-in */ "./node_modules/core-js/internals/define-built-in.js");
var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
var $toString = __webpack_require__(/*! ../internals/to-string */ "./node_modules/core-js/internals/to-string.js");
var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
var getRegExpFlags = __webpack_require__(/*! ../internals/regexp-get-flags */ "./node_modules/core-js/internals/regexp-get-flags.js");

var TO_STRING = 'toString';
var RegExpPrototype = RegExp.prototype;
var n$ToString = RegExpPrototype[TO_STRING];

var NOT_GENERIC = fails(function () { return n$ToString.call({ source: 'a', flags: 'b' }) != '/a/b'; });
// FF44- RegExp#toString has a wrong name
var INCORRECT_NAME = PROPER_FUNCTION_NAME && n$ToString.name != TO_STRING;

// `RegExp.prototype.toString` method
// https://tc39.es/ecma262/#sec-regexp.prototype.tostring
if (NOT_GENERIC || INCORRECT_NAME) {
  defineBuiltIn(RegExp.prototype, TO_STRING, function toString() {
    var R = anObject(this);
    var pattern = $toString(R.source);
    var flags = $toString(getRegExpFlags(R));
    return '/' + pattern + '/' + flags;
  }, { unsafe: true });
}


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/Overlay.vue?vue&type=style&index=0&id=2bcf09fc&lang=scss&scoped=true&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/Overlay.vue?vue&type=style&index=0&id=2bcf09fc&lang=scss&scoped=true& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "[dir] .dark-layout div[data-v-2bcf09fc]  .card .card-body .b-overlay .bg-light {\n  background-color: #161d31 !important;\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/Overlay.vue?vue&type=style&index=0&id=2bcf09fc&lang=scss&scoped=true&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--7-2!./node_modules/sass-loader/dist/cjs.js??ref--7-3!./node_modules/sass-loader/dist/cjs.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/Overlay.vue?vue&type=style&index=0&id=2bcf09fc&lang=scss&scoped=true& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Overlay.vue?vue&type=style&index=0&id=2bcf09fc&lang=scss&scoped=true& */ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/Overlay.vue?vue&type=style&index=0&id=2bcf09fc&lang=scss&scoped=true&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/Overlay.vue?vue&type=template&id=2bcf09fc&scoped=true&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/Overlay.vue?vue&type=template&id=2bcf09fc&scoped=true& ***!
  \****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-row",
    [
      _c(
        "b-col",
        { attrs: { cols: "12" } },
        [
          _c("overlay-basic"),
          _vm._v(" "),
          _c("overlay-backdrop"),
          _vm._v(" "),
          _c("overlay-fade"),
          _vm._v(" "),
          _c("overlay-spinner"),
          _vm._v(" "),
          _c("overlay-corner-round"),
          _vm._v(" "),
          _c("overlay-custom-content"),
          _vm._v(" "),
          _c("overlay-no-wrap-mode"),
          _vm._v(" "),
          _c("overlay-form"),
          _vm._v(" "),
          _c("overlay-busy-state"),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayBackdrop.vue?vue&type=template&id=1ca7db10&":
/*!************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlayBackdrop.vue?vue&type=template&id=1ca7db10& ***!
  \************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Overlay backdrop color" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeBackdrop) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [
          _vm._v("You can control the backdrop background color via the "),
        ]),
        _vm._v(" "),
        _c("code", [_vm._v("variant")]),
        _vm._v(" "),
        _c("span", [
          _vm._v(" prop. The variant is translated into one of Bootstrap's "),
        ]),
        _vm._v(" "),
        _c("code", [_vm._v("background variant utility classes")]),
        _vm._v(" "),
        _c("span", [_vm._v(". Control the opacity of the backdrop via the")]),
        _vm._v(" "),
        _c("code", [_vm._v("opacity")]),
        _vm._v(" "),
        _c("span", [_vm._v(" prop (opacity values can range from ")]),
        _vm._v(" "),
        _c("code", [_vm._v("0")]),
        _vm._v(" "),
        _c("span", [_vm._v(" to ")]),
        _vm._v(" "),
        _c("code", [_vm._v("1")]),
        _vm._v(" "),
        _c("span", [
          _vm._v("). And background blurring can be controlled via the "),
        ]),
        _vm._v(" "),
        _c("code", [_vm._v("blur")]),
        _vm._v(" "),
        _c("span", [_vm._v(" prop.")]),
      ]),
      _vm._v(" "),
      _c(
        "b-row",
        [
          _c(
            "b-col",
            { attrs: { lg: "6", "aria-controls": "overlay-background" } },
            [
              _c(
                "b-form-group",
                {
                  attrs: {
                    label: "Variant",
                    "label-for": "bg-variant",
                    "label-cols-sm": "4",
                    "label-cols-lg": "12",
                  },
                },
                [
                  _c("b-form-select", {
                    attrs: { id: "bg-variant", options: _vm.variants },
                    model: {
                      value: _vm.variant,
                      callback: function ($$v) {
                        _vm.variant = $$v
                      },
                      expression: "variant",
                    },
                  }),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-form-group",
                {
                  attrs: {
                    label: "Opacity",
                    "label-for": "bg-opacity",
                    "label-cols-sm": "4",
                    "label-cols-lg": "12",
                  },
                },
                [
                  _c(
                    "b-input-group",
                    [
                      _c("b-form-input", {
                        attrs: {
                          id: "bg-opacity",
                          type: "range",
                          number: "",
                          min: "0",
                          max: "1",
                          step: "0.01",
                        },
                        model: {
                          value: _vm.opacity,
                          callback: function ($$v) {
                            _vm.opacity = $$v
                          },
                          expression: "opacity",
                        },
                      }),
                      _vm._v(" "),
                      _c(
                        "b-input-group-append",
                        {
                          staticClass: "text-monospace",
                          attrs: { "is-text": "" },
                        },
                        [
                          _vm._v(
                            "\n            " +
                              _vm._s(_vm.opacity.toFixed(2)) +
                              "\n          "
                          ),
                        ]
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-form-group",
                {
                  staticClass: "mb-2 mb-lg-0",
                  attrs: {
                    label: "Blur",
                    "label-for": "bg-blur",
                    "label-cols-sm": "4",
                    "label-cols-lg": "12",
                  },
                },
                [
                  _c("b-form-select", {
                    attrs: { id: "bg-blur", options: _vm.blurs },
                    model: {
                      value: _vm.blur,
                      callback: function ($$v) {
                        _vm.blur = $$v
                      },
                      expression: "blur",
                    },
                  }),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-col",
            { attrs: { lg: "6" } },
            [
              _c(
                "b-overlay",
                {
                  attrs: {
                    id: "overlay-background",
                    show: "",
                    variant: _vm.variant,
                    opacity: _vm.opacity,
                    blur: _vm.blur,
                    rounded: "sm",
                  },
                },
                [
                  _c(
                    "b-card",
                    {
                      staticClass: "mb-0",
                      attrs: {
                        title: "Card with overlay",
                        "aria-hidden": "true",
                      },
                    },
                    [
                      _c("b-card-text", [
                        _vm._v(
                          "\n            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et\n            dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip\n            ex ea commodo consequat.\n          "
                        ),
                      ]),
                      _vm._v(" "),
                      _c(
                        "b-button",
                        {
                          directives: [
                            {
                              name: "ripple",
                              rawName: "v-ripple.400",
                              value: "rgba(255, 255, 255, 0.15)",
                              expression: "'rgba(255, 255, 255, 0.15)'",
                              modifiers: { 400: true },
                            },
                          ],
                          attrs: { disabled: "", variant: "primary" },
                        },
                        [_vm._v("\n            Button\n          ")]
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayBasic.vue?vue&type=template&id=3ed6c97c&":
/*!*********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlayBasic.vue?vue&type=template&id=3ed6c97c& ***!
  \*********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Card with overlay" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeBasic) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-overlay", { attrs: { show: _vm.show, rounded: "sm" } }, [
        _c(
          "div",
          [
            _c("b-card-text", [
              _c("span", [_vm._v("BootstrapVue's custom ")]),
              _vm._v(" "),
              _c("code", [_vm._v("b-overlay")]),
              _vm._v(" "),
              _c("span", [
                _vm._v(
                  "\n          component is used to visually obscure a particular element or component and its content. It signals to the\n          user of a state change within the element or component and can be used for creating loaders,\n          warnings/alerts, prompts, and more.\n        "
                ),
              ]),
            ]),
            _vm._v(" "),
            _c(
              "b-button",
              {
                directives: [
                  {
                    name: "ripple",
                    rawName: "v-ripple.400",
                    value: "rgba(113, 102, 240, 0.15)",
                    expression: "'rgba(113, 102, 240, 0.15)'",
                    modifiers: { 400: true },
                  },
                ],
                attrs: { disabled: _vm.show, variant: "outline-primary" },
                on: {
                  click: function ($event) {
                    _vm.show = true
                  },
                },
              },
              [_vm._v("\n        Show overlay\n      ")]
            ),
          ],
          1
        ),
      ]),
      _vm._v(" "),
      _c(
        "b-button",
        {
          directives: [
            {
              name: "ripple",
              rawName: "v-ripple.400",
              value: "rgba(255, 255, 255, 0.15)",
              expression: "'rgba(255, 255, 255, 0.15)'",
              modifiers: { 400: true },
            },
          ],
          staticClass: "mt-1",
          attrs: { variant: "primary" },
          on: {
            click: function ($event) {
              _vm.show = !_vm.show
            },
          },
        },
        [_vm._v("\n    Toggle overlay\n  ")]
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayBusyState.vue?vue&type=template&id=b7400934&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlayBusyState.vue?vue&type=template&id=b7400934& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Busy state input group" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeBusyState) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _vm._v("In this example, we obscure the input and button:"),
      ]),
      _vm._v(" "),
      _c(
        "div",
        [
          _c(
            "b-overlay",
            {
              attrs: { show: _vm.busy, rounded: "lg", opacity: "0.6" },
              on: { hidden: _vm.onHidden },
              scopedSlots: _vm._u([
                {
                  key: "overlay",
                  fn: function () {
                    return [
                      _c(
                        "div",
                        { staticClass: "d-flex align-items-center" },
                        [
                          _c("b-spinner", {
                            attrs: {
                              small: "",
                              type: "grow",
                              variant: "secondary",
                            },
                          }),
                          _vm._v(" "),
                          _c("b-spinner", {
                            attrs: { type: "grow", variant: "dark" },
                          }),
                          _vm._v(" "),
                          _c("b-spinner", {
                            attrs: {
                              small: "",
                              type: "grow",
                              variant: "secondary",
                            },
                          }),
                          _vm._v(" "),
                          _c("span", { staticClass: "sr-only" }, [
                            _vm._v("Please wait..."),
                          ]),
                        ],
                        1
                      ),
                    ]
                  },
                  proxy: true,
                },
              ]),
            },
            [
              _vm._v(" "),
              _c(
                "b-input-group",
                {
                  attrs: {
                    size: "lg",
                    "aria-hidden": _vm.busy ? "true" : null,
                  },
                },
                [
                  _c("b-form-input", {
                    attrs: { disabled: _vm.busy },
                    model: {
                      value: _vm.value,
                      callback: function ($$v) {
                        _vm.value = $$v
                      },
                      expression: "value",
                    },
                  }),
                  _vm._v(" "),
                  _c(
                    "b-input-group-append",
                    [
                      _c(
                        "b-button",
                        {
                          directives: [
                            {
                              name: "ripple",
                              rawName: "v-ripple.400",
                              value: "rgba(255, 255, 255, 0.15)",
                              expression: "'rgba(255, 255, 255, 0.15)'",
                              modifiers: { 400: true },
                            },
                          ],
                          ref: "button",
                          attrs: { disabled: _vm.busy, variant: "primary" },
                          on: { click: _vm.onClick },
                        },
                        [_vm._v("\n            Do something\n          ")]
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayCornerRound.vue?vue&type=template&id=6a67d387&":
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlayCornerRound.vue?vue&type=template&id=6a67d387& ***!
  \***************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Overlay corner rounding" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeCornerRounded) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [
          _vm._v(
            "\n      By default, the overlay backdrop has square corners. If the content you are wrapping has rounded corners, you\n      can use the\n    "
          ),
        ]),
        _vm._v(" "),
        _c("code", [_vm._v("rounded")]),
        _vm._v(" "),
        _c("span", [
          _vm._v(
            " prop to apply rounding to the overlay's corners to match the obscured content's rounded corners."
          ),
        ]),
      ]),
      _vm._v(" "),
      _c(
        "div",
        [
          _c(
            "b-button",
            {
              directives: [
                {
                  name: "ripple",
                  rawName: "v-ripple.400",
                  value: "rgba(255, 255, 255, 0.15)",
                  expression: "'rgba(255, 255, 255, 0.15)'",
                  modifiers: { 400: true },
                },
              ],
              attrs: { variant: "primary" },
              on: {
                click: function ($event) {
                  _vm.show = !_vm.show
                },
              },
            },
            [_vm._v("\n      Toggle overlay\n    ")]
          ),
          _vm._v(" "),
          _c(
            "b-row",
            { staticClass: "text-center mt-2" },
            [
              _c(
                "b-col",
                { attrs: { md: "6" } },
                [
                  _c("b-card-text", [_vm._v("With rounding")]),
                  _vm._v(" "),
                  _c(
                    "b-overlay",
                    {
                      staticClass: "d-inline-block",
                      attrs: { show: _vm.show, rounded: "circle" },
                    },
                    [
                      _c("b-img", {
                        attrs: {
                          rounded: "circle",
                          height: "300",
                          src: __webpack_require__(/*! @/assets/images/banner/banner-27.jpg */ "./resources/js/src/assets/images/banner/banner-27.jpg"),
                          alt: "Image 1",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-col",
                { staticClass: "mt-1 mt-md-0", attrs: { md: "6" } },
                [
                  _c("b-card-text", [_vm._v("Without rounding")]),
                  _vm._v(" "),
                  _c(
                    "b-overlay",
                    {
                      staticClass: "d-inline-block",
                      attrs: { show: _vm.show },
                    },
                    [
                      _c("b-img", {
                        attrs: {
                          rounded: "circle",
                          height: "300",
                          src: __webpack_require__(/*! @/assets/images/banner/banner-27.jpg */ "./resources/js/src/assets/images/banner/banner-27.jpg"),
                          alt: "Image 1",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayCustomContent.vue?vue&type=template&id=5a7b9bd4&":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlayCustomContent.vue?vue&type=template&id=5a7b9bd4& ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Custom overlay content" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeCustomContent) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [
          _vm._v(
            "Place custom content in the overlay (replacing the default spinner) via the optionally scoped slot "
          ),
        ]),
        _vm._v(" "),
        _c("code", [_vm._v("overlay")]),
      ]),
      _vm._v(" "),
      _c(
        "div",
        [
          _c(
            "b-overlay",
            {
              attrs: { show: _vm.show, rounded: "sm" },
              on: { shown: _vm.onShown, hidden: _vm.onHidden },
              scopedSlots: _vm._u([
                {
                  key: "overlay",
                  fn: function () {
                    return [
                      _c(
                        "div",
                        { staticClass: "text-center" },
                        [
                          _c("feather-icon", {
                            attrs: { icon: "ClockIcon", size: "24" },
                          }),
                          _vm._v(" "),
                          _c("b-card-text", { attrs: { id: "cancel-label" } }, [
                            _vm._v("\n            Please wait...\n          "),
                          ]),
                          _vm._v(" "),
                          _c(
                            "b-button",
                            {
                              directives: [
                                {
                                  name: "ripple",
                                  rawName: "v-ripple.400",
                                  value: "rgba(255, 255, 255, 0.15)",
                                  expression: "'rgba(255, 255, 255, 0.15)'",
                                  modifiers: { 400: true },
                                },
                              ],
                              ref: "cancel",
                              attrs: {
                                variant: "outline-danger",
                                size: "sm",
                                "aria-describedby": "cancel-label",
                              },
                              on: {
                                click: function ($event) {
                                  _vm.show = false
                                },
                              },
                            },
                            [_vm._v("\n            Cancel\n          ")]
                          ),
                        ],
                        1
                      ),
                    ]
                  },
                  proxy: true,
                },
              ]),
            },
            [
              _c(
                "div",
                [
                  _c("h6", [_vm._v("Card with custom overlay content")]),
                  _vm._v(" "),
                  _c("b-card-text", [
                    _vm._v(
                      "Lorem ipsum dolor sit amet, consectetur adipiscing elit."
                    ),
                  ]),
                  _vm._v(" "),
                  _c("b-card-text", [
                    _vm._v("Click the button to toggle the overlay:"),
                  ]),
                  _vm._v(" "),
                  _c(
                    "b-button",
                    {
                      directives: [
                        {
                          name: "ripple",
                          rawName: "v-ripple.400",
                          value: "rgba(255, 255, 255, 0.15)",
                          expression: "'rgba(255, 255, 255, 0.15)'",
                          modifiers: { 400: true },
                        },
                      ],
                      ref: "show",
                      attrs: { disabled: _vm.show, variant: "primary" },
                      on: {
                        click: function ($event) {
                          _vm.show = true
                        },
                      },
                    },
                    [_vm._v("\n          Show overlay\n        ")]
                  ),
                ],
                1
              ),
            ]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayFade.vue?vue&type=template&id=2cccd29e&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlayFade.vue?vue&type=template&id=2cccd29e& ***!
  \********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Fade transition" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeFade) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [
          _vm._v(
            "By default, the overlay uses Bootstrap's fade transition when showing or hiding. You can disable the fade\n      transition via adding the\n    "
          ),
        ]),
        _vm._v(" "),
        _c("code", [_vm._v("no-fade")]),
        _vm._v(" "),
        _c("span", [_vm._v(" prop to ")]),
        _vm._v(" "),
        _c("code", [_vm._v(" <b-overlay>.")]),
      ]),
      _vm._v(" "),
      _c(
        "div",
        [
          _c(
            "b-overlay",
            { attrs: { show: _vm.show, rounded: "sm", "no-fade": "" } },
            [
              _c(
                "div",
                {
                  attrs: {
                    title: "Card with overlay",
                    "aria-hidden": _vm.show ? "true" : null,
                  },
                },
                [
                  _c("b-card-text", [
                    _vm._v(
                      "\n          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio voluptatibus doloremque dolor nesciunt\n          est nobis consequuntur maxime ea ipsam? Doloribus quidem doloremque ad laudantium ullam eos, consequuntur\n          velit quas vero.\n        "
                    ),
                  ]),
                  _vm._v(" "),
                  _c(
                    "b-button",
                    {
                      directives: [
                        {
                          name: "ripple",
                          rawName: "v-ripple.400",
                          value: "rgba(113, 102, 240, 0.15)",
                          expression: "'rgba(113, 102, 240, 0.15)'",
                          modifiers: { 400: true },
                        },
                      ],
                      attrs: { disabled: _vm.show, variant: "outline-primary" },
                      on: {
                        click: function ($event) {
                          _vm.show = true
                        },
                      },
                    },
                    [_vm._v("\n          Show overlay\n        ")]
                  ),
                ],
                1
              ),
            ]
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              directives: [
                {
                  name: "ripple",
                  rawName: "v-ripple.400",
                  value: "rgba(255, 255, 255, 0.15)",
                  expression: "'rgba(255, 255, 255, 0.15)'",
                  modifiers: { 400: true },
                },
              ],
              staticClass: "mt-1",
              attrs: { variant: "primary" },
              on: {
                click: function ($event) {
                  _vm.show = !_vm.show
                },
              },
            },
            [_vm._v("\n      Toggle overlay\n    ")]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayForm.vue?vue&type=template&id=29b8a4e6&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlayForm.vue?vue&type=template&id=29b8a4e6& ***!
  \********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Form confirmation prompt and upload status" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeForm) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [
          _vm._v("This example is a bit more complex, but shows the use of "),
        ]),
        _vm._v(" "),
        _c("code", [_vm._v("no-wrap")]),
        _vm._v(" "),
        _c("span", [_vm._v(" , and using the ")]),
        _vm._v(" "),
        _c("code", [_vm._v("overlay")]),
        _vm._v(" "),
        _c("span", [
          _vm._v(
            " slot to present the user with a prompt dialog, and once confirmed it shows a uploading status indicator. This\n      example also demonstrates additional accessibility markup.\n    "
          ),
        ]),
      ]),
      _vm._v(" "),
      _c(
        "div",
        [
          _c(
            "b-form",
            {
              staticClass: "position-relative",
              on: {
                submit: function ($event) {
                  $event.preventDefault()
                  return _vm.onSubmit.apply(null, arguments)
                },
              },
            },
            [
              _c(
                "b-form-group",
                {
                  attrs: {
                    label: "Name",
                    "label-for": "form-name",
                    "label-cols-lg": "2",
                  },
                },
                [
                  _c(
                    "b-input-group",
                    [
                      _c(
                        "b-input-group-prepend",
                        { attrs: { "is-text": "" } },
                        [_c("feather-icon", { attrs: { icon: "UserIcon" } })],
                        1
                      ),
                      _vm._v(" "),
                      _c("b-form-input", {
                        attrs: { id: "form-name", disabled: _vm.busy },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-form-group",
                {
                  attrs: {
                    label: "Email",
                    "label-for": "form-mail",
                    "label-cols-lg": "2",
                  },
                },
                [
                  _c(
                    "b-input-group",
                    [
                      _c(
                        "b-input-group-prepend",
                        { attrs: { "is-text": "" } },
                        [_c("feather-icon", { attrs: { icon: "MailIcon" } })],
                        1
                      ),
                      _vm._v(" "),
                      _c("b-form-input", {
                        attrs: {
                          id: "form-email",
                          type: "email",
                          disabled: _vm.busy,
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-form-group",
                {
                  attrs: {
                    label: "Image",
                    "label-for": "form-image",
                    "label-cols-lg": "2",
                  },
                },
                [
                  _c(
                    "b-input-group",
                    [
                      _c(
                        "b-input-group-prepend",
                        { attrs: { "is-text": "" } },
                        [_c("feather-icon", { attrs: { icon: "ImageIcon" } })],
                        1
                      ),
                      _vm._v(" "),
                      _c("b-form-file", {
                        attrs: {
                          id: "form-image",
                          disabled: _vm.busy,
                          accept: "image/*",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "div",
                { staticClass: "d-flex justify-content-center" },
                [
                  _c(
                    "b-button",
                    {
                      directives: [
                        {
                          name: "ripple",
                          rawName: "v-ripple.400",
                          value: "rgba(255, 255, 255, 0.15)",
                          expression: "'rgba(255, 255, 255, 0.15)'",
                          modifiers: { 400: true },
                        },
                      ],
                      ref: "submit",
                      attrs: {
                        variant: "primary",
                        type: "submit",
                        disabled: _vm.busy,
                      },
                    },
                    [_vm._v("\n          Submit\n        ")]
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("b-overlay", {
                attrs: { show: _vm.busy, "no-wrap": "" },
                on: { shown: _vm.onShown, hidden: _vm.onHidden },
                scopedSlots: _vm._u([
                  {
                    key: "overlay",
                    fn: function () {
                      return [
                        _vm.processing
                          ? _c(
                              "div",
                              {
                                staticClass:
                                  "text-center p-3 bg-primary text-light rounded",
                              },
                              [
                                _c("feather-icon", {
                                  attrs: {
                                    icon: "UploadCloudIcon",
                                    size: "20",
                                  },
                                }),
                                _vm._v(" "),
                                _c("div", { staticClass: "mb-2" }, [
                                  _vm._v(
                                    "\n              Processing...\n            "
                                  ),
                                ]),
                                _vm._v(" "),
                                _c("b-progress", {
                                  staticClass: "mx-n3",
                                  attrs: {
                                    min: "1",
                                    max: "20",
                                    value: _vm.counter,
                                    variant: "success",
                                    height: "6px",
                                  },
                                }),
                              ],
                              1
                            )
                          : _c(
                              "div",
                              {
                                ref: "dialog",
                                staticClass: "text-center p-3",
                                attrs: {
                                  tabindex: "-1",
                                  role: "dialog",
                                  "aria-modal": "false",
                                  "aria-labelledby": "form-confirm-label",
                                },
                              },
                              [
                                _c(
                                  "b-card-text",
                                  { staticClass: "font-weight-bolder" },
                                  [
                                    _vm._v(
                                      "\n              Are you sure?\n            "
                                    ),
                                  ]
                                ),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  { staticClass: "d-flex" },
                                  [
                                    _c(
                                      "b-button",
                                      {
                                        directives: [
                                          {
                                            name: "ripple",
                                            rawName: "v-ripple.400",
                                            value: "rgba(234, 84, 85, 0.15)",
                                            expression:
                                              "'rgba(234, 84, 85, 0.15)'",
                                            modifiers: { 400: true },
                                          },
                                        ],
                                        staticClass: "mr-3",
                                        attrs: { variant: "outline-danger" },
                                        on: { click: _vm.onCancel },
                                      },
                                      [
                                        _vm._v(
                                          "\n                Cancel\n              "
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "b-button",
                                      {
                                        directives: [
                                          {
                                            name: "ripple",
                                            rawName: "v-ripple.400",
                                            value: "rgba(40, 199, 111, 0.15)",
                                            expression:
                                              "'rgba(40, 199, 111, 0.15)'",
                                            modifiers: { 400: true },
                                          },
                                        ],
                                        attrs: { variant: "outline-success" },
                                        on: { click: _vm.onOK },
                                      },
                                      [
                                        _vm._v(
                                          "\n                OK\n              "
                                        ),
                                      ]
                                    ),
                                  ],
                                  1
                                ),
                              ],
                              1
                            ),
                      ]
                    },
                    proxy: true,
                  },
                ]),
              }),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayNoWrapMode.vue?vue&type=template&id=395de4e0&":
/*!**************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlayNoWrapMode.vue?vue&type=template&id=395de4e0& ***!
  \**************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Non-wrapping mode" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeNoWrapMode) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [_vm._v("By default, ")]),
        _vm._v(" "),
        _c("code", [_vm._v("<b-overlay>")]),
        _vm._v(" "),
        _c("span", [
          _vm._v(
            " wraps the content of the default slot. In some cases you may want to obscure a parent container. Use the "
          ),
        ]),
        _vm._v(" "),
        _c("code", [_vm._v("no-wrap")]),
        _vm._v(" "),
        _c("span", [
          _vm._v(
            " prop to disable rendering of the wrapping (and ignore the default slot). Note that this requires that the\n      ancestor element that is to be obscured to have relative positioning (either via the utility class "
          ),
        ]),
        _vm._v(" "),
        _c("code", [_vm._v("'position-relative'")]),
        _vm._v(" "),
        _c("span", [_vm._v(" , or CSS style ")]),
        _vm._v(" "),
        _c("code", [_vm._v("'position: relative;'")]),
        _vm._v(" "),
        _c("span", [_vm._v(").")]),
      ]),
      _vm._v(" "),
      _c(
        "div",
        [
          _c(
            "div",
            { staticClass: "position-relative p-2 bg-info" },
            [
              _c(
                "b-card-text",
                { staticClass: "text-white font-weight-bold" },
                [
                  _vm._v(
                    "\n        Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n      "
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "b-card",
                {
                  staticClass: "mb-1",
                  attrs: { title: "Card with parent overlay" },
                },
                [
                  _c("b-card-text", [
                    _vm._v(
                      "Laborum consequat non elit enim exercitation cillum."
                    ),
                  ]),
                  _vm._v(" "),
                  _c("b-card-text", [
                    _vm._v("Click the button to toggle the overlay:"),
                  ]),
                  _vm._v(" "),
                  _c(
                    "b-button",
                    {
                      directives: [
                        {
                          name: "ripple",
                          rawName: "v-ripple.400",
                          value: "rgba(113, 102, 240, 0.15)",
                          expression: "'rgba(113, 102, 240, 0.15)'",
                          modifiers: { 400: true },
                        },
                      ],
                      attrs: { disabled: _vm.show, variant: "outline-primary" },
                      on: {
                        click: function ($event) {
                          _vm.show = true
                        },
                      },
                    },
                    [_vm._v("\n          Show overlay\n        ")]
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "b-card-text",
                { staticClass: "text-white font-weight-bold mb-0" },
                [
                  _vm._v(
                    "\n        Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n      "
                  ),
                ]
              ),
              _vm._v(" "),
              _c("b-overlay", { attrs: { show: _vm.show, "no-wrap": "" } }),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-button",
            {
              directives: [
                {
                  name: "ripple",
                  rawName: "v-ripple.400",
                  value: "rgba(255, 255, 255, 0.15)",
                  expression: "'rgba(255, 255, 255, 0.15)'",
                  modifiers: { 400: true },
                },
              ],
              staticClass: "mt-3",
              attrs: { variant: "primary" },
              on: {
                click: function ($event) {
                  _vm.show = !_vm.show
                },
              },
            },
            [_vm._v("\n      Toggle overlay\n    ")]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlaySpinner.vue?vue&type=template&id=102fb732&":
/*!***********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/overlay/OverlaySpinner.vue?vue&type=template&id=102fb732& ***!
  \***********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Default spinner styling" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeSpinner) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [_vm._v("The default overlay content is a ")]),
        _vm._v(" "),
        _c("code", [_vm._v("<b-spinner>")]),
        _vm._v(" "),
        _c("span", [_vm._v(" of type ")]),
        _vm._v(" "),
        _c("code", [_vm._v("'border'")]),
        _vm._v(" "),
        _c("span", [
          _vm._v(
            ". You can control the appearance of the spinner via the following props:"
          ),
        ]),
      ]),
      _vm._v(" "),
      _c(
        "b-overlay",
        {
          attrs: {
            show: "",
            "spinner-variant": "primary",
            "spinner-type": "grow",
            "spinner-small": "",
            rounded: "sm",
          },
        },
        [
          _c(
            "b-card",
            {
              staticClass: "mb-0",
              attrs: {
                title: "Card with spinner style",
                "aria-hidden": "true",
              },
            },
            [
              _c("b-card-text", [
                _vm._v(
                  "\n        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et\n        dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex\n        ea commodo consequat.\n      "
                ),
              ]),
              _vm._v(" "),
              _c(
                "b-button",
                {
                  directives: [
                    {
                      name: "ripple",
                      rawName: "v-ripple.400",
                      value: "rgba(255, 255, 255, 0.15)",
                      expression: "'rgba(255, 255, 255, 0.15)'",
                      modifiers: { 400: true },
                    },
                  ],
                  attrs: { disabled: "", variant: "primary" },
                },
                [_vm._v("\n        Button\n      ")]
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-prism-component/dist/vue-prism-component.common.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/vue-prism-component/dist/vue-prism-component.common.js ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var Prism = _interopDefault(__webpack_require__(/*! prismjs */ "./node_modules/prismjs/prism.js"));

function assign(obj) {
  for (var i = 1; i < arguments.length; i++) {
    // eslint-disable-next-line guard-for-in, prefer-rest-params
    for (var p in arguments[i]) {
      obj[p] = arguments[i][p];
    }
  }

  return obj;
}

var index = {
  functional: true,
  props: {
    code: {
      type: String
    },
    inline: {
      type: Boolean,
      "default": false
    },
    language: {
      type: String,
      "default": 'markup'
    }
  },
  render: function render(h, ctx) {
    var code = ctx.props.code || (ctx.children && ctx.children.length > 0 ? ctx.children[0].text : '');
    var inline = ctx.props.inline;
    var language = ctx.props.language;
    var prismLanguage = Prism.languages[language];
    var className = "language-".concat(language);

    if ( true && !prismLanguage) {
      throw new Error("Prism component for language \"".concat(language, "\" was not found, did you forget to register it? See all available ones: https://cdn.jsdelivr.net/npm/prismjs/components/"));
    }

    if (inline) {
      return h('code', assign({}, ctx.data, {
        "class": [ctx.data["class"], className],
        domProps: assign({}, ctx.data.domProps, {
          innerHTML: Prism.highlight(code, prismLanguage)
        })
      }));
    }

    return h('pre', assign({}, ctx.data, {
      "class": [ctx.data["class"], className]
    }), [h('code', {
      "class": className,
      domProps: {
        innerHTML: Prism.highlight(code, prismLanguage)
      }
    })]);
  }
};

module.exports = index;


/***/ }),

/***/ "./resources/js/src/@core/components/b-card-code/index.js":
/*!****************************************************************!*\
  !*** ./resources/js/src/@core/components/b-card-code/index.js ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");

/* harmony default export */ __webpack_exports__["default"] = (_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"]);

/***/ }),

/***/ "./resources/js/src/views/components/overlay/Overlay.vue":
/*!***************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/Overlay.vue ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Overlay_vue_vue_type_template_id_2bcf09fc_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Overlay.vue?vue&type=template&id=2bcf09fc&scoped=true& */ "./resources/js/src/views/components/overlay/Overlay.vue?vue&type=template&id=2bcf09fc&scoped=true&");
/* harmony import */ var _Overlay_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Overlay.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/overlay/Overlay.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Overlay_vue_vue_type_style_index_0_id_2bcf09fc_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Overlay.vue?vue&type=style&index=0&id=2bcf09fc&lang=scss&scoped=true& */ "./resources/js/src/views/components/overlay/Overlay.vue?vue&type=style&index=0&id=2bcf09fc&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Overlay_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Overlay_vue_vue_type_template_id_2bcf09fc_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Overlay_vue_vue_type_template_id_2bcf09fc_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "2bcf09fc",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/overlay/Overlay.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/overlay/Overlay.vue?vue&type=script&lang=js&":
/*!****************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/Overlay.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Overlay_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Overlay.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/Overlay.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Overlay_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/overlay/Overlay.vue?vue&type=style&index=0&id=2bcf09fc&lang=scss&scoped=true&":
/*!*************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/Overlay.vue?vue&type=style&index=0&id=2bcf09fc&lang=scss&scoped=true& ***!
  \*************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Overlay_vue_vue_type_style_index_0_id_2bcf09fc_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/style-loader!../../../../../../node_modules/css-loader/dist/cjs.js!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/src??ref--7-2!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--7-3!../../../../../../node_modules/sass-loader/dist/cjs.js??ref--11-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Overlay.vue?vue&type=style&index=0&id=2bcf09fc&lang=scss&scoped=true& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/Overlay.vue?vue&type=style&index=0&id=2bcf09fc&lang=scss&scoped=true&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Overlay_vue_vue_type_style_index_0_id_2bcf09fc_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Overlay_vue_vue_type_style_index_0_id_2bcf09fc_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Overlay_vue_vue_type_style_index_0_id_2bcf09fc_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_2_node_modules_sass_loader_dist_cjs_js_ref_7_3_node_modules_sass_loader_dist_cjs_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Overlay_vue_vue_type_style_index_0_id_2bcf09fc_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/src/views/components/overlay/Overlay.vue?vue&type=template&id=2bcf09fc&scoped=true&":
/*!**********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/Overlay.vue?vue&type=template&id=2bcf09fc&scoped=true& ***!
  \**********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Overlay_vue_vue_type_template_id_2bcf09fc_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Overlay.vue?vue&type=template&id=2bcf09fc&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/Overlay.vue?vue&type=template&id=2bcf09fc&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Overlay_vue_vue_type_template_id_2bcf09fc_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Overlay_vue_vue_type_template_id_2bcf09fc_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayBackdrop.vue":
/*!***********************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayBackdrop.vue ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OverlayBackdrop_vue_vue_type_template_id_1ca7db10___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OverlayBackdrop.vue?vue&type=template&id=1ca7db10& */ "./resources/js/src/views/components/overlay/OverlayBackdrop.vue?vue&type=template&id=1ca7db10&");
/* harmony import */ var _OverlayBackdrop_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OverlayBackdrop.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/overlay/OverlayBackdrop.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OverlayBackdrop_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _OverlayBackdrop_vue_vue_type_template_id_1ca7db10___WEBPACK_IMPORTED_MODULE_0__["render"],
  _OverlayBackdrop_vue_vue_type_template_id_1ca7db10___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/overlay/OverlayBackdrop.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayBackdrop.vue?vue&type=script&lang=js&":
/*!************************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayBackdrop.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayBackdrop_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlayBackdrop.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayBackdrop.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayBackdrop_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayBackdrop.vue?vue&type=template&id=1ca7db10&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayBackdrop.vue?vue&type=template&id=1ca7db10& ***!
  \******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayBackdrop_vue_vue_type_template_id_1ca7db10___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlayBackdrop.vue?vue&type=template&id=1ca7db10& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayBackdrop.vue?vue&type=template&id=1ca7db10&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayBackdrop_vue_vue_type_template_id_1ca7db10___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayBackdrop_vue_vue_type_template_id_1ca7db10___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayBasic.vue":
/*!********************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayBasic.vue ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OverlayBasic_vue_vue_type_template_id_3ed6c97c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OverlayBasic.vue?vue&type=template&id=3ed6c97c& */ "./resources/js/src/views/components/overlay/OverlayBasic.vue?vue&type=template&id=3ed6c97c&");
/* harmony import */ var _OverlayBasic_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OverlayBasic.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/overlay/OverlayBasic.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OverlayBasic_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _OverlayBasic_vue_vue_type_template_id_3ed6c97c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _OverlayBasic_vue_vue_type_template_id_3ed6c97c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/overlay/OverlayBasic.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayBasic.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayBasic.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayBasic_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlayBasic.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayBasic.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayBasic_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayBasic.vue?vue&type=template&id=3ed6c97c&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayBasic.vue?vue&type=template&id=3ed6c97c& ***!
  \***************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayBasic_vue_vue_type_template_id_3ed6c97c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlayBasic.vue?vue&type=template&id=3ed6c97c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayBasic.vue?vue&type=template&id=3ed6c97c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayBasic_vue_vue_type_template_id_3ed6c97c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayBasic_vue_vue_type_template_id_3ed6c97c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayBusyState.vue":
/*!************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayBusyState.vue ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OverlayBusyState_vue_vue_type_template_id_b7400934___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OverlayBusyState.vue?vue&type=template&id=b7400934& */ "./resources/js/src/views/components/overlay/OverlayBusyState.vue?vue&type=template&id=b7400934&");
/* harmony import */ var _OverlayBusyState_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OverlayBusyState.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/overlay/OverlayBusyState.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OverlayBusyState_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _OverlayBusyState_vue_vue_type_template_id_b7400934___WEBPACK_IMPORTED_MODULE_0__["render"],
  _OverlayBusyState_vue_vue_type_template_id_b7400934___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/overlay/OverlayBusyState.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayBusyState.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayBusyState.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayBusyState_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlayBusyState.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayBusyState.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayBusyState_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayBusyState.vue?vue&type=template&id=b7400934&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayBusyState.vue?vue&type=template&id=b7400934& ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayBusyState_vue_vue_type_template_id_b7400934___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlayBusyState.vue?vue&type=template&id=b7400934& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayBusyState.vue?vue&type=template&id=b7400934&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayBusyState_vue_vue_type_template_id_b7400934___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayBusyState_vue_vue_type_template_id_b7400934___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayCornerRound.vue":
/*!**************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayCornerRound.vue ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OverlayCornerRound_vue_vue_type_template_id_6a67d387___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OverlayCornerRound.vue?vue&type=template&id=6a67d387& */ "./resources/js/src/views/components/overlay/OverlayCornerRound.vue?vue&type=template&id=6a67d387&");
/* harmony import */ var _OverlayCornerRound_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OverlayCornerRound.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/overlay/OverlayCornerRound.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OverlayCornerRound_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _OverlayCornerRound_vue_vue_type_template_id_6a67d387___WEBPACK_IMPORTED_MODULE_0__["render"],
  _OverlayCornerRound_vue_vue_type_template_id_6a67d387___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/overlay/OverlayCornerRound.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayCornerRound.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayCornerRound.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayCornerRound_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlayCornerRound.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayCornerRound.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayCornerRound_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayCornerRound.vue?vue&type=template&id=6a67d387&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayCornerRound.vue?vue&type=template&id=6a67d387& ***!
  \*********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayCornerRound_vue_vue_type_template_id_6a67d387___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlayCornerRound.vue?vue&type=template&id=6a67d387& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayCornerRound.vue?vue&type=template&id=6a67d387&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayCornerRound_vue_vue_type_template_id_6a67d387___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayCornerRound_vue_vue_type_template_id_6a67d387___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayCustomContent.vue":
/*!****************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayCustomContent.vue ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OverlayCustomContent_vue_vue_type_template_id_5a7b9bd4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OverlayCustomContent.vue?vue&type=template&id=5a7b9bd4& */ "./resources/js/src/views/components/overlay/OverlayCustomContent.vue?vue&type=template&id=5a7b9bd4&");
/* harmony import */ var _OverlayCustomContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OverlayCustomContent.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/overlay/OverlayCustomContent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OverlayCustomContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _OverlayCustomContent_vue_vue_type_template_id_5a7b9bd4___WEBPACK_IMPORTED_MODULE_0__["render"],
  _OverlayCustomContent_vue_vue_type_template_id_5a7b9bd4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/overlay/OverlayCustomContent.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayCustomContent.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayCustomContent.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayCustomContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlayCustomContent.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayCustomContent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayCustomContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayCustomContent.vue?vue&type=template&id=5a7b9bd4&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayCustomContent.vue?vue&type=template&id=5a7b9bd4& ***!
  \***********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayCustomContent_vue_vue_type_template_id_5a7b9bd4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlayCustomContent.vue?vue&type=template&id=5a7b9bd4& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayCustomContent.vue?vue&type=template&id=5a7b9bd4&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayCustomContent_vue_vue_type_template_id_5a7b9bd4___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayCustomContent_vue_vue_type_template_id_5a7b9bd4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayFade.vue":
/*!*******************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayFade.vue ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OverlayFade_vue_vue_type_template_id_2cccd29e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OverlayFade.vue?vue&type=template&id=2cccd29e& */ "./resources/js/src/views/components/overlay/OverlayFade.vue?vue&type=template&id=2cccd29e&");
/* harmony import */ var _OverlayFade_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OverlayFade.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/overlay/OverlayFade.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OverlayFade_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _OverlayFade_vue_vue_type_template_id_2cccd29e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _OverlayFade_vue_vue_type_template_id_2cccd29e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/overlay/OverlayFade.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayFade.vue?vue&type=script&lang=js&":
/*!********************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayFade.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayFade_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlayFade.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayFade.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayFade_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayFade.vue?vue&type=template&id=2cccd29e&":
/*!**************************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayFade.vue?vue&type=template&id=2cccd29e& ***!
  \**************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayFade_vue_vue_type_template_id_2cccd29e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlayFade.vue?vue&type=template&id=2cccd29e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayFade.vue?vue&type=template&id=2cccd29e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayFade_vue_vue_type_template_id_2cccd29e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayFade_vue_vue_type_template_id_2cccd29e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayForm.vue":
/*!*******************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayForm.vue ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OverlayForm_vue_vue_type_template_id_29b8a4e6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OverlayForm.vue?vue&type=template&id=29b8a4e6& */ "./resources/js/src/views/components/overlay/OverlayForm.vue?vue&type=template&id=29b8a4e6&");
/* harmony import */ var _OverlayForm_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OverlayForm.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/overlay/OverlayForm.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OverlayForm_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _OverlayForm_vue_vue_type_template_id_29b8a4e6___WEBPACK_IMPORTED_MODULE_0__["render"],
  _OverlayForm_vue_vue_type_template_id_29b8a4e6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/overlay/OverlayForm.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayForm.vue?vue&type=script&lang=js&":
/*!********************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayForm.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayForm_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlayForm.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayForm.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayForm_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayForm.vue?vue&type=template&id=29b8a4e6&":
/*!**************************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayForm.vue?vue&type=template&id=29b8a4e6& ***!
  \**************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayForm_vue_vue_type_template_id_29b8a4e6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlayForm.vue?vue&type=template&id=29b8a4e6& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayForm.vue?vue&type=template&id=29b8a4e6&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayForm_vue_vue_type_template_id_29b8a4e6___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayForm_vue_vue_type_template_id_29b8a4e6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayNoWrapMode.vue":
/*!*************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayNoWrapMode.vue ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OverlayNoWrapMode_vue_vue_type_template_id_395de4e0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OverlayNoWrapMode.vue?vue&type=template&id=395de4e0& */ "./resources/js/src/views/components/overlay/OverlayNoWrapMode.vue?vue&type=template&id=395de4e0&");
/* harmony import */ var _OverlayNoWrapMode_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OverlayNoWrapMode.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/overlay/OverlayNoWrapMode.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OverlayNoWrapMode_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _OverlayNoWrapMode_vue_vue_type_template_id_395de4e0___WEBPACK_IMPORTED_MODULE_0__["render"],
  _OverlayNoWrapMode_vue_vue_type_template_id_395de4e0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/overlay/OverlayNoWrapMode.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayNoWrapMode.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayNoWrapMode.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayNoWrapMode_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlayNoWrapMode.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayNoWrapMode.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayNoWrapMode_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlayNoWrapMode.vue?vue&type=template&id=395de4e0&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlayNoWrapMode.vue?vue&type=template&id=395de4e0& ***!
  \********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayNoWrapMode_vue_vue_type_template_id_395de4e0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlayNoWrapMode.vue?vue&type=template&id=395de4e0& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlayNoWrapMode.vue?vue&type=template&id=395de4e0&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayNoWrapMode_vue_vue_type_template_id_395de4e0___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlayNoWrapMode_vue_vue_type_template_id_395de4e0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlaySpinner.vue":
/*!**********************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlaySpinner.vue ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _OverlaySpinner_vue_vue_type_template_id_102fb732___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./OverlaySpinner.vue?vue&type=template&id=102fb732& */ "./resources/js/src/views/components/overlay/OverlaySpinner.vue?vue&type=template&id=102fb732&");
/* harmony import */ var _OverlaySpinner_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./OverlaySpinner.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/overlay/OverlaySpinner.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _OverlaySpinner_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _OverlaySpinner_vue_vue_type_template_id_102fb732___WEBPACK_IMPORTED_MODULE_0__["render"],
  _OverlaySpinner_vue_vue_type_template_id_102fb732___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/overlay/OverlaySpinner.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlaySpinner.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlaySpinner.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlaySpinner_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlaySpinner.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlaySpinner.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlaySpinner_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/overlay/OverlaySpinner.vue?vue&type=template&id=102fb732&":
/*!*****************************************************************************************************!*\
  !*** ./resources/js/src/views/components/overlay/OverlaySpinner.vue?vue&type=template&id=102fb732& ***!
  \*****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlaySpinner_vue_vue_type_template_id_102fb732___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./OverlaySpinner.vue?vue&type=template&id=102fb732& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/overlay/OverlaySpinner.vue?vue&type=template&id=102fb732&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlaySpinner_vue_vue_type_template_id_102fb732___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_OverlaySpinner_vue_vue_type_template_id_102fb732___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/overlay/code.js":
/*!***********************************************************!*\
  !*** ./resources/js/src/views/components/overlay/code.js ***!
  \***********************************************************/
/*! exports provided: codeBasic, codeBackdrop, codeFade, codeSpinner, codeCornerRounded, codeCustomContent, codeNoWrapMode, codeForm, codeBusyState */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeBasic", function() { return codeBasic; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeBackdrop", function() { return codeBackdrop; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeFade", function() { return codeFade; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeSpinner", function() { return codeSpinner; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeCornerRounded", function() { return codeCornerRounded; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeCustomContent", function() { return codeCustomContent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeNoWrapMode", function() { return codeNoWrapMode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeForm", function() { return codeForm; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeBusyState", function() { return codeBusyState; });
var codeBasic = "\n<template>\n  <div>\n    <b-overlay\n      :show=\"show\"\n      rounded=\"sm\"\n    >\n      <div>\n        <b-card-text>\n          <span>BootstrapVue's custom </span>\n          <code>b-overlay</code>\n          <span>\n            component is used to visually obscure a particular element or component and its content. It signals to the\n            user of a state change within the element or component and can be used for creating loaders,\n            warnings/alerts, prompts, and more.\n          </span>\n        </b-card-text>\n\n        <b-button\n          v-ripple.400=\"'rgba(113, 102, 240, 0.15)'\"\n          :disabled=\"show\"\n          variant=\"outline-primary\"\n          @click=\"show = true\"\n        >\n          Show overlay\n        </b-button>\n      </div>\n    </b-overlay>\n\n    <b-button\n      v-ripple.400=\"'rgba(255, 255, 255, 0.15)'\"\n      variant=\"primary\"\n      class=\"mt-1\"\n      @click=\"show = !show\"\n    >\n      Toggle overlay\n    </b-button>\n  </div>\n</template>\n\n<script>\nimport { BOverlay, BButton, BCardText } from 'bootstrap-vue'\nimport Ripple from 'vue-ripple-directive'\n\nexport default {\n  components: {\n    BOverlay,\n    BButton,\n    BCardText,\n  },\n  directives: {\n    Ripple,\n  },\n  data: () => ({\n    show: false,\n  }),\n}\n</script>\n";
var codeBackdrop = "\n<template>\n  <b-row>\n    <b-col\n      lg=\"6\"\n      aria-controls=\"overlay-background\"\n    >\n      <b-form-group\n        label=\"Variant\"\n        label-for=\"bg-variant\"\n        label-cols-sm=\"4\"\n        label-cols-lg=\"12\"\n      >\n        <b-form-select\n          id=\"bg-variant\"\n          v-model=\"variant\"\n          :options=\"variants\"\n        />\n      </b-form-group>\n      <b-form-group\n        label=\"Opacity\"\n        label-for=\"bg-opacity\"\n        label-cols-sm=\"4\"\n        label-cols-lg=\"12\"\n      >\n        <b-input-group>\n          <b-form-input\n            id=\"bg-opacity\"\n            v-model=\"opacity\"\n            type=\"range\"\n            number\n            min=\"0\"\n            max=\"1\"\n            step=\"0.01\"\n          />\n          <b-input-group-append\n            is-text\n            class=\"text-monospace\"\n          >\n            {{ opacity.toFixed(2) }}\n          </b-input-group-append>\n        </b-input-group>\n      </b-form-group>\n      <b-form-group\n        label=\"Blur\"\n        label-for=\"bg-blur\"\n        label-cols-sm=\"4\"\n        label-cols-lg=\"12\"\n        class=\"mb-2 mb-lg-0\"\n      >\n        <b-form-select\n          id=\"bg-blur\"\n          v-model=\"blur\"\n          :options=\"blurs\"\n        />\n      </b-form-group>\n    </b-col>\n    <b-col lg=\"6\">\n      <b-overlay\n        id=\"overlay-background\"\n        show\n        :variant=\"variant\"\n        :opacity=\"opacity\"\n        :blur=\"blur\"\n        rounded=\"sm\"\n      >\n        <b-card\n          title=\"Card with overlay\"\n          aria-hidden=\"true\"\n          class=\"mb-0\"\n        >\n          <b-card-text>\n            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et\n            dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip\n            ex ea commodo consequat.\n          </b-card-text>\n          <b-button\n            v-ripple.400=\"'rgba(255, 255, 255, 0.15)'\"\n            disabled\n            variant=\"primary\"\n          >\n            Button\n          </b-button>\n        </b-card>\n      </b-overlay>\n    </b-col>\n  </b-row>\n</template>\n\n<script>\n  import {\n    BRow,\n    BCol,\n    BFormGroup,\n    BFormSelect,\n    BFormInput,\n    BInputGroupAppend,\n    BCard,\n    BOverlay,\n    BButton,\n    BInputGroup,\n  } from 'bootstrap-vue'\nimport Ripple from 'vue-ripple-directive'\n\n  export default {\n    components: {\n      BRow,\n      BCol,\n      BFormGroup,\n      BFormSelect,\n      BFormInput,\n      BInputGroupAppend,\n      BCard,\n      BOverlay,\n      BButton,\n      BCardText,\n      BInputGroup,\n    },\n    directives: {\n    Ripple,\n  },\n    data: () => ({\n      variant: 'light',\n      opacity: 0.85,\n      blur: '2px',\n      variants: ['transparent', 'white', 'light', 'dark', 'primary', 'secondary', 'success', 'danger', 'warning', 'info'],\n      blurs: [{ text: 'None', value: '' }, '1px', '2px', '5px', '0.5em', '1rem'],\n    }),\n  }\n</script>\n";
var codeFade = "\n<template>\n  <div>\n    <b-overlay\n      :show=\"show\"\n      rounded=\"sm\"\n      no-fade\n    >\n      <div\n        title=\"Card with overlay\"\n        :aria-hidden=\"show ? 'true' : null\"\n      >\n        <b-card-text>\n          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio voluptatibus doloremque dolor nesciunt\n          est nobis consequuntur maxime ea ipsam? Doloribus quidem doloremque ad laudantium ullam eos, consequuntur\n          velit quas vero.\n        </b-card-text>\n\n        <b-button\n          v-ripple.400=\"'rgba(113, 102, 240, 0.15)'\"\n          :disabled=\"show\"\n          variant=\"outline-primary\"\n          @click=\"show = true\"\n        >\n          Show overlay\n        </b-button>\n      </div>\n    </b-overlay>\n\n    <!-- trigger button -->\n    <b-button\n      v-ripple.400=\"'rgba(255, 255, 255, 0.15)'\"\n      variant=\"primary\"\n      class=\"mt-1\"\n      @click=\"show = !show\"\n    >\n      Toggle overlay\n    </b-button>\n  </div>\n</template>\n\n<script>\nimport { BOverlay, BButton, BCardText } from 'bootstrap-vue'\nimport Ripple from 'vue-ripple-directive'\n\n  export default {\n    components: {\n      BOverlay,\n      BButton,\n      BCardText,\n    },\n    directives: {\n    Ripple,\n  },\n    data: () => ({\n      show: false,\n    }),\n  }\n</script>\n";
var codeSpinner = "\n<template>\n  <b-overlay\n    show\n    spinner-variant=\"primary\"\n    spinner-type=\"grow\"\n    spinner-small\n    rounded=\"sm\"\n  >\n    <b-card\n      title=\"Card with spinner style\"\n      aria-hidden=\"true\"\n      class=\"mb-0\"\n    >\n      <b-card-text>\n        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et\n        dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex\n        ea commodo consequat.\n      </b-card-text>\n      <b-button\n        v-ripple.400=\"'rgba(255, 255, 255, 0.15)'\"\n        disabled\n        variant=\"primary\"\n      >\n        Button\n      </b-button>\n    </b-card>\n  </b-overlay>\n</template>\n\n<script>\nimport { BOverlay, BButton, BCard, BCardText} from 'bootstrap-vue'\nimport Ripple from 'vue-ripple-directive'\n\nexport default {\n  components: {\n    BOverlay,\n    BButton,\n    BCard,\n    BCardText,\n  },\n  directives: {\n    Ripple,\n  },\n}\n</script>\n";
var codeCornerRounded = "\n<template>\n  <div>\n    <b-button\n      v-ripple.400=\"'rgba(255, 255, 255, 0.15)'\"\n      variant=\"primary\"\n      @click=\"show = !show\"\n    >\n      Toggle overlay\n    </b-button>\n\n    <b-row class=\"text-center mt-2\">\n      <b-col md=\"6\">\n        <b-card-text>With rounding</b-card-text>\n        <b-overlay\n          :show=\"show\"\n          class=\"d-inline-block\"\n          rounded=\"circle\"\n        >\n          <b-img\n            rounded=\"circle\"\n            height=\"300\"\n            :src=\"require('@/assets/images/banner/banner-27.jpg')\"\n            alt=\"Image 1\"\n          />\n        </b-overlay>\n      </b-col>\n      <b-col\n        md=\"6\"\n        class=\"mt-1 mt-md-0\"\n      >\n        <b-card-text>Without rounding</b-card-text>\n        <b-overlay\n          :show=\"show\"\n          class=\"d-inline-block\"\n        >\n          <b-img\n            rounded=\"circle\"\n            height=\"300\"\n            :src=\"require('@/assets/images/banner/banner-27.jpg')\"\n            alt=\"Image 1\"\n          />\n        </b-overlay>\n      </b-col>\n    </b-row>\n  </div>\n</template>\n\n<script>\nimport {BOverlay, BButton, BImg, BRow, BCol, BCardText} from 'bootstrap-vue'\nimport Ripple from 'vue-ripple-directive'\n\nexport default {\n  components: {\n    BOverlay,\n    BButton,\n    BCardText,\n    // eslint-disable-next-line vue/no-unused-components\n    BImg,\n    BRow,\n    BCol,\n  },\n  directives: {\n    Ripple,\n  },\n  data: () => ({\n    show: false,\n  }),\n}\n</script>\n";
var codeCustomContent = "\n<template>\n  <div>\n    <b-overlay :show=\"show\" rounded=\"sm\" @shown=\"onShown\" @hidden=\"onHidden\">\n    <div>\n      <h6>Card with custom overlay content</h6>\n      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>\n      <p>Click the button to toggle the overlay:</p>\n      <b-button v-ripple.400=\"'rgba(255, 255, 255, 0.15)'\" ref=\"show\" :disabled=\"show\" variant=\"primary\" @click=\"show = true\">\n        Show overlay\n      </b-button>\n    </div>\n    <template #overlay>\n      <div class=\"text-center\">\n        <b-icon icon=\"stopwatch\" font-scale=\"3\" animation=\"cylon\" />\n        <p id=\"cancel-label\">\n          Please wait...\n        </p>\n      <b-button\n          ref=\"cancel\"\n          v-ripple.400=\"'rgba(255, 255, 255, 0.15)'\"\n          variant=\"outline-danger\"\n          size=\"sm\"\n          aria-describedby=\"cancel-label\"\n          @click=\"show = false\"\n        >\n          Cancel\n      </b-button>\n    </template>\n  </div>\n</template>\n\n<script>\nimport { BOverlay, BButton } from 'bootstrap-vue'\nimport Ripple from 'vue-ripple-directive'\n\nexport default {\n  components: {\n    BOverlay,\n    BButton,\n  },\n  directives: {\n    Ripple,\n  },\n  data: () => ({\n    show: false,\n  }),\n  methods: {\n    onShown() {\n      // Focus the cancel button when the overlay is showing\n      this.$refs.cancel.focus()\n    },\n    onHidden() {\n      // Focus the show button when the overlay is removed\n      this.$refs.show.focus()\n    },\n  },\n}\n</script>\n";
var codeNoWrapMode = "\n<template>\n <div>\n    <div class=\"position-relative p-2 bg-info\">\n      <b-card-text class=\"text-white font-weight-bold\">\n        Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n      </b-card-text>\n      <b-card\n        title=\"Card with parent overlay\"\n        class=\"mb-1\"\n      >\n        <b-card-text>Laborum consequat non elit enim exercitation cillum.</b-card-text>\n        <b-card-text>Click the button to toggle the overlay:</b-card-text>\n        <b-button\n          v-ripple.400=\"'rgba(113, 102, 240, 0.15)'\"\n          :disabled=\"show\"\n          variant=\"outline-primary\"\n          @click=\"show = true\"\n        >\n          Show overlay\n        </b-button>\n      </b-card>\n      <b-card-text class=\"text-white font-weight-bold mb-0\">\n        Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n      </b-card-text>\n      <b-overlay\n        :show=\"show\"\n        no-wrap\n      />\n    </div>\n    <b-button\n      v-ripple.400=\"'rgba(255, 255, 255, 0.15)'\"\n      class=\"mt-3\"\n      variant=\"primary\"\n      @click=\"show = !show\"\n    >\n      Toggle overlay\n    </b-button>\n  </div>\n</template>\n\n<script>\nimport { BOverlay, BButton, BCard, BCardText } from 'bootstrap-vue'\nimport Ripple from 'vue-ripple-directive'\n\nexport default {\n  components: {\n    BOverlay,\n    BButton,\n    BCard,\n    BCardText,\n  },\n   directives: {\n    Ripple,\n  },\n  data: () => ({\n    show: false,\n  }),\n}\n</script>\n";
var codeForm = "\n<template>\n  <div>\n    <b-form\n      class=\"position-relative\"\n      @submit.prevent=\"onSubmit\"\n    >\n      <b-form-group\n        label=\"Name\"\n        label-for=\"form-name\"\n        label-cols-lg=\"2\"\n      >\n        <b-input-group>\n          <b-input-group-prepend is-text>\n            <b-icon icon=\"person-fill\" />\n          </b-input-group-prepend>\n          <b-form-input\n            id=\"form-name\"\n            :disabled=\"busy\"\n          />\n        </b-input-group>\n      </b-form-group>\n      <b-form-group\n        label=\"Email\"\n        label-for=\"form-mail\"\n        label-cols-lg=\"2\"\n      >\n        <b-input-group>\n          <b-input-group-prepend is-text>\n            <b-icon icon=\"envelope-fill\" />\n          </b-input-group-prepend>\n          <b-form-input\n            id=\"form-email\"\n            type=\"email\"\n            :disabled=\"busy\"\n          />\n        </b-input-group>\n      </b-form-group>\n      <b-form-group\n        label=\"Image\"\n        label-for=\"form-image\"\n        label-cols-lg=\"2\"\n      >\n        <b-input-group>\n          <b-input-group-prepend is-text>\n            <b-icon icon=\"image-fill\" />\n          </b-input-group-prepend>\n          <b-form-file\n            id=\"form-image\"\n            :disabled=\"busy\"\n            accept=\"image/*\"\n          />\n        </b-input-group>\n      </b-form-group>\n      <div class=\"d-flex justify-content-center\">\n        <b-button\n          v-ripple.400=\"'rgba(255, 255, 255, 0.15)'\"\n          ref=\"submit\"\n          type=\"submit\"\n          :disabled=\"busy\"\n        >\n          Submit\n        </b-button>\n      </div>\n\n      <b-overlay\n        :show=\"busy\"\n        no-wrap\n        @shown=\"onShown\"\n        @hidden=\"onHidden\"\n      >\n        <template v-slot:overlay>\n          <div\n            v-if=\"processing\"\n            class=\"text-center p-4 bg-primary text-light rounded\"\n          >\n            <b-icon\n              icon=\"cloud-upload\"\n              font-scale=\"4\"\n            />\n            <div class=\"mb-3\">\n              Processing...\n            </div>\n            <b-progress\n              min=\"1\"\n              max=\"20\"\n              :value=\"counter\"\n              variant=\"success\"\n              height=\"3px\"\n              class=\"mx-n4 rounded-0\"\n            />\n          </div>\n          <div\n            v-else\n            ref=\"dialog\"\n            tabindex=\"-1\"\n            role=\"dialog\"\n            aria-modal=\"false\"\n            aria-labelledby=\"form-confirm-label\"\n            class=\"text-center p-3\"\n          >\n            <p><strong id=\"form-confirm-label\">Are you sure?</strong></p>\n            <div class=\"d-flex\">\n              <b-button\n                v-ripple.400=\"'rgba(234, 84, 85, 0.15)'\"\n                variant=\"outline-danger\"\n                class=\"mr-3\"\n                @click=\"onCancel\"\n              >\n                Cancel\n              </b-button>\n              <b-button\n                v-ripple.400=\"'rgba(40, 199, 111, 0.15)'\"\n                variant=\"outline-success\"\n                @click=\"onOK\"\n              >\n                OK\n              </b-button>\n            </div>\n          </div>\n        </template>\n      </b-overlay>\n    </b-form>\n  </div>\n</template>\n\n<script>\nimport {\n  BButton,\n  BOverlay,\n  BForm,\n  BProgress,\n  BIcon,\n  BFormGroup,\n  BInputGroup,\n  BInputGroupPrepend,\n  BFormInput,\n  BFormFile,\n} from 'bootstrap-vue'\nimport Ripple from 'vue-ripple-directive'\n\nexport default {\n  components: {\n    BButton,\n    BOverlay,\n    BForm,\n    BProgress,\n    BIcon,\n    BFormGroup,\n    BInputGroup,\n    BInputGroupPrepend,\n    BFormInput,\n    BFormFile,\n  },\n  directives: {\n    Ripple,\n  },\n  data: () => ({\n    busy: false,\n    processing: false,\n    counter: 1,\n    interval: null,\n  }),\n  beforeDestroy() {\n    this.clearInterval()\n  },\n  methods: {\n    clearInterval() {\n      if (this.interval) {\n        clearInterval(this.interval)\n        this.interval = null\n      }\n    },\n    onShown() {\n      // Focus the dialog prompt\n      this.$refs.dialog.focus()\n    },\n    onHidden() {\n      // In this case, we return focus to the submit button\n      // You may need to alter this based on your application requirements\n      this.$refs.submit.focus()\n    },\n    onSubmit() {\n      this.processing = false\n      this.busy = true\n    },\n    onCancel() {\n      this.busy = false\n    },\n    onOK() {\n      this.counter = 1\n      this.processing = true\n      // Simulate an async request\n      this.clearInterval()\n      this.interval = setInterval(() => {\n        if (this.counter < 20) {\n          this.counter += 1\n        } else {\n          this.clearInterval()\n          this.$nextTick(() => {\n            // eslint-disable-next-line\n            this.busy = this.processing = false\n          })\n        }\n      }, 350)\n    },\n  },\n}\n</script>\n ";
var codeBusyState = "\n<template>\n  <div>\n    <b-overlay\n      :show=\"busy\"\n      rounded=\"lg\"\n      opacity=\"0.6\"\n      @hidden=\"onHidden\"\n    >\n      <template v-slot:overlay>\n        <div class=\"d-flex align-items-center\">\n          <b-spinner\n            small\n            type=\"grow\"\n            variant=\"secondary\"\n          />\n          <b-spinner\n            type=\"grow\"\n            variant=\"dark\"\n          />\n          <b-spinner\n            small\n            type=\"grow\"\n            variant=\"secondary\"\n          />\n          <!-- We add an SR only text for screen readers -->\n          <span class=\"sr-only\">Please wait...</span>\n        </div>\n      </template>\n      <b-input-group\n        size=\"lg\"\n        :aria-hidden=\"busy ? 'true' : null\"\n      >\n        <b-form-input\n          v-model=\"value\"\n          :disabled=\"busy\"\n        />\n        <b-input-group-append>\n          <b-button\n           v-ripple.400=\"'rgba(255, 255, 255, 0.15)'\"\n            ref=\"button\"\n            :disabled=\"busy\"\n            variant=\"primary\"\n            @click=\"onClick\"\n          >\n            Do something\n          </b-button>\n        </b-input-group-append>\n      </b-input-group>\n    </b-overlay>\n  </div>\n</template>\n\n<script>\nimport { BOverlay, BInputGroup, BFormInput, BInputGroupAppend, BButton, BSpinner} from 'bootstrap-vue'\nimport Ripple from 'vue-ripple-directive'\n\nexport default {\n  components: {\n    BOverlay,\n    BInputGroup,\n    BFormInput,\n    BInputGroupAppend,\n    BButton,\n    BSpinner,\n  },\n    directives: {\n    Ripple,\n  },\n  data: () => ({\n    value: 'Some value',\n    busy: false,\n    timeout: null,\n  }),\n  beforeDestroy() {\n    this.clearTimeout()\n  },\n  methods: {\n    clearTimeout() {\n      if (this.timeout) {\n        clearTimeout(this.timeout)\n        this.timeout = null\n      }\n    },\n    setTimeout(callback) {\n      this.clearTimeout()\n      this.timeout = setTimeout(() => {\n        this.clearTimeout()\n        callback()\n      }, 5000)\n    },\n    onHidden() {\n      // Return focus to the button\n      this.$refs.button.focus()\n    },\n    onClick() {\n      this.busy = true\n      // Simulate an async request\n      this.setTimeout(() => {\n        this.busy = false\n      })\n    },\n  },\n}\n</script>\n";

/***/ })

}]);